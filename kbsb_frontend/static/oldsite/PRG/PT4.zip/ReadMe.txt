PairTwo v4.12
---------------------------
Email: Georges.Marchal@tiscali.be
  
to do:
------

quelques r�gles:
----------------
Tournoi Toutes Rondes Individuel :
�	Confrontation Directe
�	Syst�me KOYA
�	Sonneborn-Berger
�	Nombre de parties gagn�es

Syst�me Suisse Individuel (tous les joueurs ayant un classement coh�rent):
�	Moyenne Elo des adversaires r�ellement rencontr�s (non impl�ment� dans PairTwo)
�	Performance Elo du tournoi

Syst�me Suisse Individuel (la plupart des joueurs �tant class�s, les Elo n'�tant pas coh�rents) :
�	Confrontation Directe
�	Cumulatif
�	Buchholz
�	Sonneborn-Berger
�	Nombre de parties gagn�es

Syst�me Suisse Individuel (la plupart des joueurs �tant non class�s) :
�	Confrontation Directe
�	Buchholz
�	Sonneborn-Berger
�	Nombre de parties gagn�es
	
Historique des corrections:
---------------------------
v4.13	- 16-01-2007	- Erreur dans le calcul du Sonneborn Berger
						  Le SB est la somme des SCORES AJUSTES des joueurs contre lesquels on gagne
						  + la demi somme des SCORES AJUSTES contre ceux contre qui on a fait NULL.

v4.12	- 13-11-2006	- Erreur dasn l'affichage des grilles des tournois en Pool.
							0-0 est affich� pour la partie pas encore jou�e.
v4.11	- 18-10-2006	- Ne pas compter le BYE si la ronde n'est pas toute termin�e: il y avait
							une erreur dans la correction de la version 4.06, cela est corrig�.
							Dans cette version (et les suivantes) on ne comptabilisait pas le BYE ni les
							r�sultats suivants si TOUS les r�"sultats n'�taient pas entr�s. Avzec cette
							version, il suffit d'enregistrer UN r�sultat pour que le BYE soit comptabilis�.
v4.10	- 15-10-2006	- Modification du texte 'ne pas mettre ABSENT....'
						- Changement des 'Pr�f�rences': elles �taient toujours sauv�es m�me si l'on dit 'NON'
						- Apr�s une erreur d'ouverture, impossibilit� d'ouvrir un autre fichier.
						- Ne pas afficher les joueurs ABSENT lors du classement final
						- Ne pas autoriser ABSENT pour tournois ferm�s.
						- Tournoi FIDE: les joueurs NC apparaissent avec un Elo '0F' au lieu de '0N'
						- Tournois ferm�s double rondes: le fichier HTML ne reprenait que le premier tour.
						- Dans la fiche du joueur, affichage des Scores Ajust�s.
						- Recalcul complet du Bucholtz en tenant compte des parties non-jou�es.
						- !!! Le calcul du score ajust� se fait en attribuant qu'un demi point pour
							  les parties non jou�es (Forfait, Bye, Absent) afin de calculer le Bucholtz.
						  !!! Le bucholtz est la somme des scores ajust�s des adversaires pour les parties
							  qui ont �t� jou�es, plus la somme du bucholtz du joueur lui-m�me
							  pour les parties non jou�es (Forfait, Absent ou Bye).
						- Correction du d�partage 'R�sultat Mutuel' en cas de tournoi 'Aller-Retour'


v4.09	- 21-08-2006	- Fichier ELO Belge: Mauvais calcul des parties Gagn�es,Perdues
						- Pour les joueurs �trangers sans cote Belge, il faut mettre la cote FIDE
						- Correction du Bucholtz, Median et Sonneborn Berger:
						    le calcul des scores ajust�s n'�tait pas juste.

v4.08	- 26-07-2006	- Bug dans la suppression de la virgule entre le nom et le pr�nom des
							joueurs issus du fichier FIDE.DBF. La derni�re lettre du nom �tait perdue.
v4.07	- 25-07-2006	- Ajout du SEXE pour les joueurs extraits du fichier FIDE.DBF

v4.06	- 28-06-2006	- Ne pas tester les joueurs selectionn�s pour faires les listes ELO,HTML,TXT
						- Probl�me de date de naissance avec fichiers FIDE
						- Suppression de la virgule entre le nom et le pr�nom en provenance du fichier FIDE
						- Ajout d'un club corrig�. (affichage du nouveau club)
						- Dor�navent les release n'auront plus que 4 caract�res (4.06, 4.07, 4.08, ...)

v4.05.11   - 21-06-2006	- Toujours un petit probl�me d'alignement dans les fichiers html: corrig�.
						- Pour l'interdiction d'envoi si le tournoi n'est pas termin�, il y avait une
							erreur dans le cas de match en AllerRetour.
						- Pour rappel, pour les matchs en Aller-Retour il faut donner le nombre de
							rondes sans tenir compte des matchs retour. Soit par example 9 rondes en Aller-Retour
							et PairTwo d�termine lui-m�me qu'il faudra jou� 18 parties. Mais le
							tournoi reste un tournoi en 9 rondes.

v4.05.10   - 20-06-2006	- Interdiction d'envoyer des r�sultats pour la cote ELO si tournoi non termin�.
							Il faut soit le terminer, soit modifier le nombre de rondes.
						- Memorisation du num�ro du premier tableau (FirstBoard) dans les donn�es du tournoi.
						- Bug dans l'affichage des nom de clubs lorque l'on travaille avec le pays 'NED',
							il lisait les clubs dans le fichier Clubs.txt au lieu de ClubsNed.txt.

v4.05.09   - 19-05-2006	- Correction de la date de naissance pour l'envoi des fichers FIDE. Si la 
							date de naissance n'est pas renseign�e dans le fichier .SWS, elle est
                            lue dans PLAYER.DBF, si le joueur n'est pas renseign� dans PLAYER (joueur �tranger)
							l'ANNEE de naissance est lue dans FIDE.DBF.

v4.05.08   - 16-05-2006 - Suppression dans 'Pr�f�rence' du bouton 'D�partage par default'. Il faut g�n�rer
                            soi-m�me les d�partages suivant les recommandations ede la FIDE et suivant 
							le type de tournoi. Ce bouton �tait g�n�rateur d'erreurs.
						- Avant la g�n�ration du fichier pour le calcul ELO BELGE,
							les matricules sont v�rifi�s par rapport � PLAYER.DBF, afin de v�rifier
							que tous les joueurs soient inscrits � la FEFB (sauf les �trangers). Un message
							est affich� si un joueur n'est pas en ordre.
						- Ajout des d�partages par syst�me KOYA pour les tournois ferm�s
						     (somme des points des adversaires qui ont marqu�s 50% des points) , 
							 Nbr.VICTOIRES (Tournois ferm�s ou Open Swuisse) et PERFORMANCE (pour les open).
						- Prise en compte des ExtraPoints pour calcul des points pour classement et appariement. Ces
						     Extras-Points permettent soit de faire un syst�me acc�l�r� en ajoutant des points � 
							 certains groupes de joueurs, puis en les retirant progressivement, soit mettre
							 une amende � un joueur (en retirant des points) � la fin d'un tournoi afin de le
							 d�class� (moins de points).
 						- Correction de la lecture des fichiers PLAYER et FIDE en m�moire (DELETED RECORDS).
 						- Les Help FRANCAIS et NEERLANDAIS ont �t� adapt�s.

v4.05.07   - 11-04-2006 - Modification de la g�n�ration des dates en cas de tournois Aller-Retour
						- Probl�me avec le changement de Pays pendant les inscriptions
						- Probl�me lors de l'ouverture d'un fichier qui ne se trouve pas dans le r�pertoire
							  courant ou dans le r�pertoire SWS.
						- Modification dans menu de Open(Ctrl+O) Save(Ctrl+S) et New(Ctrl+N)
						- Ajout de l'impression de la table de Berger dans le menu imprimer.
						- Si l'on donne un nom suivit d'un '*', le programme lit automatiquement
						      PLAYER.DBF sans devoir passer par le bouton lire. Par contre, il est
							  toujours possible de changer le contenu du nom pour effectuer la
							  recherche si le d�but �tait mauvais. Le nombre maximum de joueurs lus
							  passent de 1000 � 100.
						- Ne plus mettre syst�matiquement les joueurs �trangers avec les noirs.
						      C'�tait pour corriger une erreur de calcul ELO de chez Henrion,.
						- R�alignement de certains champs dans le fichier .html
						- Standardisation du texte dans le Menu Fichier ELO Belge,Fide,Hollandais
						- Adaptation des 'helps (FR,NL,EN)' pour mise en concordance avec les modifs.
						- Visibilit� du pays en entier, mais traitement uniquement du sigle (BEL BELGIQUE)

v4.05.06   - 02-02-2006 - Ajout de la nationalit� dans PLAYER.DBF. Ceci afin de pouvoir
                              mettre la VRAI nationalit� aux joueurs �trangers
							  qui jouent et qui sont afili�s en Belgique, notamment
							  pour les interclubs, mais aussi pour les frontaliers.
							  Le champs NOUV_MOD (4 caract�res) sera utilis� � cet effet.
							  Le 4me carat�re du champs indiquera si le joueur est frontalier
						      Ce 4me caract�re (+) ne sert que pour le calcul ELO des frontaliers
						- Recalcul des Points avant chaque affichage, car il y a
						      un bug non trouv�. Il m'a d�j� �t� rapport� que les points affich�s
							  ne correspondaient pas avec la r�alit�. Cela m'est arriv� aussi une
							  une fois sans bien comprendre la provenance de cet incident. 
							  Cela m'est arriv� lorsque j'ai entr� un mauvais r�sultat � une
							  ronde, puis appari� la ronde suivante, entr� les r�sultats de cette
							  derni�re ronde, et enfin corrig� le r�sultat de la ronde pr�c�dente
							  qui �tait �rron�. Mais je n'ai pas pu reproduire le ph�nom�ne par
							  la suite, c'est pourquoi je pr�f�re recalcul� les points � chaque
							  affichage et avant le sauvetage du fichier.
						- Lorsque le d�partage est exactement identique sur tous les tie-break,
						      PairTwo donnait un r�sultat au hazard. Il donne maintenant
							  le joueur avec l'ELO le plus �lev� en premier.
						- Lorsque l'on affiche un appariement dont les r�sultats ne sont pas 
						      encore entr�s, PairTwo affichait d�j� le point de BYE. Avec cette version,
							  cette erreur est corrig�e. Ce point sera acquis d�s qu'un r�sultat est entr�.
						- Nouveau Calcul de la Performance en tenant compte de la limite de 350 points.
						- Si un club est pr�c�d� d'une etoile '*' il n'est plus actif !!!
						- Ajout de N ou F apr�s la cote du joueur si tournoi FIDE
						- Correction .html si tournoi FIDE et ABSENT
						- Pour un tournoi FIDE, le fichier pour le calcul de l'ELO NATIONAL
						      doit contenir l'ELO national et par l'ELO FIDE.
						- Ajout de la version de PairTwo dans le fichier ELO Belge
						- Ne pas g�n�rer le fichier ELO BELGE si pas de r�sultats.

v4.05.05   - 25-11-2005 - Correction du calcul de nombre de + - = dans le fichier
                              destin� au calcul de l'ELO BELGE.

v4.05.04   - 19-11-2005 - Quelques ajustements dans la pr�sentation du classement g�n�ral
                              du fichier .html

v4.05.03   - 15-11-2005 - Dans le rapport vers fichier, 
                             les ABSENT et FORFAITS sont indiqu�s pour chaque rondes
						- Allocation en une seule fois de la m�moire pour PLAYER et FIDE
						- Correction d'un probl�me de lecture de PLAYER.DBF
						- Fichier ELO Belge: ligne de titre, ajout de la constante ' N�'
						- Fichier ELO Belge, Type De Tournoi: Ajout des tournois ferm�s en Aller-Retour
						- Fichier ELO Belge: ligne de controle, ajout de +nn=nn-nn comptabilisant
						      Le nombre de victoires, de nulles et de d�faites
							  Le nombre de nulle est EXACT (aaa contre bbb 1/2 - 1/2 --> 2 NULLES)
							  aaa contre bbb: 0 - 1/2 1 DEFAITE, 1 NULLE
							  Ceci afin d'�tre compatible avec le futur CalcImport
						- Dans les tournois FERME, suppression de la possibilit� de mettre
						      les joueurs ABSENTS ou FORFAITS car cela empeche l'appariement par table
							  de berger qui sont pr��tablis. Il faut absolument renseigner
							  la partie comme perdue par FORFAIT et non le joueur.
						- Dans les options classement, ajout affichage par RANK 
						      qui peu �tre est diff�rent de l'ELO dans le cas de tournois ferm�s.
						- Dans la toolbar, affichage par ELO et par RANK
						      Modification de la routine de tri RANK et ELO
							  Le classement ELO peut ne pas etre �gal au classement par RANK,
							  notament dans les tournois ferm�s, o� le Rank est calcul� soit
							  manuellement, soit automatiquement, soit libre.
						- Interdiction de modifier le Rank apr�s la ronde 1
						- Fichiers .html: correction des Pools pour les tournois ferm�s,
						      notamment lorsque le nombre de joueurs est impair.
						- Dans la page .html, mettre le bon n� de Version de PairTwo au lieu de constante.

v4.05.02   - 07/11/2005 - Bug dans la lecture des joueurs FIDE qui ne sont pas dans PLAYER.DBF

v4.05.01   - 30-10-2005	- Les titres sur l'�cran et dans les pages imprim�es sont en gras 
						- Les Infos du .html un peu mieux (avis personnel)
						- Menu Appariement/Controler le rank: gris� si le tournoi est commenc�.
						- Fichier ELOBELGE tri� par POINTS avant la 4.05 sinon par RANK
						                   joueurs sans matricules: 5 espaces au lieur de 5 ZEROS.

v4.05	   - 05-10-2005 - Chargement des Matricule et Noms en memoire, pour g�rer un index
                             des  fichiers PLAYER.DBF et FIDE.DBF
						- Tri des absents par ordre alphab�tique
						- Forms de Resultats: modifications et ajout d'une case ABSENCE
						- Modification du HELP en html FRA NED et ENG
						- Appariements: le r�sultat est maintenant entre les joueurs (plus � la fin)
						- D�partage: ne tient plus compte de la ronde en cours (appari�e et pas jou�e).
						- D�partage Bucholtz: corrig� (les scores ajust�s �taient mal calcul�s), en effet
						     chaque partie non jou�es (Bye, GainFF, perte FF, absent) vaut 1/2 points,
						- Suppression de la boite de dialogue 'Choix du Bucholtz'.
						- Generation des fichiers .html pour publication sur web
						    Les fichiers sont xxx.html, xxx.CLG.html, xxx.Rxx.html, xxx.APT.html xxx.GRI.html
							CLG=Classement General
							Rxx=Ronde xx (r�sultats)
							Pxx=Pool xx (tableau de la Pool xx)
							APT=Appariement par Table
							GRI=Grille am�ricaine
							Si les fichiers 'PairTwoClub.jpg' et 'PairTwoFederation.jpg' sont pr�sents, il seront incorpor�s
							  dans le fichier .html, rubrique 'Infos'  en vue de piblmication sur le WEB. 
							  Ne pas oublier de transferer aussi ces fichiers sur le WED. 
							  Sinon le nom du club organisateur  est affich� ainsi que 'F.E.F.B' par defaut..
						- Classement forme Appariement: 
							Non appari� = ' ' au lieu de '0'
							Victoire par Forfait = '+' et pas '1'
							D�faite par forfait  = '-' et pas '0'
						- Pairing M�thode: defaut=Numero ELO (Ranking)
						- Memorisation du dernier repertoire des fichiers .sws
						- Correction de l'utilisation du Help 
						- Oubli de 0-1/2 et 1/2-0 dans les 'dll' NED et ENG
						- Suppression boite de dialogue 'Paste Player' (jamais utilis�e)
						- Correction de l'attribution des cat�gories
						- Correction de l'alignement des sorties en format .txt
						- Ajout de Tous Absent et Tous Present dans le menu (Shft-Ctrl-A et Shft-Ctrl-P)
						- Ajout dans le menu Apparier de 'Controler le Rank' pour recalculer la Ranking Liste.
							Cela permet de corriger �ventuellement les erreurs de Ranking de PairTwo.
						- M�me les tournois en Pool ont une Rank Liste (ce qui n'�taient pas le cas)

v4.04.04   - 18-10-2005 - Correction affichage r�sultats si Absent.

v4.04.03   - 17-10-2005 - Utilisation du nouveau Help en html

v4.04.02   - 03-10-2005 - Dans appariement, ajout des Absents et Forfaits.

v4.04.01   - 19-09-2005	- Correction du passage de la ronde 1 � la 2 puis retour � la 1 (F6-F5-F6)
						- Mise � jour du Num�ro de version dans la boite de dialogue '� propos de'
						- Tournoi en POOL et appariement avec cat�gories s�par�es :
							Interligne apr�s changement de cat�gorie dans classement (sauf ALPHA et RANK)
							Interligne dans classement 'forme appariement'
							Tableaux s�par�s dans le classement 'forme tableau'. De plus, il y a maintenant
							  un tableau par cat�gorie.
							Il faut que toutes les Pools poss�dent le m�me nombre de joueurs.
						- Dans ELOBELGE, mettre le joueur �tranger avec NOIR et son adversaire avec BLANC
						     Un �tranger est un joueur avec matricule 00000
						- Modification du fichier des resultats de la FIDE (nouveau format � partir du 1/10/2005)
						     Ecriture d'un nouveau module en format Texte (et non plus DBF).
						- Tempo par default: 40c/2h + 1h QPF (et pas 40c/1h)
						- Quelques ajustements

v4.04	 - 18-09-2005	- TieBreak par default: CUMULATIF + BUCHOLTZ MEDIAN + BUCHOLTZ (tournoi SWISS)
						- Lors de la lecture de la liste des joueurs, change le curseur en sablier.
						- Suppression dans le menu des fonction 'CUT,COPY,PASTE' des joueurs. 
						  (incompatibilt� entre versions 16 bits (Windows 3.11) et 32 bits (WIN 98, 2000, XP)
						- Ajout du resultat 0-1/2 et 1/2-0 dans la boite de dialogue lorsque l'on fait DOUBLE CLICK
						- Mettre la premi�re lettre du nom_prenom en majuscule si preceder d'un espace.
						- Tournois SWISS et AMERICAIN: ajout du mode ALLER-RETOUR. 
						    Il faut d�finir le nombre normal de ronde. 
							Dans la d�finition du tournoi, 
							cliquer sur 'TYPE' et Cocher ALLER-RETOUR.
							Le programme doublera automatiquement le nombre de rondes pour faire les appariements. 
							L'appariement 'pair' sera le m�me que 
							l'appariement 'impair' mais avec les couleurs invers�es.
						- Lors de la lecture d'un matricule, si le matricule est aussi FIDE et que le fichier 
						    FIDE.DBF n'est pas pr�sent, affichage de 'Matricule Inconnu', ce qui est une erreur.
							Le matricule est maintenabnt affich� sans les information en provenance de FIDE.DBF
						- Ajout d'une touche (Ctrl F) pour marquer le joueur FORFAIT. Egalement dans le menu.
						- Les joueurs absents sont marqu�s 'A' et plus '*'
						- Les joueurs Forfaits sont marqu�s 'F'.
						- Ajout d'un bouton 'Mettre Tous Present' (sauf les FORFAITS)
						- Tempo par default: 40c/1h + 1h QPF (et pas 30' QPF)
						- Ajustement de la liste des joueurs en insertion. Certains pays (SWE, HUN, ...) faisaient
						    que les cotes �taient 'd�salign�es' � cause de la taille des caract�res.
						- Dans les appariements, ne mettre le 'N' ou 'F' (type de la cote National ou Fide)
						    que si on a demander la cote la + haute, afin de diff�rencier.

v4.03.02 - 16-08-2005	- Lecture des joueurs par leur nom si on rentre le nom suivi de *.
						- Si ELONAT=0 afficher (0 N) et pas (0 F).
						- Probl�me de mise � jour manuelle de la cat�gorie.
						- Pour avoir un bon alignement dans les fichiers 'texte', il faut aller dans:
							Options, Options Texte, S�parateur Text = Espaces
						- Pour pouvoir �tre charg� dans Excel, il faut TABULATEUR ou VIRGULE.

v4.03.03 - 20-08-2005	- Apr�s un appariement, changement du titre de la fenetre principale.
						- Probl�me affichage du titre 'Club ou Klub' en Anglais et Neerlandais
						- Acceptation des r�sultats 0-1/2 et 1/2-0
						- Bug dans la gestion en m�moire des clubs.
						- Lorsque le club n'existe pas, ajout dans CLUBS.TXT + en memoire
						- Lors de la recherche par nom*, il manque le titre du joueur (f,m,g,...)

v4.03.01 - 13-08-2005	- Rapport en fichier texte: bug dans affichage ELO (3 chars au lieur de 4).

v4.03	 - 07-08-2005	- Lecture des fichiers PLAYER.DBF et FIDE.DBF par mes classes. Plus de OLE
						    il y avait interference avec CHess Manager (BDE de BORLAND)
						- Recherche des fichiers .sws dans le repertoire courant par default.

v4.02	 - 02-08-2005	- Autorisation des numeros de club � jusque 5 caract�res
						- Ajout d'une boite de dialogue pour d�finir les cat�gories par ELO
						- Autorisation d'entrer des joueurs sans matricule (on entre � partir du nom)
						- Affichage de la cote utilis�e dans les r�sultats (N ou F)
						- Adaptation de p2html (maintenant avec le package)
						
v4.01.01 - 31-07-2005	- Oubli de m�morisation du DRIVE (c:\) dans le pathname des fichiers *.DBF
						- S�paration de la recherche des fichiers PLAYER.DBF et FIDE.DBF

v4.01	 - 27-07-2005	- Demande de sauvetage du fichier en cours lorsque l'on quitte PairTwo.
						- Correction du changement de la cat�gorie
						- Lecture du fichier PLAYER.DBF avec des ordres 'SQL' (OLE DBF)
						- Obligation d'avoir le fichier PLAYER.DBF pour cr�er un tournoi
						- Mettre le fichier FIDE.DBF dans le m�me r�pertoire que PLAYER
						- Recherche automatique de l'elo FIDE et COUNTRY dans FIDE.DBF
						- Reinitialiser le fichier 'pairtwo.ini'
						- Remplac� KO par QPF
						- Lecture des fichiers CLUBS.TXT, CLUBSNED.TXT et COUNTRY.TXT en memoire
						- Augmentation de l'affichage du nom du club de 13 � 16 caract�res
						- Bug dans le sauvetage des fichiers (2 * le repertoire dans certains cas)

v4.00.02 - 18-07-2005	- Correction du Refresh. Correction des dates des rondes.
						- L�g�res modif dans les resources NL
						- Correction fonctionnement 'matricule inconnu'
v4.00.01 - 24-06-2005	- Gestion de Player.Dbf + Refresh dans l'inscription des joueurs.

v4.00	 - 2005         - Modification de PairTwo 3.07 pour tourner en 32 bits.
						- Gestion des matricules, correction de quelques bugs
Email: Georges.Marchal@tiscali.be