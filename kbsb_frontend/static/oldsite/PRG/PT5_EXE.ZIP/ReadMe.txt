
PairTwo v5.67
---------------------------
Email: geb.marchal@gmail.com
  
      	
Extrait du HandBook de la FIDE
Recommended Tie-Break Systems

(a)
	Individual Round-Robin Tournaments:
		Direct encounter
		The greater number of wins
		Sonneborn-Berger
		Koya System

(b)
 	Team Round-Robin Tournaments:
		Match points (if ranking is decided by game points), or
		Game points (if ranking is decided by match points)
		Direct encounter
		Sonneborn-Berger
(c) 	
	Individual Swiss Tournaments where not all the ratings are consistent:
		Direct encounter
		The greater number of wins
		The greater number of games with Black (unplayed games shall be counted as played with White)
		Buchholz Cut 1
		Buchholz
		Sonneborn-Berger
(d) 
	Individual Swiss Tournaments where all the ratings are consistent:
		Direct encounter
		The greater number of wins
		The greater number of games with Black (unplayed games shall be counted as played with White)
		AROC
		Buchholz Cut 1
		Buchholz
		Sonneborn-Berger
(e) 
	Team Swiss Tournaments:
		Match points (if ranking is decided by game points), or
		Game points (if ranking is decided by match points)
		Direct encounter
		Buchholz Cut 1
		Buchholz
		Sonneborn-Berger

Les d�partages (a) et (c) sont recommand�s et impl�ment�s dans PairTwo
Si un tournoi Swiss contient des joueurs avec des ELOs consistant il faut utiliser les d�partages (d)


Historique des corrections:
---------------------------
v5.67	-	Coloration des titres.
		-	Coloration des background 1 ligne sur 2 pour plus de lisibilit�.

v5.66	-	Correction dans appariements acc�l�r�s.
			Lorsqu'aucune ronde n'est encore appari�e, si l'affichage de la performance est demand�e
				le titre n'est pas affich�.

v5.65	-	Une page d'information a �t� ajout�e. Actuellement elle n'existe qu'en Fran�ais.
				Le fichier s'appelle InfosFRA.txt.
				Pour avoir ce m�me fichier dans les autres langues, il suffit de cr�er et
				de traduire. Les fichiers s'appellent InfosLLL.txt , ou LLL repr�sente les langues.
				FRA NED et ENG sont les 3 seules reconnus par PairTwo.

v5.64	-	Modification des d�partages par d�fault 
				Voir http://www.fide.com/component/handbook/?id=20&view=category
				Tournois ROUND-ROBIN (Ferm�) (a)
						1. R�sultat direct
						2. Nombre de victoires
						3. Sonneborn-Berger
						4. Koya
						5. Gain avec les Noirs
				Tournois SWISS (ELO disparates : (c))
						1. R�sultat direct
						2. Nombre de victoires
						3. Nombre de parties JOUEES avec les Noirs (***)
						4. Bucholtz Cut
						5. Sonneborn-Berger

				(***)  une partie non jou�e (Forfait, BYE) est consid�r�e jou�e avec les blancs m�me si elle avait �t� appari�e avec les noirs.
			
		-	G�n�ration : retour � Visual C++ 6.0 car Visual Studio 2010 ne permet plus de modififer les boites de dialogues,
					les menus et les dll des langues (fr,nl en). 

		-	ATTENTION : l'ordre dans lequel les d�partages sont pr�sent�s a �t� largement modifi�. Il est donc formellement recommand� de ne pas
				utiliser cette version avec les anciens fichiers .sws, ou alors il faudra modifier tous les d�partages et sauver le r�sultat.
				Pour avoir plus de renseignements sur les d�partages, voir le site FIDE annexe 3 du handbook et paragraphe G. recommandations.
					http://www.fide.com/component/handbook/?id=20&view=category
					
		-	Suppression du sauvetage 'autosave.sws'

					
v5.63	-	La g�n�ration des fichiers pour la FIDE ne marche pas dans les version 5.60 5.61 5.62

v5.62	-	G�n�rer maintenant avec Visual Studio 2010 et plus Visual C++ 6.0

v5.61	-	Impossible de g�n�rer le fichier ELO Belge. Bug dans une parenth�se.

v5.60	-	Correction sur l'envoi des r�sultats partiels lorsque les appariements de la ronde suivante a d�j� �t� faite.
				Actuellement il �tait impossible d'envoyer des r�sultats partiels si on avait d�j� appari� la ronde suivante.
				Maintenant c'est possible jusque la derni�re ronde encod�e dont TOUS les r�sultats sont connus.

		-	Ajout des appariements acc�l�r�s. Pour faire des appariements acc�l�r�s en syst�me SWISS UNIQUEMENT,
				une liste des extra-points a �t� ajout�e.
				Elle sert � ajouter des points fictifs aux joueurs suivant leur cote ELO (comme les cat�gories) avant le
				premier appariement. Ensuite, il faut oter une partie ou tous ces points au fur et � mesure de l'avancement du tournoi.
				On pourrait ajouter 1.5pts au premier quart des joueurs, 1.0Pts au second quart et 0.5pts au troisi�me quart. Le dernier quart
				ne poss�de pas d'eXtra points. Lors de l'appariement, les joueur sont bien appari�s en tenant coppte de leurs points + Extra points,
				ce qui signifie que les joueurs du premier quart seront appari�s ensuemble et ainsi de suite.
				Apr�s 2 rondes, on enleve 0.5 points aux extras points pour finier apr�s 4 ou 6 rondes par enlevgfer TOUS ces
				extras points. Cela permet donc d'apparier les joueurs les plus forts d�s le d�but du tournoi.
				Dans les options de classement, une case � cocher a �t� ajout�e afin de pouvoir visualiser ces extras-points.
				A utiliser en toute connaissance de cause !!!

		-	Ajout et modification d'un d�partage : 
				#Noi = Nombre de parties JOUEES  avec les noirs (#Bla #Zwa)
		        +Noi = Nombre de parties GAGNEES avec les noirs (+Bla +Zwa)
				

v5.55	-	Erreur dans la g�n�ration du fichier pour la FIDE. Ce nom est compos� d'une des lettre S_ B_ ou R_
				pour Standard, Blitz ou Rapide. Cette lettre �tait plac�e avec la lettre du disque ce qui donne
				S_c:/repertoire/NomDuTournoi.txt au lieu de C:/repertoire/S_NomDuTournoi.txt.
				La correction est faite

v5.54	-	Une petite erreur (inversion des nationalit�s) dans la g�n�ration des fichiers .pgn
				Il faut aussi une ligne blaznche apr�s l'ast�risk (*)
		-	Si un tournoi est homologu� FIDE, on prend la nationalit� dans FIDE.DBF et pas dans PLAYER.DBF
		-	Erreur dans g�n�ration 'Rapport vers fichier'

v5.53	-	Les fichiers g�n�r�s pour le calcul ELO de la FIDE et de la FRBE commence tous par une lettre
				d�signant le type de tournoi S_,  R_, et B_ pou Standard, Rapide, Blitz

v5.52	-	A la demande du Luc Cornet, � la fin d'un tournoi on a la possibilit� de g�n�rer un fichier
				au format .pgn (Portable Game Notation) reprenant les ent�tes des parties jou�es. 
				Lorsque l'on encode les parties dans ChessBase on peut alors 'coller' les parties
				dans ce fichier.
		-	La FIDE g�n�re des cotes ELO pour les tournois 'Standard', 'Rapid' et 'Blitz'. Le fichier FIDE.DBF contient maintenant
				les 3 cotes. Lors d'un tournoi homologu� FIDE, il y a lieu d'indiquer maintenant le
				type de tournoi que l'on veut g�n�rer afin de prendre la bonne cote FIDE. Il faut aussi aller dans le menu
				'Option', 'Pr�r�rences' coch� la case 'ELO utilis�: cote FIDE' De cette mani�re PairTwo
				prendra automatiquement la cote FIDE ad�quate.

v5.51	-	Lorsque qu'un fichier est modifi�, et que l'on ne sauve pas, il est impossible de quitter Pairtwo
				ou d'ouvrir un autre fichier. Bug provient de l'obligation du sauvetage apr�s avoir
				envoy� des r�sultats partiels � la FRBE/FIDE.
		-	Les titres de la FIDE ont chang�s d'initiales. Voisi les nouveaus affichages dans Pairtwo 
			CM : Candidat Master
			FM : Fide Master
			IM : International Master
			GM : Grand Master
			WC : Woman Candidat Master
			WF : Woman Fide Master
			WI : Woman International Master
			WG : Woman Grand Master
			HM : Honorary Master
			HG : Honorary Grand Master


v5.50	-	Dans l'envoi partiel des r�sultats pour la FRBE et la FIDE, modifier le message 
			'rien � g�n�rer' par 'les rondes xx � xx ont d�j� �t� g�n�r�es. Voulez-vous les refaire ,'
			On reg�n�re alors les rondes demand�es.

v5.49	-	Dans les libell�s fran�ais, une faute d'orthographe : Apparier une ronde au lieu de Appari� une ronde.
		-	Autoriser l'envoi des fichiers de r�sultats FIDE et/ou FRBE m�me si le tournoi n'est pas termin�.
		-	Apr�s la g�n�ration du fichier, il faut l'envoyer au responsable classement et il est IMPOSSIBLE de 
				revenir en arri�re, car le fichier .sws est mis � jour pour refl�ter l'envoi partiel.

v5.48	-	Lorsque l'on g�n�re un fichier .html mais que l'on a regard� les r�sultats d'une ronde pr�c�dente,
				le fichier donne les r�sultats de toutes les rondes MAIS donne le classement � la ronde regard�e,
				ce qui n'est pas logique. Il faut g�n�r� un fichier avec le classement � la derni�re ronde jou�e.

v5.47	-	Lors d'un tournoi ferm�, l'ajustement du nombre de rondes �tait erron�. Il tenait compte des diff�rentes cat�gories
				m�me si on n'appariait pas lres cat�goris s�par�ment, ce qui est une erreure. Si un tournoi poss�de plusieurs
				cat�gories et que l'on apparie pas s�par�ment, cela correspond � un seul tournoi, les cat�gories �tant pr�sentent
				uniquement pour l'attribution de prix par cat�gories. Si le tournoi comprend des cat�gories et que l'on coche
				la case 'apparier s�par�ment', cela correspondant � plusieurs tournois, les chacun des participants dse trouvant
				dans une cat�gorie et le nombre de participants DOIT �tre le m�me dans chacune des cat�gories.

v5.46	-	Lorsqu'un tournoi est commenc�, interdiction de modifier le nombre de rondes.
			Rappel : 
				Le fichier pour le classement ELO ne peut �tre g�n�r� qu'� la fin du tournoi,
				c-�-d apr�s l'encodage des r�sultats de la derni�re ronde.
				Si le tournoi ne peut �tre termin� pour quelque raison que ce soit,
				il faut faire TOUS les appariements jusque cette derni�re rond et mettre les scores � 0-0ff.
				C'est la seule mani�re de proc�der correctement.
 
v5.45	-	Depuis la version 5.41, le calcul par r�sultats mutuels utilise une fonction d'analyse combinatoire
				pour calculer le nombre de rencontres possibles avec n points.
				Cette fonction est :           n
									  Comb = C -  = n! / 2! * (n - 2)!
									           2
				Lorsque le nombre de parties possibles est trop grand, la fonction 'Factorielle' retourne ZERO et provoque une erreur.
				Correction a �t� faite avec cette version 5.45
				Donc tous les tournois avec comme d�partage 'r�sultats mutuels' ne peuvent pas utiliser
				les versions PairTwo v5.41 jusque v5.44 inclues
		

v5.44	-	Toujours probl�mes avec l'affichage du SonneBorn-Berger et Bucholtz

v5.43	-	L'affichage du SonneBorn-Berger et Bucholtz n'est pas affich� si le Score Ajust� n'est pas demand� dans les options.
			Il faut avant d'afficher les d�partages calculer le 'Score Ajust�'

v5.42	-	Mauvais calcul du Sonneborn-Berger. 
				Il faut utiliser les Scores Ajust�s en cas de FORFAIT ou BYE

v5.41	-	Mauvais calcul du d�partage 'Resultats Mutuels'

v5.40	-	Mauvais calcul du point de BYE dans le cas d'un tournoi FERME et DOUBLE RONDES.

v5.39	-	Un fichier .html n'�tait pas g�n�r� pour les tournois au syst�me 'Keizer'

v5.38	-	Erreur dans la d�composition du N� de Club et le Nom du Club depuis Clubs.txt

v5.37	-	Ajout� un espace dans le fichier html entre la performance et les points.

v5.36	-	Informer si un joueur n'est pas affili� (2�me endroit � tester)

v5.35	-	Informer si un joueur n'est pas affili�.
		-	Correction d'une traduction (signal�e par Remi)

v5.34	-	Round Robin: jusque la version 5.28 il �tait possible de faire 2 rencontre dans un tournoi.
				A partir de la version 5.29 il n'�tait plus possible de le faire (erreur).
				Cette possibilit� est de nouveau introduite � partir de cette version.
		-	Nombres de rondes dans les tournois swiss: 200. Mais attention, il faut au moins le nombre
				de joueurs soit de plus du double que de nombre de rondes. (50 rondes = 150 joueurs).
				Ce nombre n'est pas v�rifier par PairTwo, il incombe au responsable du tournoi.
		- Bug dans les tounois SWISS en plusieurs cat�gories avec appariements s�par�s et des ABSENTS.
		- SHIFT-CTRL-A met tous les joueurs ABSENT. S'ils sont absent SHIFT-CTRL-A les met PRESENT.

v5.33	-	Calcul du SonneBorn Berger revu et corrig�.

v5.32	-	Le calcul du d�partage par r�sultat mutuel n'est pas correct.

v5.31	-	La version du V5.31 �tait fausse, elle affiche 5.20 - De ce fait, le fichier SWS ne 
				pouvait plus �tre lu.
			-	Une erreur �galement dans la cr�ation du fichier HTML pour les tournois en POOL:
					si l'on g�n�re le fichier 2 x cons�cutives, la g�n�ration est mauvaise.

v5.30	-	Le calcul des parties gagn�es avec les Noirs est erron�, ce qui pourrait fausser
				 le classement dans les tournois en Pool !!!
			-	Le calcul des appariements pour les tournois ROUND ROBIN (POOLS) sont maintenant
					effectu�s suivant la table de Berger.
			-	V�rification dans les tournois ferm�s que le nombre de joueurs est �gal dans chacune
				des cat�gories.

v5.29	-	Erreur dans les POOLS si le nombre de joueurs est Impair.Le BYE est mal calcul�. 

v5.28	-	Le calcul des parties gagn�es avec les Noirs est erron�, 
				ce qui pourrait fausser le classement dans les tournois en Pool !!!
		-	Le calcul des appariements pour les tournois ROUND ROBIN (POOLS) 
				sont maintenant effectu�s suivant la table de Berger et plus calcul�s par PairTwo (il y avait des erreurs).

v5.27	-	Dans la recherche des noms, il y avait un bug qui n'apparaissait qu'en WINDOWS SEVEN.
			Le cadre n'�tait plus affich� autour des joueurs en WINDOWS SEVEN

v5.26	-	Dans les tournois 'toutes rondes' en POOL, si l'on donne des cat�gories (pour les prix par example)
					mais que l'on ne d�sire pas faire les appariements s�par�s par cat�gorie, c-�-d que tout
					le monde joue contre tout le monde, le fichier .html pour publier sur internet ne tient
					pas compte du fait que l'on a pas apparier s�par�ment et le fichier n'est pas exploitable.
					En cons�quence, pour les toutnois 'toutes ronde' donc en POOL si l'on donne des cat�gories avant 
					le premier appariement, et que l'on fasse les appariements avec cat�gorie s�par�s, c'e'st comme si l'on avait autant
					de tournoi (de pool) que de cat�gories. Cela permet de ne pas g�n�rer plusieurs fichiers pour les
					diff�rentes 'pools' � g�rer. Par contre si l'on ne fait pas de cat�gories s�par�es cela signifie que tous les
					joueurs vont se rencontrer et que la cat�gorie est juste informative et ne sert qu'� attribuer un prix
					aux joueurs de ces cat�gories.

v5.25	-	Si l'on donne des points sp�ciaux n�gatif, le calcul n'�tait pas juste.
		-	Disable du bouton 'Rafraichir' si Ajout d'un joueur. Ceci afin de ne plus faire 'Rafraichir'
				lorsque l'on ajoute un joueur. Dans le cas d'ajout, il FAUT faire OK ou CANCEL.
				Rafraichir n'est utilis� qu'en modification.
		-	Ajout d'un curseur 'sablier' (HourGlass) pendant la lecture des fichiers Player et Fide.
				En effet, la premi�re fois, il faut charger les matricules et les noms en m�moire,
				ce qui prend un peu de temps. M�me chose si l'on modifie le chemin des fichiers
				Player.dbf et/ou Fide.dbf, il faut relire ces nouveaux fichiers en m�moire.
		-	Si l'on modifie le chemin ou le nom du fichier PLAYER et/ou FIDE, les informations des joueurs
				sont automatiquement remis � jour. Par contre si l'on remplace le fichier PLAYER avec un
				autre du m�me nom, il faudra faire le 'rafraichissement' des joueurs manuellement.

v5.24	-	M�morisation correcte de la F�d�ration organisatrice
		-	Gestion des Logos sur la page HTML:
				Les fichiers images des n� de clubs organisateur, logo organisateurs, 
				des f�d�rations belges, ou autres ficghiers Jpg d�cris ci-dessous devront se trouver dans
				le m�me r�pertoire que le fichier .html g�n�r� aussi bien en local que sur le serveur
				qui va afficher cette page. En haut � gauche se trouvera le logo du club ou de l'ornanisme
				organisateur et � Droite le logo de la F�d�ration ou autre organisateur comme d�crit ici:
			Gauche: 1. le sigle ou le logo du club organisateur s'il est donn� dans la description du tournoi.
					2. Le fichier PairTwoClub.jpg s'il est pr�sent.
					3. Le nom en format texte si rien n'est donn� ni trouv�.
			Droite: 1. Le logo de la f�d�ration (FRBE,FEFB,SVDB,ou VSF) si le fichier existe.
					2. sinon le fichier 'NomDeLorganisateur.jpg' s'il existe.
					3. Le fichier 'PairTwoFederation.jpg' s'il existe
					4. Le nom de la f�d�ration.
			Voit explication sur le site de la FRBE

v5.23	-	Correction d'impr�cisions pour la lecture des inscriptions au format CSV:
				Sexe par defaut: 'M' au lieu de 'F' ou 'V'
				Prendre l'ELO du CSV s'il est absent de Player ou Fide
				Prendre le N� de CLUB de CSV dans tous les cas, s'il est donn�
				Date de Naissance: si matricule Fide et pas Player, le prendre du CSV s'il est donn�.
			En cas de modification d'un joueur, ne pas changer son n� de club s'il a �t� entr�
				� la main m�me s'il ne correcpons pas � celui du Player.

v5.22	-	 Correction d'un bug pour lire les versions ant�rieures.

v5.21	-	 Dans la f�d�ration organisatrice, ajout de  K.B.S.B ainsi que du fichier 'Logo_KBSB.jpg'
				                               ajout d'un champs vide si ce n'est pas une f�d�ration,
											   dans ce cas il n'y a pas de f�d�ration g�n�r�e dans le fichier html.
				Le logo de la f�d�ration est affich� en haut et � droite de la page html.

			 Dans le N� de Club organisateur, possibilit� d'y mettre un nom sigle au lieu du n� de club.
			    Ce sigle sera affich� dans la fichier .html en haut � gauche. 
				Luc Cornet par exemple arbitre un tournoi organis� par l'OTAN. Il pourra mettre 'OTAN' dans 
				le champs du club organisateur et ainsi le logo de l'otan 'OTAN.jpg' devra �tre mis sur 
				le serveur local et le distant afin d'�tre affich� en haut et � droite du fichier .html. 
			 Si les logos de la f�d�ration et du club organisateur ne sont pas pr�sents, les valeurs
				'texte' seront affich�es.
			 
			 Dans la 'ToolBar' des 'ToolTips' (info-bulles) sont ajout�s.
			 
			 Les nouveaux LOGOS.jpg des f�d�rations SVDB,FRBE et KBSB,
			 
			 Pour rappel:
				Pour la g�n�ration des fichiers .html, il faut mettre dans le m�me r�pertoire
				que le fichier html g�n�r� (r�pertoires locaux et distants) les fichiers suivants:
				- Le logo du club organisateur, soit n� de club soit abbr�viation. Le logo sera ainsi
					form� par le n� ou le nom donn� suivit de .jpg (xxxx.jpg)
				- Les 4 fichiers Logo_FRBE.jpg, Logo_KBSB.jpg, Logo_SVDB.jpg, Logo_VSF.jpg.
				Ces fichiers doivent aussi se trouver sur le serveur. 
				Ces fichiers permettent d'afficher les logos des f�d�rations par d�faut.
				Les fichiers 'PairTwoClub.jpg' et 'PairTwoFederation.jpg' sont l� uniquement pour
				  la compatibilit� avec les versions plus anciennes.
			

v5.20	-    La correction de la fonction 'Rafraichir' (v5.18) ne marchait pas.
		-    Le bug de la version 5.19 n'�tait pas corrig�.

v5.19	-	 Correction d'un bug lorsque l'on g�n�re un fichier texte avec le nom du club.
			 
v5.18	-	 Lorsque l'on inscrit un nouveau joueur, et que l'on fait 'Rafraichir' avant 'OK',
				le joueur n'�tait pas inscrit.
		-	 Correction des exportations en format texte et html.
		-	 Correction du calcul des points en cas de BYE (fichiers TXT et HTML)

v5.17	-    Dans la liste des appariements, les absents sont affich�s avec leurs points,...
				et aussi dans les fichiers HTML, CSV et rapports TXT
		-	 Il manque un s�parateur dans les fichiers CSV, entre le N� de club et le matricule du joueur.
		-	 Techniquement,la recherche des joueurs ABSENT ou FORFAIT a �t� transf�r�e dans une autre source.

v5.16	-    Le nom des club �tait affich� sur 20 caract�res. Maintenant, il est affich� 
			 sur une longueur maximum du plus long nom de club, 
			 ce qui permet de gagner de la place � l'affichage.
		-	 Sur la fiche de r�sultats imprim�e, impression du ranking OU de l'Elo des joueurs.
			 Le choix est fait dans le menu option/classement cadre 'r�sultat'
		-	 Dans la liste des appariements, les absents sont affich�s avec leurs points,...

v5.15	-	 Sur demande de Luc Cornet, modification de libell�s en neerlandais.
			 En neerlandais, remplacement de 'HTML naar Bestand' par 'HTML-Rapport'
			 En neerlandais, remplacement de 'CSV naar Bestand' par 'CSV-Rapport'
			 En neerlandaix, remplacement de 'Rating' par 'ELO'
			 En neerlandais, remplacement de 'Kat' par 'Cat'
			 Ajout du titre Num�ro de Club: 'ClNr' dans toutes les langues.
			 Le help ne fonctionnait pas (Le r�pertoire 'Help' DOIT �tre dans le m�me r�pertoire que p2.exe
			 Suppression de l'ancien Help (PairTwo.hlp)

v5.14	-	 Un petit bug dans la page html s'il y a des points sp�ciaux. 
			 La ligne est 'tr>Points Speciaux...' au lieu de <tr>Points Sp�ciaux'

v5.13	-	 En neerlandais Club se dit 'Club' et pas 'Klub'. Modifications dans les bo�tes de dialogues.
			 Correction des appariements manuels (Luc Cornet Janvier 2009)
			 G�n�ration d'un fichier .csv (les m�mes que les fichiers html). Il y a des fichiers pour chacune des rondes
				dont l'extension est .Rnn.csv, 
				un pour le classement g�n�ral avec extension .CLG.csv
				et un fichier g�n�ral comme avec les fichiers .html.
				Les champs sont s�lectionables dans le menu Options/Classements

v5.12	-	 Teste des 30 Rondes maximum pour un tournoi
			 Correction HTML pour les tournois de type 'Americain'.

v5.11	-	 Tie break parties jou�es avec les NOIRS: le calcul est faux, il tiens compte des
				parties BYE et FORFAIT alors qu'il ne faut compter que les parties JOUEES.

v5.10	-	 Affiche 2 points (� la place de 1) pour un BYE dans les tournois ferm�s.

v5.09	-	 Erreur de calcul de d�partage: Nombre de victoires avec les noirs.

v5.08   -    Bug dans les rapports lorsque, dans les options,
               on ne s�lectionne pas le nombre de parties jou�es.
               Il y avait un ZERO afficher par erreur.
        -    Nouvelle gestion des Logos
        -    Dans la d�finition du tournoi, ajout d'un champs Num�ro de club organisateur.
                Ce champs sert � afficher le Logo du club dans les fichier .html
               (affichage sur le web). Le logo du club est sous la forme nnn.jpg. Example: '666.jpg'
        -    Les Logos DOIVENT se trouver en local dans le m�me r�pertoire que le fichier html g�n�r�.
        -    Les Logos DOIVENT AUSSI se trouver sur le site dans le r�pertoire que les fichiers html.
        -    A gauche le Logo du club organisateur:
                Sous la forme nnn.jpg o� nnn repr�sente le n� du club.
                Si le Logo du club n'existe pas, le programme g�n�re le Logo 'PairTwoClub.jpg'
                ceci en vue de compatibilt� avec les versions pr�c�dentes.
        -    A droite le logo de la federation: ceux-ci sont:
                Logo_FRBE, Logo_FEFB.jpg , Logo_VSF.jpg , Logo_SVDB.jpg.
                Ces 4 logos sont fournis.
                S'ils ne sont pas sur le site distant ou dans le r�pertoire local,
                le logo 'PairTwoFederation.jpg' est affich� ceci en vue de compatibilt�
                avec les versions pr�c�dentes.

v5.07	-	Le calcul du Ranking est automatique depuis la v5.04. Mais elle ne doit
				pas l'�tre pour les tournois ferm�s. Le ranking est soit l'ordre
				d'inscription des joueurs (par defaut) ou un ranking manuel avant appariement. 

v5.06	-	Bug dans le fichier ELO FIDE. Si des parties n'�taient pas jou�es, les
				r�sultats �taient d�cal�s.

v5.05	-	Bug dans tournoi americain lorsque l'on met tous les joueurs absent
				Le tournoi devenait 'Tournoi Suisse'

v5.04	-	Calcul du ranking: un nouveau ranking est calcul� AUTOMATIQUEMENT si:
				Ajout d'un nouveau joueur (m�me si le tournoi est d�j� commenc�).
				Modification de l'ELO national ou FIDE.
				Modification du Titre du joueur.
		-	Si tournoi en POOL, pas de recalcul du ranking si modification de cote ELO ou Titre.
		-	Suppression du menu 'Verifier Ranking'
		-	Recalcul du Ranking juste AVANT l'appariement de la premi�re ronde.

v5.03	-	Virgule manquante dans le fichier cr�� par 'rapport ves fichier'

v5.02	-	Bug dans le choix de la cote FIDE dasn le module .csv
		-	Ne pas recalculer le Ranking APRES la premi�re ronde.
		-	Les infos bulles (tooltips) ne fonctionnent qu'en mode DEBUG. A revoir.

v5.01	-	Bug si le nombre de rondes est 1 (UN).
		-	Probl�me avec les affichages et appariements en cat�gories s�par�es.
		-	Ajout d'un champs 'Federation' dans la prise en charge d'un tournoi.
		 	C'est cette f�d�ration qui est affich�e dans le fichier .html (et plus F.E.F.B)
		-	Ajout des infos bulles (tooltips) sur la 'toolbar'

v5.00	-	- Suppression des tournoi par �quipe (Team)
			- Affichage rondes par rondes : on affiche les points obtenus JUSQUE cette ronde,
				et plus les points totaux obtenus juqu'� la derni�re ronde.
			- html: tient compte des points sp�ciaux (syst�me 3-2-1)
			- Modification du texte des points sp�ciaux: 'Forfait' devient 'Perte par Forfait'
			- Possibilit� (Options Classement) d'afficher Scores Ajust�s dans le classement.
			- Modifications dues aux changement de la FIDE:
				- Nouveau layout du fichier des r�sultats (ajout des dates des rondes code 132).
				- Ajout du d�partage 'Nbr. De parties jou�es avec les Noirs'
				- Initialisation des d�partages par d�fault pr�conis�s par la FIDE.
			- Regroupement du 'Type de Tournoi' dans la 'd�finition du tournoi'.
			- Transfert de 'Apparier Cat�gories S�par�ment' dans 'Categorie'
			- Inversion des titres : MI passe devant GMIF pour l'appariement.
			- Nombre de rondes r�elles en mode 'Aller-Retour'
			- Correction du calcul et affichage des d�partages par R�sultats Mutuels
			- Correction du d�partage du syst�me Koya 
			- Normalisation du nom d'un tournoi. Comme le nom est utilis� pour
				cr�er un nom de fichier, il est interdit d'y mettre des caract�res
				sp�ciaux (:/\&@#{}[]"') une routine remplace ces caract�res par des espaces.
			- Importation de fichiers .csv pour l'inscription aux tournois.
			    Les champs � donner sont par ordre de priorit�:
				Matricule Belge;  (SI donn�, l'inscription est faite � partir de PLAYER.DBF et FIDE.DBF
				Matricule Fide;   (SI donn�, l'inscription est faite � partir de FIDE.DBF et PLAYER.DBF
				Nom;              (Pas de Matricule national ni FIDE, les champs suivants devraient �tre remplis)
				Pr�nom;
				Elo National;     (0 ou absent == NON CLASSE)
				Date de Naissance;(format YYYYMMDD)
				Sexe;             (M par d�fault)
				Nationalit�;      (BEL par d�fault)
				N� de Club;
				Cat�gorie;
	Example:
		83224							(MOI)
		83224;							(avec ou sans virgules)
		;200018;						(Luc Winand)
		;;Marchal;Georges;1534;19440810;M;BEL;601;   (toujours MOI)
		;;Marchal;Georges;1534;19440810;;;601;       (et encore MOI avec valeurs par default)
		;;Nouveau;joueur;;19780101;;;601;2           (un nouveau joueur NC en Cat�gorie 2)
		;;Autre;Nouveau;1400;;;;;601;                (un nouveau avec un ELO estim� de 1400)
		;;Sebag;Marie;2452;FRA;F;19861015;;          (impossible: devrait donner le n� FIDE, mais comment v�rifier)
						

v4.11	- 18-10-2006	- Ne pas compter le BYE si la ronde n'est pas toute termin�e: il y avait
							une erreur dans la correction de la version 4.06, cela est corrig�.
							Dans cette version (et les suivantes) on ne comptabilisait pas le BYE ni les
							r�sultats suivants si TOUS les r�"sultats n'�taient pas entr�s. Avzec cette
							version, il suffit d'enregistrer UN r�sultat pour que le BYE soit comptabilis�.

v4.10	- 14-10-2006	- Modification du texte 'ne pas mettre ABSENT....'
						- Changement des 'Pr�f�rences': elles �taient toujours sauv�es m�me si l'on dit 'NON'
						- Apr�s une erreur d'ouverture, impossibilit� d'ouvrir un autre fichier.
						- Ne pas afficher les joueurs ABSENT lors du classement final
						- Ne pas autoriser ABSENT pour tournois ferm�s.
						- Tournoi FIDE: les joueurs NC apparaissent avec un Elo '0F' au lieu de '0N'
						- Tournois ferm�s double rondes: le fichier HTML ne reprenait que le premier tour.
						- Dans la fiche du joueur, affichage des Scores Ajust�s.
						- Recalcul complet du Bucholtz en tenant compte des parties non-jou�es.
						- !!! Le calcul du score ajust� se fait en attribuant qu'un demi point pour
							  les parties non jou�es (Forfait, Bye, Absent) afin de calculer le Bucholtz.
						  !!! Le bucholtz est la somme des scores ajust�s des adversaires pour les parties
							  qui ont �t� jou�es, plus la somme du bucholtz du joueur lui-m�me
							  pour les parties non jou�es (Forfait, Absent ou Bye).
						- Correction du d�partage par 'R�sultats Mutuels'


v4.09	- 21-08-2006	- Fichier ELO Belge: Mauvais calcul des parties Gagn�es,Perdues
						- Pour les joueurs �trangers sans cote Belge, il faut mettre la cote FIDE
						- Correction du Bucholtz, Median et Sonneborn Berger:
						    le calcul des scores ajust�s n'�tait pas juste.

v4.08	- 26-07-2006	- Bug dans la suppression de la virgule entre le nom et le pr�nom des
							joueurs issus du fichier FIDE.DBF. La derni�re lettre du nom �tait perdue.

v4.07	- 25-07-2006	- Ajout du SEXE pour les joueurs extraits du fichier FIDE.DBF

v4.06	- 28-06-2006	- Ne pas tester les joueurs selectionn�s pour faires les listes ELO,HTML,TXT
						- Probl�me de date de naissance avec fichiers FIDE
						- Suppression de la virgule entre le nom et le pr�nom en provenance du fichier FIDE
						- Ajout d'un club corrig�. (affichage du nouveau club)
						- Dor�navent les release n'auront plus que 4 caract�res (4.06, 4.07, 4.08, ...)

v4.05.11   - 21-06-2006	- Toujours un petit probl�me d'alignement dans les fichiers html: corrig�.
						- Pour l'interdiction d'envoi si le tournoi n'est pas termin�, il y avait une
							erreur dans le cas de match en AllerRetour.
						- Pour rappel, pour les matchs en Aller-Retour il faut donner le nombre de
							rondes sans tenir compte des matchs retour. Soit par example 9 rondes en Aller-Retour
							et PairTwo d�termine lui-m�me qu'il faudra jou� 18 parties. Mais le
							tournoi reste un tournoi en 9 rondes.

v4.05.10   - 20-06-2006	- Interdiction d'envoyer des r�sultats pour la cote ELO si tournoi non termin�.
							Il faut soit le terminer, soit modifier le nombre de rondes.
						- Memorisation du num�ro du premier tableau (FirstBoard) dans les donn�es du tournoi.
						- Bug dans l'affichage des nom de clubs lorque l'on travaille avec le pays 'NED',
							il lisait les clubs dans le fichier Clubs.txt au lieu de ClubsNed.txt.

v4.05.09   - 19-05-2006	- Correction de la date de naissance pour l'envoi des fichers FIDE. Si la 
							date de naissance n'est pas renseign�e dans le fichier .SWS, elle est
                            lue dans PLAYER.DBF, si le joueur n'est pas renseign� dans PLAYER (joueur �tranger)
							l'ANNEE de naissance est lue dans FIDE.DBF.

v4.05.08   - 16-05-2006 - Suppression dans 'Pr�f�rence' du bouton 'D�partage par default'. Il faut g�n�rer
                            soi-m�me les d�partages suivant les recommandations ede la FIDE et suivant 
							le type de tournoi. Ce bouton �tait g�n�rateur d'erreurs.
						- Avant la g�n�ration du fichier pour le calcul ELO BELGE,
							les matricules sont v�rifi�s par rapport � PLAYER.DBF, afin de v�rifier
							que tous les joueurs soient inscrits � la FEFB (sauf les �trangers). Un message
							est affich� si un joueur n'est pas en ordre.
						- Ajout des d�partages par syst�me KOYA pour les tournois ferm�s
						     (somme des points des adversaires qui ont marqu�s 50% des points) , 
							 Nbr.VICTOIRES (Tournois ferm�s ou Open Swuisse) et PERFORMANCE (pour les open).
						- Prise en compte des ExtraPoints pour calcul des points pour classement et appariement. Ces
						     Extras-Points permettent soit de faire un syst�me acc�l�r� en ajoutant des points � 
							 certains groupes de joueurs, puis en les retirant progressivement, soit mettre
							 une amende � un joueur (en retirant des points) � la fin d'un tournoi afin de le
							 d�class� (moins de points).
 						- Correction de la lecture des fichiers PLAYER et FIDE en m�moire (DELETED RECORDS).
 						- Les Help FRANCAIS et NEERLANDAIS ont �t� adapt�s.

v4.05.07   - 11-04-2006 - Modification de la g�n�ration des dates en cas de tournois Aller-Retour
						- Probl�me avec le changement de Pays pendant les inscriptions
						- Probl�me lors de l'ouverture d'un fichier qui ne se trouve pas dans le r�pertoire
							  courant ou dans le r�pertoire SWS.
						- Modification dans menu de Open(Ctrl+O) Save(Ctrl+S) et New(Ctrl+N)
						- Ajout de l'impression de la table de Berger dans le menu imprimer.
						- Si l'on donne un nom suivit d'un '*', le programme lit automatiquement
						      PLAYER.DBF sans devoir passer par le bouton lire. Par contre, il est
							  toujours possible de changer le contenu du nom pour effectuer la
							  recherche si le d�but �tait mauvais. Le nombre maximum de joueurs lus
							  passent de 1000 � 100.
						- Ne plus mettre syst�matiquement les joueurs �trangers avec les noirs.
						      C'�tait pour corriger une erreur de calcul ELO de chez Henrion,.
						- R�alignement de certains champs dans le fichier .html
						- Standardisation du texte dans le Menu Fichier ELO Belge,Fide,Hollandais
						- Adaptation des 'helps (FR,NL,EN)' pour mise en concordance avec les modifs.
						- Visibilit� du pays en entier, mais traitement uniquement du sigle (BEL BELGIQUE)

v4.05.06   - 02-02-2006 - Ajout de la nationalit� dans PLAYER.DBF. Ceci afin de pouvoir
                              mettre la VRAI nationalit� aux joueurs �trangers
							  qui jouent et qui sont afili�s en Belgique, notamment
							  pour les interclubs, mais aussi pour les frontaliers.
							  Le champs NOUV_MOD (4 caract�res) sera utilis� � cet effet.
							  Le 4me carat�re du champs indiquera si le joueur est frontalier
						      Ce 4me caract�re (+) ne sert que pour le calcul ELO des frontaliers
						- Recalcul des Points avant chaque affichage, car il y a
						      un bug non trouv�. Il m'a d�j� �t� rapport� que les points affich�s
							  ne correspondaient pas avec la r�alit�. Cela m'est arriv� aussi une
							  une fois sans bien comprendre la provenance de cet incident. 
							  Cela m'est arriv� lorsque j'ai entr� un mauvais r�sultat � une
							  ronde, puis appari� la ronde suivante, entr� les r�sultats de cette
							  derni�re ronde, et enfin corrig� le r�sultat de la ronde pr�c�dente
							  qui �tait �rron�. Mais je n'ai pas pu reproduire le ph�nom�ne par
							  la suite, c'est pourquoi je pr�f�re recalcul� les points � chaque
							  affichage et avant le sauvetage du fichier.
						- Lorsque le d�partage est exactement identique sur tous les tie-break,
						      PairTwo donnait un r�sultat au hazard. Il donne maintenant
							  le joueur avec l'ELO le plus �lev� en premier.
						- Lorsque l'on affiche un appariement dont les r�sultats ne sont pas 
						      encore entr�s, PairTwo affichait d�j� le point de BYE. Avec cette version,
							  cette erreur est corrig�e. Ce point sera acquis d�s qu'un r�sultat est entr�.
						- Nouveau Calcul de la Performance en tenant compte de la limite de 350 points.
						- Si un club est pr�c�d� d'une etoile '*' il n'est plus actif !!!
						- Ajout de N ou F apr�s la cote du joueur si tournoi FIDE
						- Correction .html si tournoi FIDE et ABSENT
						- Pour un tournoi FIDE, le fichier pour le calcul de l'ELO NATIONAL
						      doit contenir l'ELO national et par l'ELO FIDE.
						- Ajout de la version de PairTwo dans le fichier ELO Belge
						- Ne pas g�n�rer le fichier ELO BELGE si pas de r�sultats.

v4.05.05   - 25-11-2005 - Correction du calcul de nombre de + - = dans le fichier
                              destin� au calcul de l'ELO BELGE.

v4.05.04   - 19-11-2005 - Quelques ajustements dans la pr�sentation du classement g�n�ral
                              du fichier .html

v4.05.03   - 15-11-2005 - Dans le rapport vers fichier, 
                             les ABSENT et FORFAITS sont indiqu�s pour chaque rondes
						- Allocation en une seule fois de la m�moire pour PLAYER et FIDE
						- Correction d'un probl�me de lecture de PLAYER.DBF
						- Fichier ELO Belge: ligne de titre, ajout de la constante ' N�'
						- Fichier ELO Belge, Type De Tournoi: Ajout des tournois ferm�s en Aller-Retour
						- Fichier ELO Belge: ligne de controle, ajout de +nn=nn-nn comptabilisant
						      Le nombre de victoires, de nulles et de d�faites
							  Le nombre de nulle est EXACT (aaa contre bbb 1/2 - 1/2 --> 2 NULLES)
							  aaa contre bbb: 0 - 1/2 1 DEFAITE, 1 NULLE
							  Ceci afin d'�tre compatible avec le futur CalcImport
						- Dans les tournois FERME, suppression de la possibilit� de mettre
						      les joueurs ABSENTS ou FORFAITS car cela empeche l'appariement par table
							  de berger qui sont pr��tablis. Il faut absolument renseigner
							  la partie comme perdue par FORFAIT et non le joueur.
						- Dans les options classement, ajout affichage par RANK 
						      qui peu �tre est diff�rent de l'ELO dans le cas de tournois ferm�s.
						- Dans la toolbar, affichage par ELO et par RANK
						      Modification de la routine de tri RANK et ELO
							  Le classement ELO peut ne pas etre �gal au classement par RANK,
							  notament dans les tournois ferm�s, o� le Rank est calcul� soit
							  manuellement, soit automatiquement, soit libre.
						- Interdiction de modifier le Rank apr�s la ronde 1
						- Fichiers .html: correction des Pools pour les tournois ferm�s,
						      notamment lorsque le nombre de joueurs est impair.
						- Dans la page .html, mettre le bon n� de Version de PairTwo au lieu de constante.

v4.05.02   - 07/11/2005 - Bug dans la lecture des joueurs FIDE qui ne sont pas dans PLAYER.DBF

v4.05.01   - 30-10-2005	- Les titres sur l'�cran et dans les pages imprim�es sont en gras 
						- Les Infos du .html un peu mieux (avis personnel)
						- Menu Appariement/Controler le rank: gris� si le tournoi est commenc�.
						- Fichier ELOBELGE tri� par POINTS avant la 4.05 sinon par RANK
						                   joueurs sans matricules: 5 espaces au lieur de 5 ZEROS.

v4.05	   - 05-10-2005 - Chargement des Matricule et Noms en memoire, pour g�rer un index
                             des  fichiers PLAYER.DBF et FIDE.DBF
						- Tri des absents par ordre alphab�tique
						- Forms de Resultats: modifications et ajout d'une case ABSENCE
						- Modification du HELP en html FRA NED et ENG
						- Appariements: le r�sultat est maintenant entre les joueurs (plus � la fin)
						- D�partage: ne tient plus compte de la ronde en cours (appari�e et pas jou�e).
						- D�partage Bucholtz: corrig� (les scores ajust�s �taient mal calcul�s), en effet
						     chaque partie non jou�es (Bye, GainFF, perte FF, absent) vaut 1/2 points,
						- Suppression de la boite de dialogue 'Choix du Bucholtz'.
						- Generation des fichiers .html pour publication sur web
						    Les fichiers sont xxx.html, xxx.CLG.html, xxx.Rxx.html, xxx.APT.html xxx.GRI.html
							CLG=Classement General
							Rxx=Ronde xx (r�sultats)
							Pxx=Pool xx (tableau de la Pool xx)
							APT=Appariement par Table
							GRI=Grille am�ricaine
							Si les fichiers 'PairTwoClub.jpg' et 'PairTwoFederation.jpg' sont pr�sents, il seront incorpor�s
							  dans le fichier .html, rubrique 'Infos'  en vue de piblmication sur le WEB. 
							  Ne pas oublier de transferer aussi ces fichiers sur le WED. 
							  Sinon le nom du club organisateur  est affich� ainsi que 'F.E.F.B' par defaut..
						- Classement forme Appariement: 
							Non appari� = ' ' au lieu de '0'
							Victoire par Forfait = '+' et pas '1'
							D�faite par forfait  = '-' et pas '0'
						- Pairing M�thode: defaut=Numero ELO (Ranking)
						- Memorisation du dernier repertoire des fichiers .sws
						- Correction de l'utilisation du Help 
						- Oubli de 0-1/2 et 1/2-0 dans les 'dll' NED et ENG
						- Suppression boite de dialogue 'Paste Player' (jamais utilis�e)
						- Correction de l'attribution des cat�gories
						- Correction de l'alignement des sorties en format .txt
						- Ajout de Tous Absent et Tous Present dans le menu (Shft-Ctrl-A et Shft-Ctrl-P)
						- Ajout dans le menu Apparier de 'Controler le Rank' pour recalculer la Ranking Liste.
							Cela permet de corriger �ventuellement les erreurs de Ranking de PairTwo.
						- M�me les tournois en Pool ont une Rank Liste (ce qui n'�taient pas le cas)

v4.04.04   - 18-10-2005 - Correction affichage r�sultats si Absent.

v4.04.03   - 17-10-2005 - Utilisation du nouveau Help en html

v4.04.02   - 03-10-2005 - Dans appariement, ajout des Absents et Forfaits.

v4.04.01   - 19-09-2005	- Correction du passage de la ronde 1 � la 2 puis retour � la 1 (F6-F5-F6)
						- Mise � jour du Num�ro de version dans la boite de dialogue '� propos de'
						- Tournoi en POOL et appariement avec cat�gories s�par�es :
							Interligne apr�s changement de cat�gorie dans classement (sauf ALPHA et RANK)
							Interligne dans classement 'forme appariement'
							Tableaux s�par�s dans le classement 'forme tableau'. De plus, il y a maintenant
							  un tableau par cat�gorie.
							Il faut que toutes les Pools poss�dent le m�me nombre de joueurs.
						- Dans ELOBELGE, mettre le joueur �tranger avec NOIR et son adversaire avec BLANC
						     Un �tranger est un joueur avec matricule 00000
						- Modification du fichier des resultats de la FIDE (nouveau format � partir du 1/10/2005)
						     Ecriture d'un nouveau module en format Texte (et non plus DBF).
						- Tempo par default: 40c/2h + 1h QPF (et pas 40c/1h)
						- Quelques ajustements

v4.04	 - 18-09-2005	- TieBreak par default: CUMULATIF + BUCHOLTZ MEDIAN + BUCHOLTZ (tournoi SWISS)
						- Lors de la lecture de la liste des joueurs, change le curseur en sablier.
						- Suppression dans le menu des fonction 'CUT,COPY,PASTE' des joueurs. 
						  (incompatibilt� entre versions 16 bits (Windows 3.11) et 32 bits (WIN 98, 2000, XP)
						- Ajout du resultat 0-1/2 et 1/2-0 dans la boite de dialogue lorsque l'on fait DOUBLE CLICK
						- Mettre la premi�re lettre du nom_prenom en majuscule si preceder d'un espace.
						- Tournois SWISS et AMERICAIN: ajout du mode ALLER-RETOUR. 
						    Il faut d�finir le nombre normal de ronde. 
							Dans la d�finition du tournoi, 
							cliquer sur 'TYPE' et Cocher ALLER-RETOUR.
							Le programme doublera automatiquement le nombre de rondes pour faire les appariements. 
							L'appariement 'pair' sera le m�me que 
							l'appariement 'impair' mais avec les couleurs invers�es.
						- Lors de la lecture d'un matricule, si le matricule est aussi FIDE et que le fichier 
						    FIDE.DBF n'est pas pr�sent, affichage de 'Matricule Inconnu', ce qui est une erreur.
							Le matricule est maintenabnt affich� sans les information en provenance de FIDE.DBF
						- Ajout d'une touche (Ctrl F) pour marquer le joueur FORFAIT. Egalement dans le menu.
						- Les joueurs absents sont marqu�s 'A' et plus '*'
						- Les joueurs Forfaits sont marqu�s 'F'.
						- Ajout d'un bouton 'Mettre Tous Present' (sauf les FORFAITS)
						- Tempo par default: 40c/1h + 1h QPF (et pas 30' QPF)
						- Ajustement de la liste des joueurs en insertion. Certains pays (SWE, HUN, ...) faisaient
						    que les cotes �taient 'd�salign�es' � cause de la taille des caract�res.
						- Dans les appariements, ne mettre le 'N' ou 'F' (type de la cote National ou Fide)
						    que si on a demander la cote la + haute, afin de diff�rencier.

v4.03.02 - 16-08-2005	- Lecture des joueurs par leur nom si on rentre le nom suivi de *.
						- Si ELONAT=0 afficher (0 N) et pas (0 F).
						- Probl�me de mise � jour manuelle de la cat�gorie.
						- Pour avoir un bon alignement dans les fichiers 'texte', il faut aller dans:
							Options, Options Texte, S�parateur Text = Espaces
						- Pour pouvoir �tre charg� dans Excel, il faut TABULATEUR ou VIRGULE.

v4.03.03 - 20-08-2005	- Apr�s un appariement, changement du titre de la fenetre principale.
						- Probl�me affichage du titre 'Club ou Klub' en Anglais et Neerlandais
						- Acceptation des r�sultats 0-1/2 et 1/2-0
						- Bug dans la gestion en m�moire des clubs.
						- Lorsque le club n'existe pas, ajout dans CLUBS.TXT + en memoire
						- Lors de la recherche par nom*, il manque le titre du joueur (f,m,g,...)

v4.03.01 - 13-08-2005	- Rapport en fichier texte: bug dans affichage ELO (3 chars au lieur de 4).

v4.03	 - 07-08-2005	- Lecture des fichiers PLAYER.DBF et FIDE.DBF par mes classes. Plus de OLE
						    il y avait interference avec CHess Manager (BDE de BORLAND)
						- Recherche des fichiers .sws dans le repertoire courant par default.

v4.02	 - 02-08-2005	- Autorisation des numeros de club � jusque 5 caract�res
						- Ajout d'une boite de dialogue pour d�finir les cat�gories par ELO
						- Autorisation d'entrer des joueurs sans matricule (on entre � partir du nom)
						- Affichage de la cote utilis�e dans les r�sultats (N ou F)
						- Adaptation de p2html (maintenant avec le package)
						
v4.01.01 - 31-07-2005	- Oubli de m�morisation du DRIVE (c:\) dans le pathname des fichiers *.DBF
						- S�paration de la recherche des fichiers PLAYER.DBF et FIDE.DBF

v4.01	 - 27-07-2005	- Demande de sauvetage du fichier en cours lorsque l'on quitte PairTwo.
						- Correction du changement de la cat�gorie
						- Lecture du fichier PLAYER.DBF avec des ordres 'SQL' (OLE DBF)
						- Obligation d'avoir le fichier PLAYER.DBF pour cr�er un tournoi
						- Mettre le fichier FIDE.DBF dans le m�me r�pertoire que PLAYER
						- Recherche automatique de l'elo FIDE et COUNTRY dans FIDE.DBF
						- Reinitialiser le fichier 'pairtwo.ini'
						- Remplac� KO par QPF
						- Lecture des fichiers CLUBS.TXT, CLUBSNED.TXT et COUNTRY.TXT en memoire
						- Augmentation de l'affichage du nom du club de 13 � 16 caract�res
						- Bug dans le sauvetage des fichiers (2 * le repertoire dans certains cas)

v4.00.02 - 18-07-2005	- Correction du Refresh. Correction des dates des rondes.
						- L�g�res modif dans les resources NL
						- Correction fonctionnement 'matricule inconnu'

v4.00.01 - 24-06-2005	- Gestion de Player.Dbf + Refresh dans l'inscription des joueurs.

v4.00	 - 2005         - Modification de PairTwo 3.07 pour tourner en 32 bits.
						- Gestion des matricules, correction de quelques bugs
Email: g_marchal@voo.be
