Installation of PAIRTWO :
PairTwo will run under Windows 3.1 and 3.11 ; Windows NT ; Windows 95, 
Windows 98 and other compatible operating systems, such as OS/2.
Run the Setup program as indicated on the floppy-disc.