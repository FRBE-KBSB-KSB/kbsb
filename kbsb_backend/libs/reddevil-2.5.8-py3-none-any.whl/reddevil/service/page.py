# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
log = logging.getLogger(__name__)

import uuid
from datetime import datetime, timezone, date
from slugify import slugify
from typing import List, cast
from reddevil.common import (
    encode_model,
    hash_password,
)
from reddevil.models.md_page import (
    PageDetailedOut,
    PageIn,
    PageOut,
    PageList,
    PageUpdate,
    Page,
    PageContent,
    PageI18nFields
)
from reddevil.crud.db_page import DbPage

log = logging.getLogger('reddevil')

async def createPage(d: PageIn) -> str:
    """
    create a new Page returning its id
    """
    pf = PageI18nFields(body='', intro='', title=d.name)
    tsnow = datetime.now(tz=timezone.utc)
    dd = d.dict()
    dd['layout'] = 'default'
    dd['creationtime'] = tsnow
    dd['enabled'] = False
    dd['expirationdate'] = ''
    dd['id'] = str(uuid.uuid4())
    dd['i18n'] =  {
        'default': pf.dict(),
        d.locale: pf.dict(),
    }
    dd['languages'] = [d.locale]
    dd['modificationtime'] = tsnow
    dd['owner'] = ''
    dd['publicationdate'] = ''
    dd['slug'] = slugify(d.name)
    return await DbPage.add(dd)

async def deletePage(id: str) -> None:
    await DbPage.delete(id)

async def getPage(id: str, options: dict= {}) -> Page:
    """
    get the page 
    """
    validator = options.pop('_class', PageDetailedOut)
    filter = dict(id=id, **options)
    pdict = await DbPage.find_single(filter)
    pdict['active'] = isactive(pdict)
    return cast(Page, encode_model(pdict, validator))

async def getPageBySlug(slug: str, options: dict= {}) -> Page:
    """
    get the page 
    """
    validator = options.pop('_class', PageDetailedOut)
    filter = dict(slug=slug, **options)
    pdict = await DbPage.find_single(filter)
    pdict['active'] = isactive(pdict)
    return cast(Page, encode_model(pdict, validator))


async def getPages(options: dict={}) -> PageList:
    """
    get all the pages
    """
    validator = options.pop('_class', PageOut)
    docs = await DbPage.find_multiple(options)
    for pdict in docs:
        pdict['active'] = isactive(pdict)
    pages = [encode_model(pdict, validator) for pdict in docs]
    return PageList(pages=pages)    

async def updatePage(id: str, d: PageUpdate) -> PageDetailedOut:
    """
    update a page
    """
    dd = d.dict(exclude_unset=True)
    pdict = await DbPage.update(id, dd)
    pdict['active'] = isactive(pdict)
    return cast(PageDetailedOut, encode_model(pdict, PageDetailedOut))

# async def getActiveArticles(token: str=None) -> ArticleListOut:
#     """
#     get all the pages
#     """
#     dl = await DbPage.find_multiple({
#         'doctype': 'article',
#         'enabled': True,
#         '_fieldlist': ["creationtime", "enabled", "expirationdate", 
#             "i18n", "name", "modificationtime", "publicationdate", 'slug'],
#         'publicationdate': {'$ne': ""},
#     })
#     ap = [x for x in dl if isactive(x)]
#     ap = sorted(ap, key=lambda x: x['publicationdate'], reverse=True)
#     return ArticleListOut(articles=ap)

def isactive(dd: dict) -> bool:
    """
    checks whether a page is active
    """
    if not dd.get('enabled'):
        return False
    p = dd['publicationdate']
    e = dd['expirationdate']
    published = p and (date.fromisoformat(p) <= date.today())
    expired = e and (date.fromisoformat(e) < date.today())
    return bool( published and not expired)

# async def backupPages() -> List[PageOptional]:
#     """
#     dumps all pages records with full details
#     """
#     docs =  await DbPage.find_multiple({
#         '_fieldlist': {}
#     })
#     return [encode_page(d, PageOptional) for d in docs]

# async def restorePages(docs: List[dict]) -> None:
#     """
#     dumps all pages records with full details
#     """
#     await DbPage.restore(docs)    