# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

import logging

log = logging.getLogger("reddevil")

from fastapi import HTTPException, Depends, status, Response, FastAPI
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List
from reddevil.common import (
    get_app,
    RdException,
)
from reddevil.service.account import (
    add_account,
    delete_account,
    get_account,
    get_accounts,
    update_account,
    get_token,
    validate_token,
    login,
)
from reddevil.common import (
    bearer_schema,
)
from reddevil.models.md_account import (
    AccountIn,
    AccountListOut,
    AccountLogin,
    AccountOut,
    AccountUpdate,
)

app = get_app()


# crud 


@app.get("/api/v1/account", response_model=AccountListOut)
async def api_getAccounts(auth: HTTPAuthorizationCredentials = Depends(bearer_schema)):
    try:
        await validate_token(auth)
        return await get_accounts()
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception as e:
        log.exception("Api_get_account failed")
        raise HTTPException(500, "ApiGetAccountsFailed")


@app.post("/api/v1/account", response_model=str)
async def api_addAccount(
    ac: AccountIn, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await add_account(ac)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception as e:
        log.exception("Api_add_account failed")
        raise HTTPException(500, "ApiCreateEventFailed")


@app.get("/api/v1/account/{account_id}", response_model=AccountOut)
async def api_getAccount(
    account_id, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await get_account(account_id)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception as e:
        log.exception("Api_get_account failed")
        raise HTTPException(500, "ApiGetAccountFailed")


@app.delete("/api/v1/account/{account_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_deleteAccount(
    account_id: str, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await delete_account(account_id)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception as e:
        log.exception("Api_delete_account failed")
        raise HTTPException(500, "ApiDeleteAccountFailed")


@app.put("/api/v1/account/{account_id}", response_model=AccountOut)
async def api_updatAccount(
    account_id: str,
    au: AccountIn,
    auth: HTTPAuthorizationCredentials = Depends(bearer_schema),
):
    try:
        await validate_token(auth)
        return await update_account(account_id, au)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception as e:
        log.exception("Api_update_account failed")
        raise HTTPException(500, "ApiUpdateAccountFailed")


# actions by the user


@app.post("/api/v1/login", response_model=str)
async def api_login(li: AccountLogin):
    """
    login in an account, returning an authorisation token
    """
    try:
        return await login(li)
    except RdException as e:
        raise HTTPException(e.status_code, e.description)
    except Exception as e:
        log.exception("Api_login failed")
        raise HTTPException(500, "ApiLoginFailed")


# @app.post('/api/v1/command/accountregister', status_code=status.HTTP_204_NO_CONTENT, response_class=Response)
# async def api_registerAccount(ac: AccountIn):
#     """
#     create an new account, sending a confirm email
#     """
#     try:
#         await registerAccount(ac)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception('Application error registerAccount')
#         raise HTTPException(500, "ApiRegisterAccountFailed")

# @app.post('/api/accountconfirm', status_code=status.HTTP_204_NO_CONTENT)
# async def api_confirmAccount(ac: AccountConfirm):
#     """
#     confirm the valid email of an account
#     """
#     try:
#         await confirmAccount(ac)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception('Api_confirm_account failed')
#         raise HTTPException(500, "ApiConfirmAccountFailed")

# @app.put('/api/accountpassword', response_model=str)
# async def api_updatePassword(passwordupdate: AccountPasswordUpdate,
#     auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
# ):
#     """
#     update the password of an account, return a new token
#     """
#     try:
#         await validate_token(auth)
#         await updatePassword(passwordupdate)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception('Api_update_password failed')
#         raise HTTPException(500, "ApiUpdatePasswordFailed")

# @app.post('/api/accountresetpassword', status_code=status.HTTP_204_NO_CONTENT)
# async def api_resetPassword(pwreset: AccountPasswordReset):
#     """
#     ask for a password reset of the account, by sending a password reset email
#     """
#     try:
#         await resetPassword(pwreset)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception('Api_reset_password failed')
#         raise HTTPException(500, "ApiResetPasswordFailed")

# @app.post('/api/accountconfirmpassword')
# async def api_confirmPassword(pwconfirm: AccountPasswordConfirm,
#     auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
# ):
#     """
#     confirms the password reset email
#     """
#     try:
#         await confirmPassword(pwconfirm)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception('Api_confirm_password failed')
#         raise HTTPException(500, "ApiConfirmPasswordFailed")
