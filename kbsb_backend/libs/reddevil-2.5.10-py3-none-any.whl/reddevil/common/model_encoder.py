# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from typing import Type, cast
from reddevil.common import RdInternalServerError
from pydantic import BaseModel

log = logging.getLogger("reddevil")

def encode_model( e: dict, validator_class: Type[BaseModel]) -> BaseModel:
    """
    validates and encodes a result dict as a validator class
    """
    # log.info(f'encoding a validating {validator_class}')
    try:
        eo = validator_class(**e)  
    except Exception:
        log.exception(f'cannot encode model {validator_class}')
        raise RdInternalServerError(description=f'CannotEncode{validator_class}')
    return eo
