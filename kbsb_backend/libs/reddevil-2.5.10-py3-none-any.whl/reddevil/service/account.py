# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import uuid
import asyncio

from jose import JWTError, ExpiredSignatureError
from fastapi.security import HTTPAuthorizationCredentials
from google.oauth2 import id_token
from google.auth.transport import requests
from datetime import datetime, timedelta
from typing import Optional, cast, List

from reddevil.common import (
    encode_model,
    get_settings,
    hash_password,
    jwt_encode,
    jwt_getunverifiedpayload,
    jwt_verify,
    verify_password,
    RdBadRequest,
    RdNotAuthorized,
    RdNotFound,
)
from reddevil.models.md_account import (
    Account,
    AccountDetailedOut,
    AccountIn,
    AccountListOut,
    AccountLogin,
    AccountOut,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    AccountRequest,
    AccountRequestType,
    AccountRequestVerification,
    AccountUpdate,
    LoginType,
)
from reddevil.db.db_account import DbAccount, DbAccountRequest

log = logging.getLogger("reddevil")


async def add_account(d: AccountIn) -> str:
    """
    add a new Account
    """
    assert d.password is not None
    dd = d.dict()
    pw = dd.pop("password", "")
    dd["id"] = d.id
    dd["verified"] = False
    dd["groups"] = []
    dd["logintype"] = d.logintype
    dd["enabled"] = d.enabled
    dd["tokensalt"] = str(uuid.uuid1())
    dd["hashed_password"] = hash_password(pw or "***")
    id = await DbAccount.add(dd)
    return id


async def delete_account(id: str) -> None:
    """
    delete the account
    """
    await DbAccount.delete(id)


async def get_account(id: str, options: dict = {}) -> Account:
    """
    get the account, AccountOut is default validator
    """
    validator = options.pop("_class", AccountOut)
    filter = dict(id=id, **options)
    adict = await DbAccount.find_single(filter)
    return cast(Account, encode_model(adict, validator))


async def get_accounts(options: dict = {}) -> AccountListOut:
    """
    get all account
    """
    validator = options.pop("_class", AccountOut)
    accs = await DbAccount.find_multiple(options)
    accounts = [cast(AccountOut, encode_model(a, validator)) for a in accs]
    return AccountListOut(accounts=accounts)


async def update_account(id: str, d: AccountUpdate, options: dict = {}) -> AccountOut:
    """
    update a Account, AccountOut is default validator for return object
    """
    # TODO import dates as isoformat string
    dd = d.dict(exclude_unset=True)
    udd = await DbAccount.update(id, dd, options)
    return cast(AccountOut, encode_model(udd, AccountOut))


# business logic


async def account_request_verification(arv: AccountRequestVerification) -> None:
    """
    verify returned email verification
    """
    ardict = await DbAccountRequest.find_single(
        {"id": arv.id, "username": arv.username}
    )
    ar = cast(AccountRequest, encode_model(ardict, AccountRequest))
    assert ar.expiry_time and ar.username
    if ar.reason != arv.reason:
        raise RdBadRequest(description="WrongReason")
    if ar.expiry_time < datetime.utcnow():
        raise RdBadRequest(description="VerificationRequestExpired")
    # the verification succeeded, drop the request and update the account
    await DbAccountRequest.delete(arv.id)
    hashed_password = hash_password(arv.password)
    await update_account(
        ar.username,
        AccountUpdate(),
        {"$set": {"verified": True, "hashed_password": hashed_password}},
    )
    log.info(f"AccountRequest {arv.reason} for {ar.username} successfully processed.")


async def change_password(apu: AccountPasswordUpdate, checkold=True) -> None:
    """
    change password
    """
    try:
        acc = await get_account(
            apu.username,
            {"_class": Account, "_fieldlist": ["hashed_password", "tokensalt"]},
        )
        assert acc.hashed_password
    except RdNotFound:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    verified = verify_password(apu.oldpassword, acc.hashed_password)
    if checkold and not verified:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    hashed_password = hash_password(apu.newpassword)
    await update_account(
        apu.username,
        AccountUpdate(),
        {
            "$set": {
                "hashed_password": hashed_password,
            }
        },
    )
    log.info(f"Account {apu.username} password changed.")


async def check_accountid(id: str) -> bool:
    """
    check if account id already exists
    """
    try:
        await get_account(id)
        return True
    except RdNotFound:
        return False


async def confirm_password(pwc: AccountPasswordConfirm) -> str:
    """
    confirms a newly reset password, returning a new authorisation token
    """
    settings = get_settings()
    hashed_password = hash_password(pwc.newpassword)
    await update_account(
        pwc.username, AccountUpdate(), {"$set": {"hashed_password": hashed_password}}
    )
    acc = await get_account(
        pwc.username,
        {"_class": Account, "_fieldlist": ["hashed_password", "tokensalt"]},
    )
    token = await get_token(acc, timedelta(minutes=settings.TOKEN["timeout"]))
    return token


async def get_token(acc: Account, duration: timedelta, invalidate: bool = True) -> str:
    """
    gets a new JWT token for a user
    :param acc: an Account
    :param invalidate: invalidate the existing tokens by changing the salt
    :return: return the newly created token
    """
    id = acc.id
    assert id
    if invalidate or acc.tokensalt is None:
        tokensalt = str(uuid.uuid1())
        await update_account(id, AccountUpdate(), {"$set": {"tokensalt": tokensalt}})
    else:
        tokensalt = acc.tokensalt
        await asyncio.sleep(0)  # a noop await
    payload = {"sub": acc.id, "exp": datetime.utcnow() + duration}
    return jwt_encode(payload, tokensalt)


async def login(al: AccountLogin) -> str:
    """
    login and returns a newly create JWT token
    """
    settings = get_settings()
    if al.logintype == LoginType.google:
        assert al.token is not None
        token = al.token
        try:
            idinfo = id_token.verify_oauth2_token(
                token, requests.Request(), settings.GOOGLE_CLIENT_ID
            )
        except ValueError:
            raise RdNotAuthorized(description="InvalidGoogleToken")
        if idinfo["iss"] not in ["accounts.google.com", "https://accounts.google.com"]:
            raise RdNotAuthorized(description="WrongAuthIssuer")
        if (
            settings.GOOGLE_LOGIN_DOMAINS
            and idinfo["hd"] not in settings.GOOGLE_LOGIN_DOMAINS
        ):
            raise RdNotAuthorized(description="WrongGoogleDomain")
        try:
            acc = await get_account(
                idinfo["sub"],
                {
                    "_class": Account,
                    "_fieldlist": ["id", "tokensalt"],
                },
            )
        except RdNotFound:
            log.info(f"account not found creating ...")
            accdict = {
                "domain": idinfo["hd"],
                "email": idinfo["email"],
                "verified": idinfo["email_verified"],
                "enabled": True,
                "id": idinfo["sub"],
                "locale": idinfo["locale"],
                "logintype": LoginType.google,
            }
            id = await DbAccount.add(accdict)
            acc = await get_account(
                idinfo["sub"],
                {
                    "_class": Account,
                    "_fieldlist": ["id", "tokensalt"],
                },
            )
    elif al.logintype == LoginType.email:
        assert al.password
        if al.username is None:
            raise RdBadRequest(description="MissingUsername")
        try:
            acc = await get_account(
                al.username,
                {"_class": Account, "_fieldlist": ["hashed_password", "tokensalt"]},
            )
            assert acc.hashed_password
        except RdNotFound:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
        verified = False
        try:
            verified = verify_password(al.password, acc.hashed_password)
        except Exception as e:
            log.exception("cannot process verify password")
        if not verified:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
    else:
        raise RdBadRequest(description="InvalidLoginType")
    token = await get_token(acc, timedelta(minutes=settings.TOKEN["timeout"]))
    return token


async def validate_token(auth: HTTPAuthorizationCredentials) -> Account:
    """
    checks a JWT token for validity
    return an Account if the token is correctly validated
    if token is not valid the function :
        - either returns None
        - either raise RdNotAuthorized if raising is set
    """
    settings = get_settings()
    token = auth.credentials if auth else None
    if not token:
        raise RdNotAuthorized(description="MissingToken")
    if settings.TOKEN.get("nocheck"):
        await asyncio.sleep(0)
    try:
        payload = jwt_getunverifiedpayload(token)
    except:
        log.exception("invalid token without verification")
        raise RdNotAuthorized(description="BadToken")
    username = payload.get("sub")
    try:
        acc = await get_account(
            username,
            {
                "_class": Account,
                "_fieldlist": ["tokensalt"],
            },
        )
    except RdNotFound:
        raise RdNotAuthorized(description="BadToken")
    try:
        jwt_verify(token, settings.JWT_SECRET + acc.tokensalt)
    except JWTError:
        raise RdNotAuthorized(description="BadToken")
    except ExpiredSignatureError:
        log.debug("JWT Error")
        raise RdNotAuthorized(description="TokenExpired")
    return acc
