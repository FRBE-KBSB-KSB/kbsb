import pytest, json
from datetime import datetime
from starlette.testclient import TestClient
from unittest.mock import AsyncMock, patch
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from reddevil.models.md_account import AccountLogin, LoginType
from reddevil.common import RdNotAuthorized, RdException
from demotestapp import app

# @pytest.fixture
# def acclist():
#     return AccountList(accounts=[
#         AccountBasicOut(
#             email = 'email1@email1.com',
#             first_name = 'First1',
#             last_name = 'Last1',
#             username = 'User1',
#         ),
#         AccountBasicOut(
#             email = 'email2@email2.com',
#             first_name = 'First2',
#             last_name = 'Last2',
#             username = 'User2',
#         )
#     ])

# @pytest.fixture
# def accin():
#     return {
#         'logintype': 'email',
#         'password': 'Password',
#         'username': 'User'
#     }

# @pytest.fixture
# def accout():
#     return {
#         'creationtime': '2020-07-27T10:45:51Z',
#         'email': 'email@email.com',
#         'email_verified': True,
#         'enabled': True,
#         'first_name': 'First',
#         'last_name': 'Last',
#         'locale': 'nl',
#         'logintype': 'email',
#         'modificationtime': '2020-07-27T10:45:51Z',
#         'username': 'User',
#     }

# @pytest.fixture
# def accup():
#     return {
#         'first_name': 'Firster name',
#     }


# @pytest.fixture
# def acc_rights():
#     return AccountRights(
#         groups= 'group 1',
#         scopes= 'scope1',
#         username= 'User',
#     )

# @patch('talistro_election.api.api_account.get_account')
# def test_get_accounts(get_account: AsyncMock, accout):
#     client = TestClient(app)
#     get_account.return_value = accout
#     resp = client.get("api/account/1234")
#     reply = resp.json()
#     assert resp.status_code == 200
#     assert 'first_name' in reply
#     assert reply['first_name'] == 'First'

# @patch('talistro_election.api.api_account.add_account')
# def test_add_account(add_account: AsyncMock, accin):
#     client = TestClient(app)
#     add_account.return_value = "1234"
#     resp = client.post("/api/account", json=accin)
#     reply = resp.json()
#     assert resp.status_code == 200

# @patch('talistro_election.api.api_account.get_accounts')
# def test_get_account(get_accounts: AsyncMock, acclist):
#     client = TestClient(app)
#     get_accounts.return_value = acclist
#     resp = client.get("/api/account")
#     reply = resp.json()
#     assert resp.status_code == 200
#     assert 'accounts' in reply
#     accounts = reply['accounts']
#     assert len(accounts) == 2
#     assert accounts[0]["username"] == "User1"

# @patch('talistro_election.api.api_account.validate_token')
# @patch('talistro_election.api.api_account.delete_account')
# def test_delete_account(delete_account: AsyncMock,
#         m_validate_token: AsyncMock, acc_rights):
#     client = TestClient(app)
#     m_validate_token.return_value = acc_rights
#     resp = client.delete("/api/account/1234")
#     assert resp.status_code == 204

# @patch('talistro_election.api.api_account.validate_token')
# @patch('talistro_election.api.api_account.update_account')
# def test_update_account(update_account: AsyncMock,
#         m_validate_token: AsyncMock, acc_rights, accout, accup):
#     client = TestClient(app)
#     m_validate_token.return_value = acc_rights
#     update_account.return_value = accout
#     resp = client.put("/api/account/1234", json = accup)
#     reply = resp.json()
#     assert resp.status_code == 200
#     assert 'last_name' in reply
#     lastname = reply['last_name']
#     assert lastname == "Last"


@patch("reddevil.api.api_account.login")
def test_login(login: AsyncMock):
    client = TestClient(app)
    login.return_value = "1234"
    resp = client.post(
        "/api/accountlogin",
        json={
            "email": "a@b",
            "first_name": "Julius",
            "last_name": "Caesar",
            "logintype": LoginType.email,
            "id": "julius.caeser",
            "password": "secret",
        },
    )
    reply = resp.json()
    assert resp.status_code == 200


@patch("reddevil.api.api_account.login")
def test_login_failed(login: AsyncMock):
    client = TestClient(app)
    login.side_effect = RdNotAuthorized(description="Yuck")
    rc = client.post(
        "/api/accountlogin",
        json={
            "email": "a@b",
            "first_name": "Julius",
            "last_name": "Caesar",
            "logintype": LoginType.email,
            "id": "julius.caeser",
            "password": "secret",
        },
    )
    assert rc.status_code == 401
    err = json.loads(rc.text)
    assert err["detail"] == "Yuck"


# @patch('talistro_election.api.api_account.validate_token')
# @patch('talistro_election.api.api_account.change_password')
# def test_change_password(m_cpw: AsyncMock, m_validate_token: AsyncMock):
#     client = TestClient(app)
#     resp = client.put("/api/account/1234/password", json= {
#         'old_password': 'oldpw',
#         'new_password': 'newpw',
#     })
#     assert resp.status_code == 200
#     m_cpw.assert_awaited()
#     m_cpw.assert_awaited_with(
#         '1234',
#         'oldpw',
#         'newpw'
#     )

# @patch('talistro_election.api.api_account.request_reset_password')
# def test_reset_password(m_reset_pw: AsyncMock):
#     client = TestClient(app)
#     resp = client.post("/api/resetaccount", json={
#         'email': 'email@mail.com'
#     })
#     assert resp.status_code == 200
#     m_reset_pw.assert_awaited()
#     m_reset_pw.assert_awaited_with('email@mail.com')

# @patch('talistro_election.api.api_account.set_password')
# def test_set_password(m_set_pw: AsyncMock):
#     client = TestClient(app)
#     resp = client.post("/api/password", json={
#         'token': 'token',
#         'new_password': 'newpw'
#     })
#     assert resp.status_code == 200
#     m_set_pw.assert_awaited()
#     m_set_pw.assert_awaited_with('token', 'newpw')
