# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019


import pytest

from datetime import datetime

from reddevil.models.md_account import (
    Account,
    AccountIn,
    AccountLogin,
    AccountOut,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    AccountRequest,
    AccountRequestEmailVerification,
    AccountRequestPasswordReset,
    AccountUpdate,
    LoginType,
)


@pytest.fixture
def acc1():
    return Account(
        domain='dom1',
        email='a@b.cd',
        email_verified=True,
        enabled=True,
        first_name='Julius',
        groups=[], 
        hashed_password='pw1',
        id='julius.caesar',
        last_name='Caesar',
        locale = 'nl',
        logintype=LoginType.email,
        password_expirationtime=datetime(2000,1,1),
        roles=[], 
        tokensalt='Preuteleute',
        xtra={},
        _creationtime=datetime(2020,1,1),
        _documenttype="Account", 
        _modificationtime=datetime(2020,4,15), 
    )

@pytest.fixture
def acc2():
    return Account(
        domain='dom2',
        email='ff@b.cd',
        email_verified=True,
        enabled=True,
        first_name='Freddy',
        groups=[], 
        hashed_password='pw2',
        id='freddy.devadder',
        last_name='Devadder',
        locale = 'nl',
        logintype=LoginType.google,
        password_expirationtime=datetime(2000,3,20),
        roles=[], 
        tokensalt=None,
        xtra={},
        _creationtime=datetime(2020,2,1),
        _documenttype="Account", 
        _modificationtime=datetime(2020,4,16),         
    )

@pytest.fixture
def accin1():
    return AccountIn(
        email='a@b.c', 
        first_name='Jimi',
        last_name = 'Hendrix',
        logintype = LoginType.email,
        id = 'jimi.hendrix',
        password = 'secret',
    )

@pytest.fixture
def acclogin1():
    return AccountLogin(
        logintype=LoginType.email,
        password='secret', 
        username='user1'
    )

@pytest.fixture
def accpu1():
    return AccountPasswordUpdate(
        newpassword='np',
        oldpassword='op',
        username='users1'
    )

@pytest.fixture
def accpwc1():
    return AccountPasswordConfirm(
        email='a@b',
        newpassword='np1',
        username='user1',
        token='098765'
    )

@pytest.fixture
def accemv1():
    return AccountRequestEmailVerification(
        id='1234',
        username='user1',
        reason='reason1'
    )


from reddevil.models.md_template import (
    TemplateRendered,
)

@pytest.fixture
def tmprnd():
    return TemplateRendered(
        content='content1',
        name='name1',
        title='title1'
    )

@pytest.fixture
def tmp1():
    return Template(
        content={'default': 'content1'}, 
        id='234', 
        name='name1',  
        reference='ref1',
        title={'default': 'title1', 'nl': 'nltitle', 'fr': 'frtitle'}, 
        _creationtime=datetime(2020,1,1),
        _documenttype="Template", 
        _modificationtime=datetime(2020,4,15), 
    )

@pytest.fixture
def tmpl1():
    return [{
        'content': {'default': 'content1'}, 
        'id': '234', 
        'name': 'name1',  
        'reference': 'ref1',
        'title': {'default': 'title1', 'nl': 'nltitle', 'fr': 'frtitle'}, 
        '_creationtime': datetime(2020,1,1),
        '_documenttype': "Template", 
        '_modificationtime': datetime(2020,4,15), 
    },{
        'content': {'default': 'content2', 'nl': 'nlcontent', 'fr': 'frcontent'}, 
        'id': '345', 
        'name': 'name2',  
        'reference': 'ref2', 
        'title': {'default': 'title2'}, 
        '_creationtime': datetime(2020,1,2),
        '_documenttype': "Template", 
        '_modificationtime': datetime(2020,4,16), 
    }]
