# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, patch
from datetime import datetime, date, timedelta

from service.account import (
    createAccount,
    delete_account,
    get_account,
    get_accounts,
    update_account,
)

from reddevil.models.md_account import (
    AccountDetailedOut,
    AccountIn,
    AccountListOut,
    AccountOut,
    AccountLogin,
    LoginType,
)


@pytest.fixture
def accdetailed1():
    return {
        "_creationtime": datetime(2020, 1, 1),
        "domain": "chessdevil",
        "email": "a@b.cd",
        "enabled": True,
        "first_name": "Julius",
        "id": "234",
        "last_name": "Casear",
        "locale": "lt",
        "logintype": "google",
        "_modificationtime": datetime(2020, 4, 15),
        "_version": 2,
    }


@pytest.fixture
def accs1():
    return [
        {
            "email": "a@b.cd",
            "enabled": True,
            "first_name": "Julius",
            "id": "234",
            "last_name": "Casear",
            "locale": "lt",
            "logintype": "google",
        },
        {
            "email": "f@b.cd",
            "enabled": True,
            "first_name": "Jimi",
            "id": "235",
            "last_name": "Hendrix",
            "locale": "en",
            "logintype": "email",
        },
    ]


@patch("reddevil.service.sv_account.DbAccount.add")
@pytest.mark.asyncio
async def test_create_account(aadd: Mock):
    aadd.return_value = "123"
    a = AccountIn(
        id="ikke",
        logintype=LoginType.google,
        password="1234",
        domain="dom1",
        email="a@b.cd",
        first_name="julius",
        last_name="Caesar",
    )
    id = await createAccount(a)
    aadd.assert_awaited()
    pd = aadd.await_args.args[0]
    assert pd["logintype"] == LoginType.google
    assert pd["enabled"] == False
    assert isinstance(pd["tokensalt"], str)
    assert id == "123"


@patch("reddevil.service.sv_account.DbAccount.delete")
@pytest.mark.asyncio
async def test_delete_accont(adelete: Mock):
    id = await delete_account("123")
    adelete.assert_awaited()
    assert adelete.await_args.args[0] == "123"


@patch("reddevil.service.sv_account.DbAccount.find_single")
@pytest.mark.asyncio
async def test_get_account(afindsingle: Mock, accdetailed1):
    afindsingle.return_value = accdetailed1
    pd = await get_account("123")
    afindsingle.assert_awaited()
    assert afindsingle.await_args.args[0] == {"id": "123"}
    assert isinstance(pd, AccountDetailedOut)
    assert pd.id == "234"
    assert pd.domain == "chessdevil"
    assert pd.first_name == "Julius"


@patch("reddevil.service.sv_account.DbAccount.find_multiple")
@pytest.mark.asyncio
async def test_get_accounts(afindmultiple: Mock, accs1):
    afindmultiple.return_value = accs1
    accs = await get_accounts()
    afindmultiple.assert_awaited()
    assert isinstance(accs, AccountListOut)
    assert len(accs.accounts) == 2
