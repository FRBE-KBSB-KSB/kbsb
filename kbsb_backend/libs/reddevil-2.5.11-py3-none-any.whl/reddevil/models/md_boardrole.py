# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

from datetime import datetime
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
from .md_i18nfield import I18nField

class BoardRole_(BaseModel):
    """
    a BoardRole as written in database
    """
    name: str
    title: Dict[str, I18nField]  
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime

class BoardRole(BaseModel):
    """
    a BoardRole as used in the service
    """
    id: Optional[str] = None
    name: Optional[str] = None
    title: Optional[Dict[str, I18nField]] = None
    _id: Optional[str] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None

class BoardRoleIn(BaseModel):
    """
    validator for creating a BoardRole
    """
    name: str

class BoardRoleOut(BaseModel):
    """
    validator of a single BoardRole in een list
    """
    id: str
    name: str
    title: Dict[str, I18nField]

class BoardRoleList(BaseModel):
    """
    contains a list of BoardRoleOut
    """
    roles: List[Any]

class BoardRoleUpdate(BaseModel):
    """
    Validator to update a BaordRole
    """
    title: Optional[Dict[str,I18nField]] = None
    name: Optional[str] = None

