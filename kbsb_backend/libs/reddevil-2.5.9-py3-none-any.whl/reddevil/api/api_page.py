import logging
from fastapi import HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List
from reddevil.common import (
    get_app, 
    get_baseurl,
    RdException,
    bearer_schema,
)

app = get_app()
print('App', app)
url = get_baseurl()

from reddevil.service.sv_page import (
    createPage,
    deletePage,
    getPage,
    getPageBySlug,
    getPages,
    updatePage,
    # getActiveArticles,
    # backupPages,
)
from reddevil.service.sv_accountactions import validate_token
from reddevil.models.md_page import (
    PageIn,
    PageList,
    Page,
    PageUpdate,
)

log = logging.getLogger('reddevil')

@app.get(url + '/pages', response_model=PageList)
async def api_get_pages( 
        auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
    try:
        log.info('trying pages')
        await validate_token(auth)
        return await getPages()
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_pages')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/a/pages/{site}', response_model=PageList)
async def api_anon_get_pages(site):
    log.info(f'options {options}')
    try:
        return await getPages(dict(site=site))
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_pages')
        raise HTTPException(status_code=500, detail="Internal Server Error")

# @app.post(url + '/pages/backup', response_model=List[Page])
# async def api_backup_pages( 
#         auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
#     try:
#         await validate_token(auth)
#         return await backupPages()
#     except RdException as e:
#         raise HTTPException(status_code=e.status_code, detail=e.description)
#     except:
#         log.exception('failed api call get_pages')
#         raise HTTPException(status_code=500, detail="Internal Server Error")

# @app.post(url + '/pages/restore', response_model=PageList)
# async def api_restore_pages( 
#         auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
#     try:
#         await validate_token(auth)
#         return await getPages()
#     except RdException as e:
#         raise HTTPException(status_code=e.status_code, detail=e.description)
#     except:
#         log.exception('failed api call get_pages')
#         raise HTTPException(status_code=500, detail="Internal Server Error")

@app.post(url + '/page', response_model=str)
async def api_add_page(p: PageIn, 
        auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
    try:
        await validate_token(auth)
        return await createPage(p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call create_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/page/{id}')
async def api_get_page(id: str, 
             auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
    try:
        await validate_token(auth)
        return await getPage(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/a/page/{id}')
async def api_anon_get_page(id: str):
    try:
        return await getPage(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/a/pages/slug/{slug}')
async def api_anon_get_page_by_slug(slug: str):
    try:
        return await getPageBySlug(slug)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")


@app.delete(url + '/page/{id}')
async def api_delete_page(id: str,  
        auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
    try:
        await validate_token(auth)
        await deletePage(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call delete_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.put(url + '/page/{id}')
async def api_update_page(id: str, p: PageUpdate,  
                auth: HTTPAuthorizationCredentials=Depends(bearer_schema)):
    try:
        await validate_token(auth)
        await updatePage(id, p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call update_page')
        raise HTTPException(status_code=500, detail="Internal Server Error")


# @app.get(url + '/a/slug/{slug}')
# async def api_anon_slug_page(slug: str):
#     try:
#         return await getPageBySlug(slug)
#     except RdException as e:
#         raise HTTPException(status_code=e.status_code, detail=e.description)
#     except:
#         log.exception('failed api call get_localized_page')
#         raise HTTPException(status_code=500, detail="Internal Server Error")


# @app.get(url + '/a/articles')
# async def api_getActiveArticles():
#     try:
#         return await getActiveArticles()
#     except RdException as e:
#         raise HTTPException(status_code=e.status_code, detail=e.description)
#     except:
#         log.exception('failed api call get_activearticles')
#         raise HTTPException(status_code=500, detail="Internal Server Error") 
