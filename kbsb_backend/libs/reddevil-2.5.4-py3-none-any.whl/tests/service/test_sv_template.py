# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, patch
from datetime import datetime, date, timedelta

from reddevil.service.sv_template import (
    createTemplate,
    deleteTemplate,
    getTemplate,
    getTemplates,
    renderTemplate,
    updateTemplate,
)

from reddevil.models.md_template import (
    Template,
    TemplateIn,
    TemplateList,
    TemplateOut,
    TemplateRendered,
    TemplateUpdate,
)

@pytest.fixture
def tmpl1():
    return [{
        'content': {'default': 'content1'}, 
        'id': '234', 
        'name': 'name1',  
        'reference': 'ref1',
        'title': {'default': 'title1', 'nl': 'nltitle', 'fr': 'frtitle'}, 
        '_creationtime': datetime(2020,1,1),
        '_documenttype': "Template", 
        '_modificationtime': datetime(2020,4,15), 
    },{
        'content': {'default': 'content2', 'nl': 'nlcontent', 'fr': 'frcontent'}, 
        'id': '345', 
        'name': 'name2',  
        'reference': 'ref2', 
        'title': {'default': 'title2'}, 
        '_creationtime': datetime(2020,1,2),
        '_documenttype': "Template", 
        '_modificationtime': datetime(2020,4,16), 
    }]

@patch('reddevil.service.sv_template.DbTemplate.add')
@pytest.mark.asyncio
async def test_create_template(add: Mock):
    tmpl = TemplateIn(name='name1', reference='ref1')
    id = await createTemplate(tmpl)
    add.assert_awaited()
    tdict = add.await_args.args[0]
    assert tdict['name'] == 'name1'
    assert tdict['reference'] == 'ref1'
    assert tdict['title']['default'] == 'name1'
    assert tdict['content']['default'] == ''

@patch('reddevil.service.sv_template.DbTemplate.delete')
@pytest.mark.asyncio
async def test_delete_template(delete_: Mock):
    id = await deleteTemplate('123')
    delete_.assert_awaited()
    assert delete_.await_args.args[0] == '123'

@patch('reddevil.service.sv_template.DbTemplate.find_single')
@pytest.mark.asyncio
async def test_get_template(find_single: Mock, tmpl1):
    find_single.return_value = tmpl1[0]
    t = await getTemplate('123')
    find_single.assert_awaited()
    assert find_single.await_args.args[0] == {'id':'123'}
    assert isinstance(t, Template)
    assert t.id == '234'
    assert t.reference == 'ref1'

@patch('reddevil.service.sv_template.DbTemplate.find_multiple')
@pytest.mark.asyncio
async def test_get_templates(find_multiple: Mock, tmpl1):
    find_multiple.return_value = tmpl1
    t = await getTemplates()
    find_multiple.assert_awaited()
    assert isinstance(t, TemplateList)
    assert len(t.templates) == 2
    assert isinstance(t.templates[0], TemplateOut)

@patch('reddevil.service.sv_template.DbTemplate.update')
@pytest.mark.asyncio
async def test_update_template(update: Mock, tmpl1):
    update.return_value = tmpl1[0]
    t = await updateTemplate('123', TemplateUpdate(name='new'))
    update.assert_awaited()
    assert update.await_args.args[0] == '123'
    assert update.await_args.args[1] == {'name': 'new'}
    assert isinstance(t, Template)
    assert t.id == '234'
    assert t.content == {'default': 'content1'}

def test_render_template(tmpl1):
    t1 = Template(**tmpl1[0])
    t2 = Template(**tmpl1[1])
    rt = renderTemplate(t1, 'nl')
    assert isinstance(rt, TemplateRendered)
    assert rt.name == t1.name
    assert rt.id == t1.id
    assert rt.reference == t1.reference
    assert rt.title == 'nltitle'
    assert rt.content == 'content1'
    rt = renderTemplate(t1, 'en')
    assert isinstance(rt, TemplateRendered)
    assert rt.title == 'title1'
    rt = renderTemplate(t1, 'en', {}, 'fr')
    assert isinstance(rt, TemplateRendered)
    assert rt.title == 'frtitle'
    rt = renderTemplate(t2, 'nl')
    assert isinstance(rt, TemplateRendered)
    assert rt.title == 'title2'
    assert rt.content == 'nlcontent'
    rt = renderTemplate(t2, 'en')
    assert isinstance(rt, TemplateRendered)
    assert rt.content == 'content2'
    rt = renderTemplate(t2, 'en', {}, 'fr')
    assert isinstance(rt, TemplateRendered)
    assert rt.content == 'frcontent'

