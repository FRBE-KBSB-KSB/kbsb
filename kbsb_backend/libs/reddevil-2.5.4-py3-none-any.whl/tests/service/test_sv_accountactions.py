# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, MagicMock, patch, PropertyMock, AsyncMock
from datetime import datetime, date, timedelta
from fastapi.security import HTTPAuthorizationCredentials

from reddevil.service.sv_accountactions import (
    get_token,
    validate_token,
    registerAccount,
    login,
    changePassword,
    confirmPassword,
    processEmailVerification,
    requestPasswordReset,
    processPasswordReset,
)

from reddevil.models.md_account import (
    Account,
    AccountIn,
    AccountLogin,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    LoginType,
)
from reddevil.common import RdNotFound, RdNotAuthorized


@pytest.fixture
def acc1():
    return [
        {
            "domain": "dom1",
            "email": "a@b.cd",
            "email_verified": True,
            "enabled": True,
            "first_name": "Julius",
            "groups": [],
            "hashed_password": "pw1",
            "id": "julius.caesar",
            "last_name": "Caesar",
            "logintype": LoginType.email,
            "password_expirationtime": datetime(2000, 1, 1),
            "roles": [],
            "tokensalt": "Preuteleute",
            "xtra": {},
            "_creationtime": datetime(2020, 1, 1),
            "_documenttype": "Account",
            "_modificationtime": datetime(2020, 4, 15),
        },
        {
            "domain": "dom2",
            "email": "ff@b.cd",
            "email_verified": True,
            "enabled": True,
            "first_name": "Freddy",
            "groups": [],
            "hashed_password": "pw2",
            "id": "freddy.devadder",
            "last_name": "De Vadder",
            "logintype": LoginType.google,
            "password_expirationtime": datetime(2000, 3, 20),
            "roles": [],
            "tokensalt": None,
            "xtra": {},
            "_creationtime": datetime(2020, 1, 1),
            "_documenttype": "Account",
            "_modificationtime": datetime(2020, 4, 15),
        },
    ]


@patch("reddevil.service.sv_accountactions.jwt_encode")
@patch("reddevil.service.sv_accountactions.settings")
@patch("reddevil.service.sv_accountactions.updateAccount")
@pytest.mark.asyncio
async def test_get_token(
    updateAccount: AsyncMock, settings: MagicMock, jwt_encode: AsyncMock, acc1
):
    acc1 = Account(**acc1[0])
    await get_token(acc1, timedelta(hours=1), True)
    updateAccount.assert_awaited()
    jwt_encode.assert_called()
    payload = jwt_encode.call_args.args[0]
    assert "sub" in payload
    assert "exp" in payload
    assert payload["sub"] == "julius.caesar"


@patch("reddevil.service.sv_accountactions.jwt_verify")
@patch("reddevil.service.sv_accountactions.jwt_getunverifiedpayload")
@patch("reddevil.service.sv_accountactions.settings")
@patch("reddevil.service.sv_accountactions.getAccount")
@pytest.mark.asyncio
async def test_validate_token(
    getAccount: AsyncMock,
    settings: MagicMock,
    jwt_getunverifiedpayload: AsyncMock,
    jwt_verify: AsyncMock,
    acc1,
):
    acc1 = Account(**acc1[0])
    auth = HTTPAuthorizationCredentials(scheme="http", credentials="token1")
    token = PropertyMock()
    token.return_value = {"secret": "secret"}
    type(settings).TOKEN = token
    print("settings.TOKEN", settings.TOKEN)
    getAccount.return_value = acc1
    jwt_getunverifiedpayload.return_value = {"sub": "user1"}
    await validate_token(auth)
    getAccount.assert_awaited()
    jwt_verify.assert_called()


@patch("reddevil.service.sv_accountactions.settings")
@patch("reddevil.service.sv_accountactions.getAccount")
@patch("reddevil.service.sv_accountactions.verify_password")
@patch("reddevil.service.sv_accountactions.get_token")
@pytest.mark.asyncio
async def test_login_email(
    get_token: Mock, verify_password: Mock, getAccount: Mock, settings: MagicMock, acc1
):
    acc = Account(**acc1[0])
    getAccount.return_value = acc
    verify_password.return_value = True
    get_token.return_value = "token"
    TOKEN = PropertyMock()
    TOKEN.return_value = {"timeout": 50}
    type(settings).TOKEN = TOKEN
    await login(
        AccountLogin(logintype=LoginType.email, password="dronken", username="ikke")
    )
    getAccount.assert_awaited()
    assert getAccount.await_args.args[0] == "ikke"
    verify_password.assert_called()
    assert verify_password.call_args.args[0] == "dronken"
    assert verify_password.call_args.args[1] == "pw1"
    get_token.assert_awaited()
    assert get_token.await_args.args[0] == acc
