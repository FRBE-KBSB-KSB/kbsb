# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, patch
from datetime import datetime, date, timedelta

from reddevil.service.sv_boardrole import (
    # backupBoardRoles,
    createBoardRole,
    deleteBoardRole,
    getBoardRole,
    getBoardRoles,
    # restoreBoardRoles,
    updateBoardRole,
)

from reddevil.models.md_boardrole import (
    BoardRole,
    BoardRoleIn,
    BoardRoleOut,
    BoardRoleList,
    BoardRoleUpdate,
)

@patch('reddevil.service.sv_boardrole.DbBoardRole.add')
@pytest.mark.asyncio
async def test_create_boardrole(add: Mock):
    d = BoardRoleIn(name='role1')
    id = await createBoardRole(d)
    add.assert_awaited()
    pd = add.await_args.args[0]
    assert 'title' in pd
    assert pd['name'] == 'role1'

@patch('reddevil.service.sv_boardrole.DbBoardRole.delete')
@pytest.mark.asyncio
async def test_delete_boardrole(delete_: Mock):
    id = await deleteBoardRole('123')
    delete_.assert_awaited()
    assert delete_.await_args.args[0] == '123'

@pytest.fixture
def br1():
    return {
        '_creationtime': datetime(2020,1,1),
        '_documenttype': "BoardRole", 
        'id': '234', 
        'name': 'role1',  
        '_modificationtime': datetime(2020,4,15), 
        'title': {'default': {'value': 'title1'}}, 
        '_version': 2,        
    }

@patch('reddevil.service.sv_boardrole.DbBoardRole.find_single')
@pytest.mark.asyncio
async def test_get_boardrole(find_single: Mock, br1):
    find_single.return_value = br1
    pd = await getBoardRole('123')
    find_single.assert_awaited()
    assert find_single.await_args.args[0] == {'id':'123'}
    assert isinstance(pd, BoardRoleOut)
    assert pd.id == '234'

@pytest.fixture
def br2():
    return [{
        'id': '234', 
        'name': 'role1',  
        'title': {'default': {'value': 'title1'}}, 
    },{
        'id': '345', 
        'name': 'role2',  
        'title': {'default': {'value': 'title2'}}, 

    }]


@patch('reddevil.service.sv_boardrole.DbBoardRole.find_multiple')
@pytest.mark.asyncio
async def test_get_boardroles(find_multiple: Mock, br2):
    find_multiple.return_value = br2
    pd = await getBoardRoles()
    find_multiple.assert_awaited()
    assert isinstance(pd, BoardRoleList)
    assert len(pd.roles) == 2
    assert isinstance(pd.roles[0], BoardRoleOut)

@patch('reddevil.service.sv_boardrole.DbBoardRole.update')
@pytest.mark.asyncio
async def test_update_boardrole(update: Mock, br1):
    update.return_value = br1
    pd = await updateBoardRole('123', BoardRoleUpdate(name='new'))
    update.assert_awaited()
    assert update.await_args.args[0] == '123'
    assert update.await_args.args[1] == {'name': 'new'}
    assert isinstance(pd, BoardRoleOut)
    assert pd.id == '234'
  