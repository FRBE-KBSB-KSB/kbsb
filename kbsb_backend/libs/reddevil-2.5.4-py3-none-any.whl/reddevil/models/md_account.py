# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# all models in the service level exposed to the API
# we are using pydantic as tool

from datetime import datetime, date, timezone
from typing import Dict, Any, List, Optional, Type, Tuple
from enum import Enum
from pydantic import BaseModel


class LoginType(str, Enum):
    """
    enum for Account
    """

    email = "email"
    facebook = "facebook"
    google = "google"


class Account_(BaseModel):
    """
    the account class as registered in the database
    """

    domain: str
    email: str
    enabled: bool
    hashed_password: str
    locale: str
    logintype: LoginType
    expiration_time: datetime
    tokensalt: str
    super: bool
    verified: bool
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class Account(BaseModel):
    """
    The account class as used in the service layer
    """

    domain: Optional[str] = None
    email: Optional[str] = None
    enabled: Optional[bool] = None
    expirationtime: Optional[datetime] = None
    hashed_password: Optional[str] = None
    id: Optional[str] = None
    locale: Optional[str] = None
    logintype: Optional[LoginType] = None
    super: Optional[bool] = None
    tokensalt: Optional[str] = None
    verified: Optional[bool] = None
    _creationtime: Optional[datetime] = None
    _documenttype: Optional[str] = None
    _id: Optional[str] = None
    _modificationtime: Optional[datetime] = None
    _version: Optional[int] = None


class AccountIn(BaseModel):
    """
    validator to create a new account on API lvel
    """

    domain: Optional[str] = ""
    email: str
    enabled: bool = False
    id: str
    locale: Optional[str] = "en"
    logintype: LoginType
    password: Optional[str] = ""
    verified: bool = False


class AccountOut(BaseModel):
    """
    A standard validator for a account
    No
    """

    domain: str
    email: str
    enabled: bool
    id: str
    locale: str
    logintype: LoginType
    verified: bool = False


class AccountUpdate(BaseModel):
    """
    validator for an AccountUpdate
    """

    domain: Optional[str] = None
    enabled: Optional[bool] = None
    locale: Optional[str] = None
    logintype: Optional[LoginType] = None
    verified: Optional[bool] = None


class AccountListOut(BaseModel):
    accounts: List[Any]


class AccountDetailedOut(BaseModel):
    """
    validator for a detailed account
    """

    _creationtime: datetime
    domain: str = ""
    email: str
    enabled: bool = False
    expiration_time: Optional[datetime] = None
    id: str
    locale: str
    logintype: LoginType
    _modificationtime: datetime
    verified: bool = False


class AccountLogin(BaseModel):
    """
    validator for logging in
    """

    logintype: LoginType
    password: Optional[str]
    token: Optional[str]
    username: Optional[str]


class AccountPasswordUpdate(BaseModel):
    """
    validator for passwordupdate
    """

    newpassword: str
    oldpassword: str
    username: str


class AccountPasswordReset(BaseModel):
    """
    validator for passwordreset
    """

    username: Optional[str]
    email: Optional[str]
    locale: str


class AccountPasswordConfirm(BaseModel):
    """
    validator for passwordconfirm
    """

    email: str
    newpassword: str
    username: str
    token: str


class AccountRequestType(str, Enum):
    email_verification = "email_verification"
    password_reset = "password_reset"


class AccountRequest_(BaseModel):
    """
    contains the fields as registered in the database
    of a email Request to chnage password, confirmAccount, ....
    """

    username: str
    expiry_time: datetime
    reason: str
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class AccountRequest(BaseModel):
    """
    contains the fields as registered in the database
    of a email Request to
    """

    username: Optional[str] = None
    expiry_time: Optional[datetime] = None
    id: Optional[str] = None
    reason: Optional[str] = None
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class AccountRequestVerification(BaseModel):
    """
    validator for verification of incoming AccountRequest
    """

    id: str
    password: str
    reason: str
    username: str
