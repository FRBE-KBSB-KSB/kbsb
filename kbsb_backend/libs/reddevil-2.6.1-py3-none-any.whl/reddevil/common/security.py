# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from typing import Optional
from jose import jwt, JWTError, ExpiredSignatureError
from passlib.context import CryptContext
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from reddevil.common import get_settings

log = logging.getLogger("reddevil")
bearer_schema = HTTPBearer(auto_error=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str):
    """
    return the password hashed
    """
    return pwd_context.hash(password)


def verify_password(plain: str, hash: str):
    """
    verify hash is the plain password hashed
    """
    return pwd_context.verify(plain, hash)


def jwt_encode(payload: dict, salt: str, algorithm: Optional[str] = None):
    """
    create a jwt_token
    """
    settings = get_settings()
    if algorithm is None:
        algorithm = settings.JWT_ALGORITHM
    return jwt.encode(payload, settings.JWT_SECRET + salt, algorithm)


def jwt_verify(token, key):
    """
    verify the token with the secret key
    """
    return jwt.decode(token, key)


def jwt_getunverifiedpayload(token):
    """
    gets the payload from a token.  Does not validate the signature
    """
    return jwt.decode(token, key="", options={"verify_signature": False})
