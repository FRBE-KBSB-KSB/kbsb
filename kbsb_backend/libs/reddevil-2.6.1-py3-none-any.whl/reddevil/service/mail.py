# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import os
from fastapi import HTTPException
from markdown2 import Markdown
from jinja2 import FileSystemLoader, Environment, exceptions
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from io import BytesIO
from pathlib import Path
from typing import List, Optional
from weasyprint import HTML, CSS
from reddevil.common import get_settings
from reddevil.models.md_mail import MailParams

from .mailbackend import backends

log = logging.getLogger("reddevil")
md = Markdown(extras=["tables"])


def get_template_env():
    if not hasattr(get_template_env, "env"):
        settings = get_settings()
        get_template_env.env = Environment(
            loader=FileSystemLoader(settings.TEMPLATES_PATH), trim_blocks=True
        )
    log.debug(f"jinja2 searchpath {get_template_env.env.loader.searchpath}")
    return get_template_env.env


def getCss():
    settings = get_settings()
    if not hasattr(getCss, "css"):
        with open(Path(settings.TEMPLATES_PATH) / "markdown.css") as f:
            setattr(getCss, "css", f.read())
    return getattr(getCss, "css")


def sendEmail(mp: MailParams, context: dict, name: str = ""):
    """
    dispatcher for emails
    """
    attachments = mp.attachments
    if not attachments:
        sendEmailNoAttachments(mp, context, name)
        return
    if len(attachments) == 1 and attachments[0].mimetype == "application/pdf":
        sendEmailWithPdf(mp, context, name)
        return
    log.error("emails with more than 1 attachment not yet supported")
    raise HTTPException(503, detail="EmailBackendNotImplemented")


def sendEmailNoAttachments(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with no attachment
    """
    settings = get_settings()
    env = get_template_env()
    try:
        tmpl = env.get_template(mp.template.format(locale=context["locale"]))
    except exceptions.TemplateNotFound as e:
        log.info(f"could not find template in searchpath {env.loader.searchpath}")
        raise e
    markdowntext = tmpl.render(**context)
    htmltext = md.convert(markdowntext)
    try:
        msg = MIMEMultipart("related")
        msg["Subject"] = mp.subject
        msg["From"] = mp.sender
        msg["To"] = mp.receiver
        if mp.cc:
            msg["Cc"] = mp.cc
        if mp.bcc:
            msg["Bcc"] = mp.bcc
        msg.preamble = "This is a multi-part message in MIME format."
        msgAlternative = MIMEMultipart("alternative")
        msgText = MIMEText(markdowntext)
        msgAlternative.attach(msgText)
        msgText = MIMEText(htmltext, "html")
        msgAlternative.attach(msgText)
        msg.attach(msgAlternative)
        backend = backends[settings.EMAIL["backend"]]()
        backend.send_message(msg)
        log.info(f"email {name} sent to {mp.receiver}")
    except Exception:
        log.exception("failed")


def sendEmailWithPdf(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with a pdf attachment
    """
    settings = get_settings()
    env = get_template_env()
    tmpl = env.get_template(mp.template.format(locale=context["locale"]))
    markdowntext = tmpl.render(**context)
    htmltext = md.convert(markdowntext)
    try:
        # receiver = rsv.email
        msg = MIMEMultipart("related")
        msg["Subject"] = mp.subject
        msg["From"] = mp.sender
        msg["To"] = mp.receiver
        if mp.cc:
            msg["Cc"] = mp.cc
        if mp.bcc:
            msg["Bcc"] = mp.bcc
        msg.preamble = "This is a multi-part message in MIME format."
        msgAlternative = MIMEMultipart("alternative")
        msgText = MIMEText(markdowntext)
        msgAlternative.attach(msgText)
        msgText = MIMEText(htmltext, "html")
        msgAlternative.attach(msgText)
        msg.attach(msgAlternative)
        # pdf
        att = mp.attachments[0]
        assert att.template is not None
        pdftmpl = env.get_template(att.template.format(locale=context["locale"]))
        pdfmd = pdftmpl.render(**context)
        pdfhtml = md.convert(pdfmd)
        pdfio = BytesIO()
        HTML(string=pdfhtml).write_pdf(pdfio, stylesheets=[CSS(string=getCss())])
        msgAtt = MIMEBase("application", "octet-stream")
        msgAtt.set_payload(pdfio.getvalue())
        encoders.encode_base64(msgAtt)
        msgAtt.add_header(
            "Content-Disposition",
            f"attachment; filename={att.filename}",
        )
        msg.attach(msgAtt)
        backend = backends[settings.EMAIL["backend"]]()
        backend.send_message(msg)
        log.info(f"payrequest email sent to {mp.receiver}")
    except Exception:
        log.exception("failed")
