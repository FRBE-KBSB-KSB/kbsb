# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging, json, os, uuid, os
from aiofiles.os import stat as aio_stat
from datetime import datetime, timezone, date
from slugify import slugify
from mimetypes import guess_type
from random import randrange
from base64 import b64encode, b64decode
from typing import List, Optional, Union, cast
from fastapi.responses import FileResponse

from reddevil.common import (
    RdInternalServerError,
    RdBadRequest,
    RdNotFound,
    get_settings,
)

from reddevil.models.md_file import (
    FileIn,
    FileOut,
    FileUpdate,
    FileListOut,
    FileOptional,
)

from reddevil.db.db_file import DbFile

log = logging.getLogger(__name__)
settings = get_settings()


def encode_file(e: dict, _class=FileOptional) -> FileOptional:
    try:
        eo = _class(**e)
    except Exception:
        log.exception("cannot encode File")
        raise RdInternalServerError(description="CannotEncodeFile")
    return cast(FileOptional, eo)


async def createFile(d: FileIn) -> str:
    """
    create a new File returning its id
    """
    tsnow = datetime.now(tz=timezone.utc)
    dd = d.dict()
    ns = dd["name"].split(".")
    dd["id"] = str(uuid.uuid4())
    dd["url"] = f'{".".join(ns[0:-1])}__{randrange(1000000):06d}.{ns[-1]}'
    dd["path"] = os.path.join(settings.FILESTORE, dd["url"])
    dd["mimetype"] = guess_type(dd["name"])[0]
    content = b64decode(dd.pop("content"))
    dd["filelength"] = len(content)
    dd["topicdate"] = ""
    rf = await DbFile.add(dd)
    with open(dd["path"], "wb") as f:
        f.write(content)
    return rf


async def deleteFile(id: str) -> None:
    d = await getFile(
        id,
        {
            "_class": FileOptional,
            "_fieldlist": ["path"],
        },
    )
    assert d.path
    try:
        os.unlink(d.path)
    except:
        pass
    await DbFile.delete(id)


async def getFile(id: str, options: dict = {}) -> FileOptional:
    """
    get the file
    """
    _class = options.pop("_class", FileOut)
    filter = dict(id=id, **options)
    fdict = await DbFile.find_single(filter)
    return encode_file(fdict, _class)


async def getFiles(options: dict = {}) -> FileListOut:
    """
    get all the Files
    """
    if options.pop("reports", None):
        options["topic"] = {"$in": ["Report General Assembly", "Report Board Meeting"]}
    _class = options.pop("_class", FileOut)
    docs = await DbFile.find_multiple(options)
    files = [encode_file(d, _class) for d in docs]
    return FileListOut(files=files)


async def getFileContent(url: str) -> FileResponse:
    """
    get the file
    """
    fd = await DbFile.find_single(
        {
            "url": url,
            "_fieldlist": ["url", "mimetype"],
        }
    )
    try:
        ## we reconstruct the path because settings.FILESTORE could be changed
        ## wrt the file creation
        ## we don't let FileResponse check the existence of the file
        # in order to have a decent error handling
        path = os.path.join(settings.FILESTORE, fd["url"])
        stat_result = await aio_stat(path)
        return FileResponse(
            path=path, media_type=fd["mimetype"], stat_result=stat_result
        )
    except FileNotFoundError:
        raise RdNotFound(description="CouldNotReadFile")


async def updateFile(id: str, d: FileUpdate) -> FileOptional:
    """
    update a file
    """
    fd = d.dict(exclude_unset=True)
    content = None
    if "name" in fd:
        name = f'{fd["name"]}__{randrange(1000000):06d}'
        fd["mimetype"] = guess_type(fd["name"])[0]
    if "content" in fd:
        content = b64decode(fd.pop("content"))
        fd["filelength"] = len(content)
    ufd = await DbFile.update(id, fd)
    log.info(f"ufg {ufd}")
    if content:
        with open(ufd["path"], "wb") as f:
            f.write(content)
    return encode_file(ufd)


async def backupFiles() -> List[FileOptional]:
    """
    dumps all Files records with full details
    """
    docs = await DbFile.find_multiple({"_fieldlist": {}})
    return [encode_file(d, FileOptional) for d in docs]


async def restoreFiles(docs: List[dict]) -> None:
    """
    dumps all Files records with full details
    """
    await DbFile.restore(docs)
