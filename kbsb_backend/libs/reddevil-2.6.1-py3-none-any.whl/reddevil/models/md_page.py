# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

# all models in the service level exposed to the API
# we are using pydantic as tool

import logging

from datetime import datetime
from typing import Dict, Any, List, Optional, Type, Union
from enum import Enum
from pydantic import BaseModel


class Page_(BaseModel):
    """
    a Page as written in database
    """
    body: Dict[str, Any]
    doctype: str
    enabled: bool
    expirationdate: str             # format yyyy-mm-dd
    intro: Dict[str, Any]
    languages: List[str]
    layout: str
    name: str
    owner: str 
    publicationdate: str            # format yyyy-mm-dd
    slug: str
    title: Dict[str, Any]
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime

class Page(BaseModel):
    """
    as a default all fields in Page are Optional so we can work on raw database documents
    """
    active: Optional[bool] = None
    body: Optional[Dict[str, Any]] = None
    doctype: Optional[str] = None
    enabled: Optional[bool] = None
    expirationdate: Optional[str] = None          # format yyyy-mm-dd
    intro: Optional[Dict[str, Any]] = None
    id: Optional[str] = None
    languages: Optional[List[str]] = None
    layout: Optional[str] = None
    name: Optional[str] = None
    owner: Optional[str] = None 
    publicationdate: Optional[str] = None         # format yyyy-mm-dd
    slug: Optional[str] = None
    title: Optional[Dict[str, Any]] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None


class PageIn(BaseModel):
    """
    validator for new pages
    """
    doctype: str        # 'normal-page', 'article', 'app-page' 
    locale: str
    name: str

class PageList(BaseModel):
    pages: List[Any]

class PageUpdate(BaseModel):
    """
    validator for Page updates
    """
    body: Optional[Dict[str, Any]]
    doctype: Optional[str]
    enabled: Optional[bool]
    expirationdate: Optional[str]             # format yyyy-mm-dd
    intro: Optional[Dict[str, Any]] = None
    languages: Optional[List[str]]
    name: Optional[str]
    owner: Optional[str] 
    publicationdate: Optional[str]            # format yyyy-mm-dd
    slug: Optional[str]
    title: Optional[Dict[str, Any]] = None
