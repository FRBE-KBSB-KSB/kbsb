# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

# all models in the service level exposed to the API
# we are using pydantic as tool

import logging

from datetime import datetime
from typing import Dict, Any, List, Optional, Type, Union
from enum import Enum
from pydantic import BaseModel

class PageI18nFields(BaseModel):
    body: str
    intro: str
    title: str

class Page_(BaseModel):
    """
    a Page as written in database
    """
    doctype: str
    enabled: bool
    expirationdate: str             # format yyyy-mm-dd
    i18n: Dict[str, PageI18nFields]
    languages: List[str]
    layout: str
    name: str
    owner: str 
    publicationdate: str            # format yyyy-mm-dd
    slug: str
    site: str
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime

class Page(BaseModel):
    """
    as a default all fields in Page are Optional so we can work on raw database documents
    """
    active: Optional[bool] = None
    doctype: Optional[str] = None
    enabled: Optional[bool] = None
    expirationdate: Optional[str] = None          # format yyyy-mm-dd
    i18n: Optional[Dict[str, PageI18nFields]] = None
    languages: Optional[List[str]] = None
    layout: Optional[str] = None
    name: Optional[str] = None
    owner: Optional[str] = None 
    publicationdate: Optional[str] = None         # format yyyy-mm-dd
    slug: Optional[str] = None
    site: Optional[str] = None
    _id: Optional[str] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None


class PageIn(BaseModel):
    """
    validator for new pages
    """
    doctype: str        # 'normal-page', 'article', 'app-page' 
    locale: str
    name: str
    site: str

class PageOut(BaseModel):
    """
    A validator for listing of pages
    """
    active: bool
    doctype: str
    enabled: bool
    expirationdate: Optional[str]
    id: str
    name: str
    publicationdate: Optional[str]
    slug: str
    _creationtime: Optional[datetime]

class PageDetailedOut(BaseModel):
    """
    A validator for a detailed page
    """
    doctype: str
    enabled: bool
    expirationdate: str          # format yyyy-mm-dd
    id: str
    i18n: Dict[str, PageI18nFields]
    languages: List[str]
    layout: str
    name: str
    owner: str
    publicationdate: str         # format yyyy-mm-dd
    slug: str
    site: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime

class PageList(BaseModel):
    pages: List[Any]

class PageUpdate(BaseModel):
    """
    validator for Page updates
    """
    doctype: Optional[str]
    enabled: Optional[bool]
    expirationdate: Optional[str]             # format yyyy-mm-dd
    i18n: Optional[Dict[str, PageI18nFields]]
    languages: Optional[List[str]]
    name: Optional[str]
    owner: Optional[str] 
    publicationdate: Optional[str]            # format yyyy-mm-dd
    slug: Optional[str]


class PageContent(BaseModel):
    """
    validator for localized page content
    """
    expirationdate: str          # format yyyy-mm-dd
    id: str
    content: PageI18nFields
    locale: str
    layout: str
    name: str
    owner: str
    publicationdate: str         # format yyyy-mm-dd
    slug: str
    _creationtime: datetime

