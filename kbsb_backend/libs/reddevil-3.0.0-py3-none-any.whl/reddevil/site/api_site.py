# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from reddevil.core import RdException
from fastapi import HTTPException
from reddevil.core import get_app

log = logging.getLogger("bycco")
app = get_app()


@app.post("/api/site/fetchi18n", response_model=str)
async def api_fetchMarkdownFiles():
    try:
        return await fetchI18n()
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call generate_site")
        raise HTTPException(status_code=500)
