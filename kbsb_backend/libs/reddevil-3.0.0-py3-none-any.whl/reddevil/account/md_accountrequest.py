# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

# all models in the service level exposed to the API
# we are using pydantic as tool

from datetime import datetime
from typing import Dict, Any, List, Optional
from enum import Enum
from pydantic import BaseModel, Field
from reddevil.core.model import DocumentType, ListType
from reddevil.core.base import DbBase


class AccountRequestType(str, Enum):
    email_verification = "email_verification"
    password_reset = "password_reset"


class AccountRequest_:
    """
    contains the fields as registered in the database
    of a email Request to chnage password, confirmAccount, ....
    """

    username: str
    expiry_time: datetime
    reason: str
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class AccountRequest(DocumentType):
    """
    An accountrequest
    """

    username: Optional[str] = None
    expiry_time: Optional[datetime] = None
    id: Optional[str] = None
    reason: Optional[str] = None
    _id: Optional[str]
    _documenttype: Optional[str]
    _version: Optional[int]
    _creationtime: Optional[datetime]
    _modificationtime: Optional[datetime]


class AccountRequestList(ListType):
    accountrequests: List[AccountRequest]


class DbAccountRequest(DbBase):
    COLLECTION = "rd_accountrequest"
    DOCUMENTTYPE = "AccountRequest"
    VERSION = 1
    DT = AccountRequest
    LT = AccountRequestList
    ItemField = "accountrequests"


class AccountRequestVerification(BaseModel):
    """
    validator for verification of incoming AccountRequest
    """

    id: str
    password: str
    reason: str
    username: str


class AccountRecreateOrgVerify(BaseModel):
    """
    validator to recreate organisation Verify
    """

    email: str
    org_id: str
