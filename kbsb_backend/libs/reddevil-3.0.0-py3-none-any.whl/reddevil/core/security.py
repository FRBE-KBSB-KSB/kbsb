# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

import logging
import asyncio
from typing import Optional
from jose import jwt, JWTError, ExpiredSignatureError
from passlib.context import CryptContext
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from reddevil.core import get_settings, RdNotFound, RdNotAuthorized

logger = logging.getLogger(__name__)
bearer_schema = HTTPBearer(auto_error=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str):
    """
    return the password hashed
    """
    return pwd_context.hash(password)


def verify_password(plain: str, hash: str):
    """
    verify hash is the plain password hashed
    """
    return pwd_context.verify(plain, hash)


def jwt_encode(payload: dict, salt: str, algorithm: Optional[str] = None):
    """
    create a jwt_token
    """
    settings = get_settings()
    if algorithm is None:
        algorithm = settings.JWT_ALGORITHM
    return jwt.encode(payload, settings.JWT_SECRET + salt, algorithm)


def jwt_verify(token, key):
    """
    verify the token with the secret key
    """
    jwt.decode(token, key)


def jwt_getunverifiedpayload(token):
    """
    gets the payload from a token.  Does not validate the signature
    """
    return jwt.decode(token, key="", options={"verify_signature": False})


async def validate_token(auth: HTTPAuthorizationCredentials) -> str:
    """
    checks a JWT token for validity
    return username if the token is correctly validated
    if token is not valid the function :
        - either returns None
        - either raise RdNotAuthorized if raising is set
    if nocheck is set, returns "anonymous"
    """
    settings = get_settings()
    token = auth.credentials if auth else None
    if not token:
        raise RdNotAuthorized(description="MissingToken")
    if settings.TOKEN.get("nocheck"):
        await asyncio.sleep(0)
        return "anonymous"
    try:
        payload = jwt_getunverifiedpayload(token)
    except:
        logger.exception("invalid token without verification")
        raise RdNotAuthorized(description="BadToken")
    username = payload.get("sub")
    tokensalt = await get_tokensalt(username)
    if not tokensalt:
        logger.debug(f"Tokensalt empty for {username}")
        raise RdNotAuthorized(description="BadToken")
    try:
        jwt_verify(token, settings.JWT_SECRET + tokensalt)
    except ExpiredSignatureError:
        logger.debug("JWT Error")
        raise RdNotAuthorized(description="TokenExpired")
    except JWTError:
        raise RdNotAuthorized(description="BadToken")
    return username


async def get_tokensalt(username: str) -> Optional[str]:
    """
    get tokensalt for an account, identified by username
    return None if account not found
    """
    from reddevil.account import DbAccount

    try:
        acc = await DbAccount.find_single({"id": username, "_fieldlist": ["tokensalt"]})
        return acc.get("tokensalt", None)
    except RdNotFound:
        return None
