# copyright Chessdevil Consulting BVBA 2015 - 2022

import logging
import uuid
from datetime import datetime, date, timezone
from typing import List, Dict, Any, Optional, Type, cast
from bson.objectid import ObjectId
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from reddevil.core import RdNotFound, RdBadRequest, encode_model
from reddevil.core.mongodb import get_mongodb
from reddevil.core.model import DocumentType, ListType

log = logging.getLogger(__name__)


class DbBase:
    """
    Base class for Mongo collection async operations
    All operations are dumb, unaware of any business logic
    RdExceptions can be raised
    """

    COLLECTION: Optional[str] = None  # should be overriden
    VERSION = 1
    SIMPLEFIELDS: list = []
    HIDDENFIELDS: list = []
    IDGENERATOR = "uuid"
    DT = DocumentType
    LT = ListType
    ItemField = "items"

    @classmethod
    def idgenerator(cls):
        if cls.IDGENERATOR == "uuid":
            return str(uuid.uuid4())
        if cls.IDGENERATOR == "objectid":
            return ObjectId()

    @classmethod
    def id_to_native(cls, id):
        if cls.IDGENERATOR == "uuid":
            return str(id)
        if cls.IDGENERATOR == "objectid":
            return ObjectId(id)

    @classmethod
    def id_from_native(cls, _id):
        if cls.IDGENERATOR == "uuid":
            return str(_id)
        if cls.IDGENERATOR == "objectid":
            return str(_id)

    # dict based methods

    @classmethod
    async def add(cls, doc_in: dict) -> str:
        """
        add a new record, starting form doc_in, return the id
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        if "id" in doc_in:
            doc_in["_id"] = cls.id_to_native(doc_in.pop("id"))
        else:
            doc_in["_id"] = cls.idgenerator()
        doc_in["_DocumentType"] = cls.__name__
        doc_in["_version"] = cls.VERSION
        doc_in["_creationtime"] = datetime.now(timezone.utc)
        doc_in["_modificationtime"] = datetime.now(timezone.utc)
        try:
            await coll.insert_one(doc_in)
        except:
            log.exception(f"error inserting {cls.COLLECTION} record")
            raise RdBadRequest(description=f"CannotCreate{cls.COLLECTION}")
        return doc_in["_id"]

    @classmethod
    async def find_multiple(cls, options: dict = {}) -> List[dict]:
        """
        find multiple records
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        docs = []
        if "id" in options:
            options["_id"] = cls.id_to_native(options.pop("id"))
        _fieldlist = options.pop("_fieldlist", cls.SIMPLEFIELDS)
        _sort = options.pop("_sort", None)
        _limit = options.pop("_limit", 0)
        projfields = (
            {k: 1 for k in _fieldlist}
            if _fieldlist
            else {k: 0 for k in cls.HIDDENFIELDS} or None
        )
        async for doc in coll.find(
            options, projection=projfields, sort=_sort, limit=_limit
        ):
            doc["id"] = cls.id_from_native(doc.pop("_id"))
            docs.append(doc)
        return docs

    @classmethod
    async def find_single(cls, options: dict) -> dict:
        """
        find a single doc,
        raises NotFound if nothing is found
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        if "id" in options:
            options["_id"] = cls.id_to_native(options.pop("id"))
        fieldlist = options.pop("_fieldlist", None)
        projfields = (
            {k: 1 for k in fieldlist}
            if fieldlist
            else {k: 0 for k in cls.HIDDENFIELDS} or None
        )
        doc = await coll.find_one(options, projection=projfields)
        if not doc:
            raise RdNotFound(description=f"CannotFindSingle{cls.COLLECTION}")
        doc["id"] = cls.id_from_native(doc.pop("_id"))
        return doc

    @classmethod
    async def update(
        cls, id: str, docupdate: Dict[str, Any], options: dict = {}
    ) -> dict:
        """
        updates a single doc
        raises NotFound if event is not found
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        idn = cls.id_to_native(id)
        extraupdates = options.pop("$set", None)
        if extraupdates:
            docupdate.update(extraupdates)
        if "_modificationtime" not in docupdate:
            docupdate["_modificationtime"] = datetime.now(timezone.utc)
        doc = await coll.find_one_and_update(
            {"_id": idn},
            dict(**{"$set": docupdate}, **options),
            projection={k: 0 for k in cls.HIDDENFIELDS},
            return_document=ReturnDocument.AFTER,
        )
        if not doc:
            raise RdNotFound(description=f"CannotFind{cls.COLLECTION}")
        doc["id"] = cls.id_from_native(doc.pop("_id"))
        return doc

    @classmethod
    async def delete(cls, id: str) -> None:
        """
        delete a single doc
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        rs = await coll.delete_one({"_id": cls.id_to_native(id)})
        if rs.deleted_count != 1:
            raise RdNotFound(description=f"CannotFind{cls.COLLECTION}")

    # pydantic based methods

    @classmethod
    async def p_add(cls, d: Type[DocumentType], options: dict) -> Type[DocumentType]:
        """
        creates a new document using pydantic types
        """
        validator = options.pop("_validator", cls.DT)
        id = await cls.add(d.dict())
        docdict = await cls.find_single({"id": id}, options)
        return encode_model(docdict, validator)

    @classmethod
    async def p_find_single(cls, id: str, options: dict = {}) -> Type[DocumentType]:
        """
        get a document using pydantic
        raises RdNotFound if not found
        """
        validator = options.pop("_validator", cls.DT)
        docdict = await cls.find_single(id, **options)
        return cast(cls.DT, encode_model(docdict, validator))

    @classmethod
    async def p_find_multiple(cls, options: dict = {}) -> Type[ListType]:
        """
        get multiple documents
        """
        validator = options.pop("_validator", cls.DT)
        docsdict = await cls.find_multiple(options)
        objs = [encode_model(d, validator) for d in docsdict]
        return cls.LT(**{cls.ItemField: objs})

    @classmethod
    async def p_update(
        cls, id: str, upd: Type[DocumentType], options: dict = {}
    ) -> Type[DocumentType]:
        """
        get multiple documents
        leaves NotFound raised
        """
        validator = options.pop("_validator", cls.DT)
        cdict = await cls.update(id, upd.dict(exclude_unset=True), options)
        return cast(cls.DT, encode_model(cdict, validator))
