# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from typing import Type, List
from reddevil.core import RdInternalServerError
from pydantic import BaseModel

log = logging.getLogger(__name__)


class DocumentType(BaseModel):
    pass


class ListType(BaseModel):
    pass


def encode_model(e: dict, validator_class: Type[DocumentType]) -> DocumentType:
    """
    validates and encodes a result dict as a validator class
    """
    log.debug(f"encoding a validating {validator_class}")
    try:
        eo = validator_class(**e)
    except Exception:
        log.exception(f"cannot encode model {validator_class}")
        raise RdInternalServerError(description=f"CannotEncode{validator_class}")
    return eo
