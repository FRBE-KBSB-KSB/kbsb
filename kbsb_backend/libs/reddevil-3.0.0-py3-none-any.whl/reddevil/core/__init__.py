# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# variables common for all reddevil modules

from .colorlogfactory import c_factory
from .register import (
    register_app,
    get_app,
    get_settings,
    get_baseurl,
)
from .errors import (
    RdBadRequest,
    RdException,
    RdInternalServerError,
    RdNotFound,
    RdNotAuthorized,
)
from .security import (
    bearer_schema,
    get_tokensalt,
    hash_password,
    jwt_encode,
    jwt_getunverifiedpayload,
    jwt_verify,
    validate_token,
    verify_password,
)
from .model import (
    encode_model,
    DocumentType,
    ListType,
)
from .secrets import (
    secretmanager_client,
    get_secret,
)
from .mongodb import (
    connect_mongodb,
    close_mongodb,
    get_mongodb,
    date2datetime,
)
from .base import DbBase
