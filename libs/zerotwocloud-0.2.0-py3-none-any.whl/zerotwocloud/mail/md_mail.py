# Same dataclasses as reddevil.mail.md_mail, field for field, so existing
# positional and keyword construction keeps working after an import switch.
# Plain dataclasses rather than pydantic, for the same reason reddevil gives:
# these are never parsed from an API body.

from dataclasses import dataclass, field


@dataclass
class MailAttachment:
    filename: str  # filename of attachment
    mimetype: str  # mimetype of attachment, "maintype/subtype"
    content_base64: bytes  # base64 encoded content


@dataclass
class MailParams:
    locale: str
    receiver: str
    sender: str
    subject: str
    template: str
    attachments: list[MailAttachment] = field(default_factory=list)
    bcc: str = ""
    cc: str = ""
    # Added last, with a default, so nobody's positional arguments shift.
    reply_to: str = ""
