# The configuration hook that stands in for reddevil.core's get_settings and
# get_setting.
#
# reddevil reads a settings module registered with register_app. This package
# is mounted inside a host app that already registered its own settings for
# reddevil, so it must not share or depend on them. Settings resolve, in
# order of precedence, from:
#   1. configure() calls (a library user, or a test),
#   2. ZC_MAIL_* environment variables,
#   3. the defaults below.
#
# The defaults exist so the host needs no app.yaml change to mount the
# router. They name infrastructure (which account signs, which mailbox sends,
# where the caller list lives), never a message's sender or recipients: the
# sender comes from the caller list, and no Bcc is ever configured here.
#
# Nothing in this module raises. A bad value is only noticed by the code that
# needs it, per request, so the host app always boots.

import os
import threading
from typing import Any

DEFAULT_BACKEND = "GMAIL"
# The service account that holds the domain-wide delegation grant and is the
# `iss` of the delegation JWT. It is NOT the identity the code runs as: the
# host's runtime identity asks IAM to sign on this account's behalf.
DEFAULT_SERVICE_ACCOUNT = "zerotwocloud-mail@website-kbsb-prod.iam.gserviceaccount.com"
# The Workspace user mail is sent as (the delegation `sub`).
DEFAULT_DELEGATED_USER = "noreply-jorian@frbe-kbsb-ksb.be"
# Secret Manager version holding the caller list (see callers.py).
DEFAULT_CALLERS_SECRET = (
    "projects/website-kbsb-prod/secrets/zerotwocloud-mail-callers/versions/latest"
)

_lock = threading.Lock()
_overrides: dict[str, Any] = {}


class Settings:
    """
    Attribute bag with the attribute names reddevil's mail code reads, EMAIL
    (a dict), TEMPLATES_MODULE and TEMPLATES_PATH, plus CALLERS_SECRET for the
    HTTP router.

    EMAIL keys used by this package:
      backend          "GMAIL" or "TEST"
      account          the Workspace user mail is sent as (delegated user)
      service_account  the service account named in the delegation JWT
    """

    def __init__(self, values: dict[str, Any]):
        for key, value in values.items():
            setattr(self, key, value)


def _env(name: str, default: str) -> str:
    # An empty variable counts as unset, so a blank line in an env file does
    # not silently blank out the account.
    return os.environ.get(name) or default


def _from_environment() -> dict[str, Any]:
    return {
        "EMAIL": {
            "backend": _env("ZC_MAIL_BACKEND", DEFAULT_BACKEND),
            "account": _env("ZC_MAIL_DELEGATED_USER", DEFAULT_DELEGATED_USER),
            "service_account": _env("ZC_MAIL_SERVICE_ACCOUNT", DEFAULT_SERVICE_ACCOUNT),
        },
        "CALLERS_SECRET": _env("ZC_MAIL_CALLERS_SECRET", DEFAULT_CALLERS_SECRET),
        "TEMPLATES_MODULE": _env("ZC_MAIL_TEMPLATES_MODULE", ""),
        "TEMPLATES_PATH": _env("ZC_MAIL_TEMPLATES_PATH", ""),
    }


def configure(**settings: Any) -> None:
    """
    Override settings for this process, for example
    configure(EMAIL={"backend": "TEST"}).

    EMAIL is merged key by key, so a caller can change the backend without
    restating the account.
    """
    with _lock:
        for key, value in settings.items():
            if key == "EMAIL":
                merged = dict(_overrides.get("EMAIL", {}))
                merged.update(value)
                _overrides["EMAIL"] = merged
            else:
                _overrides[key] = value


def reset_settings() -> None:
    """Forget every configure() override; environment and defaults apply again."""
    with _lock:
        _overrides.clear()


def get_settings() -> Settings:
    # Rebuilt on every call rather than cached: it is a handful of lookups,
    # and it means configure() after import takes effect, which reddevil's
    # import-time read of EMAIL did not allow.
    values = _from_environment()
    with _lock:
        for key, value in _overrides.items():
            if key == "EMAIL":
                values["EMAIL"] = {**values["EMAIL"], **value}
            else:
                values[key] = value
    return Settings(values)


def get_setting(key: str) -> Any:
    return getattr(get_settings(), key)
