# Exceptions for the mail package.
#
# Shaped like reddevil.core.errors (a status_code and a description on the
# instance) so code that inspects RdMailError's attributes keeps working. The
# one structural change: the description is also passed to Exception, so
# str(exc) and tracebacks say what went wrong instead of printing nothing.


class ZcException(Exception):
    def __init__(self, status_code=500, description="Unknown"):
        super().__init__(description)
        self.status_code = status_code
        self.description = description


class ZcMailError(ZcException):
    # 502, not RdMailError's 400: a failed send is the mail provider's
    # refusal or absence, not a mistake in the caller's request.
    def __init__(self, description="MailError", status_code=502):
        super().__init__(status_code=status_code, description=description)


class ZcBadRequest(ZcMailError):
    # A subclass of ZcMailError so that catching ZcMailError is enough to be
    # told about every message that was not sent, whatever the reason.
    def __init__(self, description="BadRequest"):
        super().__init__(description=description, status_code=400)
