# Message building and dispatch, with the same public functions and
# signatures as reddevil.mail.mail.
#
# The behavioural difference that matters: reddevil wraps every send in
# `except Exception: logger.exception("failed")`, so a caller cannot tell a
# sent message from a lost one. Here nothing is swallowed. Each function
# returns the backend's message id after the backend accepted the message,
# and raises otherwise.
#
# jinja2 and markdown2 are imported only by the template based functions, so
# the HTTP service (which only uses sendEmailMessage) does not need them.

import base64
import binascii
import logging
from email import encoders
from email.message import EmailMessage, Message
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html.parser import HTMLParser
from pathlib import Path

from . import mailbackend
from .config import get_settings
from .errors import ZcBadRequest, ZcMailError
from .md_mail import MailParams

logger = logging.getLogger("zerotwocloud.mail")


def _markdown():
    if not hasattr(_markdown, "md"):
        from markdown2 import Markdown

        _markdown.md = Markdown(extras=["tables", "metadata"])  # type: ignore
    return _markdown.md  # type: ignore


def get_template_env():
    if not hasattr(get_template_env, "env"):
        from jinja2 import Environment, PackageLoader

        settings = get_settings()
        if not getattr(settings, "TEMPLATES_MODULE", ""):
            raise ZcMailError("TemplatesModuleNotConfigured", status_code=500)
        get_template_env.env = Environment(  # type: ignore
            loader=PackageLoader(settings.TEMPLATES_MODULE), trim_blocks=True  # type: ignore
        )
    return get_template_env.env  # type: ignore


def getCss():
    settings = get_settings()
    if not hasattr(getCss, "css"):
        if not getattr(settings, "TEMPLATES_PATH", ""):
            raise ZcMailError("TemplatesPathNotConfigured", status_code=500)
        with open(Path(settings.TEMPLATES_PATH) / "markdown.css") as f:  # type: ignore
            getCss.css = f.read()  # type: ignore
    return getCss.css  # type: ignore


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data):
        self.parts.append(data)


def _html_to_text(html: str) -> str:
    # Stands in for bs4's get_text(): the concatenated text nodes.
    parser = _TextExtractor()
    parser.feed(html)
    parser.close()
    return "".join(parser.parts)


def _set_headers(msg: Message, mp: MailParams, subject: str) -> None:
    # A CR or LF in a header value would let whoever controls the value add
    # headers of their own (a Bcc, say). The HTTP service passes the subject
    # and recipients straight from a request body, so refuse them outright
    # rather than relying on each email policy to notice.
    values = {
        "Subject": subject,
        "From": mp.sender,
        "To": mp.receiver,
        "Cc": mp.cc,
        "Bcc": mp.bcc,
        "Reply-To": mp.reply_to,
    }
    for header, value in values.items():
        if value and ("\r" in value or "\n" in value):
            raise ZcBadRequest(f"InvalidHeader: {header} contains a line break")
    msg["Subject"] = subject
    msg["From"] = mp.sender
    # Set even when empty: the website bridge relies on a bare To header for
    # bcc-only messages.
    msg["To"] = mp.receiver
    if mp.cc:
        msg["Cc"] = mp.cc
    # Only what the caller asked for. The library never adds a Bcc of its own.
    if mp.bcc:
        msg["Bcc"] = mp.bcc
    if mp.reply_to:
        msg["Reply-To"] = mp.reply_to


def _send(msg: Message) -> str:
    name = get_settings().EMAIL.get("backend", "")  # type: ignore
    try:
        backend_class = mailbackend.backends[name]
    except KeyError:
        raise ZcMailError(f"UnknownEmailBackend: {name!r}", status_code=500) from None
    return backend_class().send_message(msg)


def _short(subject: str) -> str:
    return subject if len(subject) < 20 else subject[0:17] + "..."


def sendEmail(mp: MailParams, context: dict, name: str = ""):
    """
    dispatcher for emails
    """
    attachments = mp.attachments
    if not attachments:
        return sendEmailNoAttachments(mp, context, name)
    if len(attachments) == 1 and attachments[0].mimetype == "application/pdf":
        return sendEmailWithPdf(mp, context, name)
    logger.error("emails with more than 1 attachment not yet supported")
    raise ZcMailError("TooManyAttachments", status_code=503)


def _render(mp: MailParams, context: dict):
    env = get_template_env()
    tmpl = env.get_template(mp.template.format(locale=context["locale"]))
    markdowntext = tmpl.render(**context)
    htmltext = _markdown().convert(markdowntext)
    return markdowntext, htmltext


def _related_message(mp: MailParams, markdowntext: str, htmltext) -> MIMEMultipart:
    msg = MIMEMultipart("related")
    subject = htmltext.metadata.get("title") or mp.subject
    _set_headers(msg, mp, subject)
    msg.preamble = "This is a multi-part message in MIME format."
    msgAlternative = MIMEMultipart("alternative")
    msgAlternative.attach(MIMEText(markdowntext))
    msgAlternative.attach(MIMEText(str(htmltext), "html"))
    msg.attach(msgAlternative)
    return msg


def sendEmailNoAttachments(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with no attachment
    """
    markdowntext, htmltext = _render(mp, context)
    msg = _related_message(mp, markdowntext, htmltext)
    message_id = _send(msg)
    logger.info(f"email {name} sent, id {message_id}")
    return message_id


def _decode_attachment(att) -> tuple[str, str, bytes]:
    try:
        maintype, subtype = att.mimetype.split("/")
    except ValueError:
        raise ZcBadRequest(f"attachment {att.filename} has invalid mimetype") from None
    try:
        content = base64.b64decode(att.content_base64)
    except (binascii.Error, ValueError, TypeError):
        raise ZcBadRequest(f"attachment {att.filename} is not valid base64") from None
    return maintype, subtype, content


def sendEmailMessage(mp: MailParams):
    """
    sends an HTML email with plain text alternative and optional attachments
    using the EmailMessage class
    """
    htmltext = mp.template
    plaintext = _html_to_text(htmltext)
    logger.debug(f"sendingEmailMessage with {len(mp.attachments)} attachments")
    msg = EmailMessage()
    _set_headers(msg, mp, mp.subject)
    msg.set_content(plaintext)
    msg.add_alternative(htmltext, subtype="html")
    for att in mp.attachments:
        logger.debug(f"adding attachment {att.filename}")
        maintype, subtype, content = _decode_attachment(att)
        msg.add_attachment(
            content,
            maintype=maintype,
            subtype=subtype,
            filename=att.filename,
        )
    message_id = _send(msg)
    logger.info(f"sendEmailMessage {_short(mp.subject)} sent, id {message_id}")
    return message_id


def sendEmailWithPdf(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with a pdf attachment
    """
    markdowntext, htmltext = _render(mp, context)
    msg = _related_message(mp, markdowntext, htmltext)
    att = mp.attachments[0]
    maintype, subtype, content = _decode_attachment(att)
    # reddevil attached an empty BytesIO here, so every "PDF" arrived as a
    # zero byte file. This attaches the content that was passed in.
    msgAtt = MIMEBase(maintype, subtype)
    msgAtt.set_payload(content)
    encoders.encode_base64(msgAtt)
    msgAtt.add_header("Content-Disposition", "attachment", filename=att.filename)
    msg.attach(msgAtt)
    message_id = _send(msg)
    logger.info(f"email {name} with pdf sent, id {message_id}")
    return message_id
