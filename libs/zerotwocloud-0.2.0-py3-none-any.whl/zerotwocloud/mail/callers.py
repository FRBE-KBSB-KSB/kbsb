# Who may send, as whom, and how often.
#
# The caller list lives in one Secret Manager secret so that adding a caller,
# rotating a key or changing a limit is a new secret version, not a deploy.
# It holds only SHA-256 hashes of the callers' keys: the raw keys stay with
# the callers, so reading the secret (or a log of it) does not let anyone
# send mail.

import base64
import hashlib
import hmac
import json
import logging
import re
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable

from .errors import ZcMailError
from .mailbackend import check_sender

log = logging.getLogger("zerotwocloud.mail")

SECRET_MANAGER_ACCESS_URL = "https://secretmanager.googleapis.com/v1/{name}:access"
SECRET_RESOURCE_RE = re.compile(r"^projects/[^/]+/secrets/[^/]+/versions/[^/]+$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")


class CallersUnavailable(Exception):
    """The caller list could not be fetched and there is no earlier copy."""


class CallersConfigError(Exception):
    """The caller list was fetched but is not acceptable."""


@dataclass(frozen=True)
class Caller:
    name: str
    sha256: str
    sender: str
    reply_to: str
    per_hour: int


def parse_callers(raw: bytes | str, delegated_user: str) -> dict[str, Caller]:
    """
    Validate the whole caller list or refuse it.

    All or nothing on purpose: a list with one bad entry is a list somebody
    edited by hand and got wrong, and serving the rest of it would hide that.
    """
    try:
        data = json.loads(raw)
    except (ValueError, TypeError) as e:
        raise CallersConfigError(f"caller secret is not JSON: {type(e).__name__}") from e
    if not isinstance(data, dict) or not data:
        raise CallersConfigError("caller secret must be a non-empty JSON object")

    callers: dict[str, Caller] = {}
    seen_hashes: set[str] = set()
    for name, entry in data.items():
        if not isinstance(name, str) or not name.strip():
            raise CallersConfigError("caller name must be a non-empty string")
        if not isinstance(entry, dict):
            raise CallersConfigError(f"caller {name}: entry must be an object")

        digest = entry.get("sha256")
        if not isinstance(digest, str) or not _HEX64.match(digest.strip().lower()):
            raise CallersConfigError(f"caller {name}: sha256 must be 64 hex characters")
        digest = digest.strip().lower()
        if digest in seen_hashes:
            # Two callers with one key could not be told apart in the logs
            # or in the rate limit.
            raise CallersConfigError(f"caller {name}: sha256 duplicates another caller")
        seen_hashes.add(digest)

        sender = entry.get("sender")
        if not isinstance(sender, str) or not sender.strip():
            raise CallersConfigError(f"caller {name}: sender is required")
        if delegated_user:
            try:
                check_sender(sender, delegated_user)
            except ZcMailError as e:
                raise CallersConfigError(f"caller {name}: {e.description}") from e

        reply_to = entry.get("reply_to", "")
        if reply_to is None:
            reply_to = ""
        if not isinstance(reply_to, str) or "\r" in reply_to or "\n" in reply_to:
            raise CallersConfigError(f"caller {name}: reply_to must be a single line string")

        per_hour = entry.get("per_hour")
        if isinstance(per_hour, bool) or not isinstance(per_hour, int) or per_hour <= 0:
            raise CallersConfigError(f"caller {name}: per_hour must be a positive integer")

        callers[name] = Caller(
            name=name,
            sha256=digest,
            sender=sender.strip(),
            reply_to=reply_to.strip(),
            per_hour=per_hour,
        )
    return callers


def _authorized_session():
    import google.auth
    from google.auth.transport.requests import AuthorizedSession

    credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return AuthorizedSession(credentials)


class SecretManagerPayload:
    """
    Reads one secret version over the Secret Manager REST API, as the
    runtime's default identity (which therefore needs
    roles/secretmanager.secretAccessor on this secret).

    REST through google-auth rather than the google-cloud-secret-manager
    client: it is the same session type the signJwt call uses, so there is
    one HTTP path to fake in tests and to reason about. Constructing it does
    no I/O; a malformed name raises ValueError, which the router constructs
    per request and reports as a misconfiguration rather than at import.
    """

    def __init__(self, resource_name: str):
        if not SECRET_RESOURCE_RE.match(resource_name or ""):
            raise ValueError(
                "secret resource name must look like projects/P/secrets/S/versions/V"
            )
        self.resource_name = resource_name
        self._session = None

    def __call__(self) -> bytes:
        if self._session is None:
            self._session = _authorized_session()
        resp = self._session.get(
            SECRET_MANAGER_ACCESS_URL.format(name=self.resource_name), timeout=(5, 10)
        )
        if resp.status_code != 200:
            raise CallersUnavailable(f"Secret Manager answered HTTP {resp.status_code}")
        return base64.b64decode(resp.json()["payload"]["data"])


class CallerRegistry:
    def __init__(
        self,
        load: Callable[[], bytes],
        delegated_user: str,
        ttl_seconds: float = 300.0,
        failure_backoff_seconds: float = 60.0,
        clock: Callable[[], float] = time.monotonic,
    ):
        self._load = load
        self._delegated_user = delegated_user
        self._ttl = ttl_seconds
        self._backoff = failure_backoff_seconds
        self._clock = clock
        self._lock = threading.Lock()
        self._callers: dict[str, Caller] | None = None
        self._error: Exception | None = None
        self._next_refresh = 0.0

    def callers(self) -> dict[str, Caller]:
        with self._lock:
            now = self._clock()
            if now < self._next_refresh:
                if self._error is not None:
                    raise self._error
                if self._callers is not None:
                    return self._callers

            try:
                raw = self._load()
            except Exception as e:
                self._next_refresh = now + self._backoff
                if self._callers is not None and self._error is None:
                    # A Secret Manager hiccup should not stop mail that was
                    # authorised a few minutes ago.
                    log.warning("caller secret refresh failed, keeping the previous list: %s",
                                type(e).__name__)
                    return self._callers
                self._error = CallersUnavailable(f"caller secret unavailable: {type(e).__name__}")
                raise self._error from e

            try:
                callers = parse_callers(raw, self._delegated_user)
            except CallersConfigError as e:
                # Fail closed: an unacceptable new version must not be papered
                # over by the old one, or a sender change would appear to work.
                log.error("caller secret refused: %s", e)
                self._callers = None
                self._error = e
                self._next_refresh = now + self._backoff
                raise

            self._callers = callers
            self._error = None
            self._next_refresh = now + self._ttl
            return callers

    def authenticate(self, presented: str) -> Caller | None:
        callers = self.callers()
        if not presented:
            return None
        digest = hashlib.sha256(presented.encode("utf-8")).hexdigest()
        match = None
        # Compare against every caller without stopping at a match, so the
        # time taken does not depend on which caller, if any, matched.
        for caller in callers.values():
            if hmac.compare_digest(digest, caller.sha256):
                match = caller
        return match


class RateLimiter:
    """
    Sliding one hour window per caller, in memory.

    PER PROCESS, and so per instance: the host app autoscales, and each
    instance (and each worker process within one) keeps its own window. With
    N instances a caller can send up to N times per_hour. It is a brake on a
    runaway loop in a caller, not an exact quota; an exact quota would need
    shared state (a database or Memorystore) that this router does not
    otherwise need. A restart forgets the window, which errs towards allowing
    a little more mail, never less.
    """

    def __init__(self, clock: Callable[[], float] = time.monotonic, window_seconds: float = 3600.0):
        self._clock = clock
        self._window = window_seconds
        self._lock = threading.Lock()
        self._events: dict[str, deque] = defaultdict(deque)

    def allow(self, name: str, limit: int) -> bool:
        with self._lock:
            now = self._clock()
            events = self._events[name]
            while events and events[0] <= now - self._window:
                events.popleft()
            if len(events) >= limit:
                return False
            events.append(now)
            return True
