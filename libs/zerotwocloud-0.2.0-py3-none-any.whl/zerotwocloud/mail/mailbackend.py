# Mail backends, selected by name through the `backends` registry exactly as
# in reddevil.mail.mailbackend: backends[settings.EMAIL["backend"]]().
#
# GMAIL sends through the Gmail API as a Workspace user, using domain-wide
# delegation WITHOUT a stored service-account key. There is no key file to
# leak, rotate or forget about.
#
# Two identities are involved, and they are deliberately different:
#   * the RUNTIME identity: whatever default credentials the process has. When
#     mounted in the website this is the website's App Engine default service
#     account, taken from the metadata server. It only ever calls signJwt.
#   * the CONFIGURED service account (EMAIL["service_account"],
#     zerotwocloud-mail@...). It holds the domain-wide delegation grant in
#     Workspace, is the `iss` of the JWT, and is the account whose Google
#     managed key signs it. The runtime identity needs
#     roles/iam.serviceAccountTokenCreator on this account, nothing more.
# The signed JWT is then exchanged for a gmail.send access token.
#
# TEST keeps messages in memory for tests.
#
# There are no SMTP backends. App Engine has no fixed outbound address to put
# on a relay's allow list, and this service does not use the Workspace SMTP
# relay at all.

import base64
import email
import email.policy
import json
import logging
import threading
import time
from dataclasses import dataclass
from email.message import Message
from email.utils import getaddresses

import requests

from .config import get_setting
from .errors import ZcMailError

log = logging.getLogger("zerotwocloud.mail")

# Only the scope needed to send. Delegation is granted per scope in the
# Workspace admin console; asking for more here would fail there, and
# granting more there would be a larger blast radius for no benefit.
GMAIL_SEND_SCOPE = "https://www.googleapis.com/auth/gmail.send"
# The scope the runtime's own credentials need to call signJwt.
IAM_SCOPE = "https://www.googleapis.com/auth/cloud-platform"

SIGN_JWT_URL = (
    "https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/{account}:signJwt"
)
TOKEN_URL = "https://oauth2.googleapis.com/token"
JWT_BEARER_GRANT = "urn:ietf:params:oauth:grant-type:jwt-bearer"
GMAIL_SEND_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"

# Google refuses delegation JWTs that live longer than an hour.
JWT_LIFETIME_SECONDS = 3600
# Refresh this long before expiry, so a token never runs out between being
# read from the cache and reaching Gmail.
TOKEN_REFRESH_MARGIN_SECONDS = 300

# Bounded retry on transient Gmail answers (429, 5xx). The total is capped
# because the callers give up after about 20 seconds (the database manager's
# MailBridge waits 20); a send that finally succeeds after the caller has
# already reported failure is a lie in the other direction, and a person who
# then presses Confirm again sends it twice.
#
# So a retry only starts when a complete attempt still fits inside the budget,
# not merely when some time is left. Checking only time spent plus the backoff
# let a retry start at 11 seconds and land at 20.
SEND_ATTEMPTS = 3
SEND_BACKOFF_SECONDS = (1.0, 2.0)
SEND_DEADLINE_SECONDS = 15.0
# (connect, read). Gmail answers a send in well under two seconds; these only
# bound the bad case, and their sum is what one attempt can cost.
HTTP_TIMEOUT = (3, 6)
ATTEMPT_WORST_CASE_SECONDS = HTTP_TIMEOUT[0] + HTTP_TIMEOUT[1]

# Indirections so tests can control time without sleeping.
_clock = time.time
_monotonic = time.monotonic
_sleep = time.sleep


class BaseEmailBackend:
    def send_message(self, msg: Message) -> str:
        raise ZcMailError("EmailBackendNotImplemented", status_code=503)


def check_sender(sender: str, account: str) -> None:
    """
    Refuse a From header whose address is not the delegated user's.

    Gmail does not reject a From address the delegated user may not send as;
    it silently replaces it. That silent rewrite is how unexpected sender
    addresses reached recipients before, so a mismatch is an error here,
    before anything is sent. "Name <address>" is accepted when the address
    matches.
    """
    if not account or not account.strip():
        raise ZcMailError("DelegatedUserNotConfigured", status_code=500)
    # Every parsed entry counts, empty ones included: getaddresses turns
    # unparseable input such as "a@x <b@y>" into an empty entry, and dropping
    # those would let a malformed header through as if it were clean.
    parsed = getaddresses([sender or ""])
    if len(parsed) != 1 or not parsed[0][1]:
        raise ZcMailError("SenderInvalid: expected exactly one sender address", status_code=500)
    name, addr = parsed[0]
    if addr.strip().casefold() != account.strip().casefold():
        raise ZcMailError(
            f"SenderNotDelegatedUser: sender {addr} is not the delegated user {account}",
            status_code=500,
        )
    # A display name that is itself an address shows recipients a sender
    # that is not the real one, which is the problem this check exists for.
    if "@" in name:
        raise ZcMailError("SenderInvalid: display name contains an address", status_code=500)


def check_wire_sender(wire: bytes, account: str) -> None:
    """
    Apply check_sender to the From header exactly as it will be sent.

    Checked on the serialised bytes, not on the Message object, because the
    object's header view can differ from what goes out: the default email
    policy reads "a@x <b@y>" as a clean "a@x" while the bytes still say
    "a@x <b@y>".
    """
    headers = email.message_from_bytes(wire, policy=email.policy.compat32)
    froms = headers.get_all("From") or []
    if len(froms) != 1:
        raise ZcMailError("SenderInvalid: expected exactly one From header", status_code=500)
    check_sender(str(froms[0]), account)


_session_lock = threading.Lock()
_sessions: dict[str, requests.Session] = {}


def _iam_session() -> requests.Session:
    """
    A session carrying the RUNTIME's default credentials (on App Engine, the
    host service's own account from the metadata server). Used only for
    signJwt; it is never used to call Gmail.
    """
    with _session_lock:
        if "iam" not in _sessions:
            try:
                import google.auth
                from google.auth.transport.requests import AuthorizedSession

                credentials, _ = google.auth.default(scopes=[IAM_SCOPE])
            except Exception as e:
                raise ZcMailError(
                    f"GmailCredentialsUnavailable: {type(e).__name__}", status_code=503
                ) from e
            _sessions["iam"] = AuthorizedSession(credentials)
        return _sessions["iam"]


def _plain_session() -> requests.Session:
    """An unauthenticated session for the token endpoint and for Gmail."""
    with _session_lock:
        if "plain" not in _sessions:
            _sessions["plain"] = requests.Session()
        return _sessions["plain"]


def _error_reason(resp) -> str:
    """A short, human reason from a Google error response."""
    reason = ""
    try:
        body = resp.json()
    except Exception:
        body = None
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            reason = err.get("message") or err.get("status") or ""
        elif isinstance(err, str):
            # The OAuth token endpoint's shape: {"error": ..., "error_description": ...}
            reason = err
            if body.get("error_description"):
                reason = f"{err}: {body['error_description']}"
    if not reason:
        reason = (getattr(resp, "text", "") or "")[:200]
    return f"HTTP {resp.status_code} {reason}".strip()


class DelegatedTokenSource:
    """
    Access tokens for one (service account, delegated user) pair, cached until
    shortly before they expire.
    """

    def __init__(self, service_account: str, subject: str, scope: str = GMAIL_SEND_SCOPE):
        self.service_account = service_account
        self.subject = subject
        self.scope = scope
        self._lock = threading.Lock()
        self._token = ""
        self._expires_at = 0

    def claims(self, now: int) -> dict:
        return {
            "iss": self.service_account,
            "sub": self.subject,
            "scope": self.scope,
            "aud": TOKEN_URL,
            "iat": now,
            "exp": now + JWT_LIFETIME_SECONDS,
        }

    def token(self) -> str:
        with self._lock:
            now = int(_clock())
            if self._token and now < self._expires_at - TOKEN_REFRESH_MARGIN_SECONDS:
                return self._token
            self._token, self._expires_at = self._fetch(now)
            return self._token

    def invalidate(self) -> None:
        with self._lock:
            self._token = ""
            self._expires_at = 0

    def _fetch(self, now: int) -> tuple[str, int]:
        claims = self.claims(now)
        # The URL names the CONFIGURED service account, not the caller's own
        # identity: the runtime asks IAM to sign as zerotwocloud-mail, which
        # works only if it has Token Creator on that account.
        url = SIGN_JWT_URL.format(account=self.service_account)
        try:
            resp = _iam_session().post(
                url, json={"payload": json.dumps(claims)}, timeout=HTTP_TIMEOUT
            )
        except requests.RequestException as e:
            raise ZcMailError(f"GmailTokenUnavailable: signJwt {type(e).__name__}") from e
        if resp.status_code != 200:
            raise ZcMailError(f"GmailTokenUnavailable: signJwt {_error_reason(resp)}")
        signed = (resp.json() or {}).get("signedJwt")
        if not signed:
            raise ZcMailError("GmailTokenUnavailable: signJwt returned no signedJwt")

        try:
            resp = _plain_session().post(
                TOKEN_URL,
                data={"grant_type": JWT_BEARER_GRANT, "assertion": signed},
                timeout=HTTP_TIMEOUT,
            )
        except requests.RequestException as e:
            raise ZcMailError(f"GmailTokenUnavailable: token {type(e).__name__}") from e
        if resp.status_code != 200:
            # unauthorized_client here usually means domain-wide delegation
            # is not granted for this client id and scope.
            raise ZcMailError(f"GmailTokenUnavailable: token {_error_reason(resp)}")
        body = resp.json() or {}
        access_token = body.get("access_token")
        if not access_token:
            raise ZcMailError("GmailTokenUnavailable: token endpoint returned no access_token")
        expires_in = int(body.get("expires_in") or JWT_LIFETIME_SECONDS)
        return access_token, now + min(expires_in, JWT_LIFETIME_SECONDS)


_token_lock = threading.Lock()
_token_sources: dict[tuple[str, str], DelegatedTokenSource] = {}


def get_token_source(service_account: str, subject: str) -> DelegatedTokenSource:
    with _token_lock:
        key = (service_account, subject)
        if key not in _token_sources:
            _token_sources[key] = DelegatedTokenSource(service_account, subject)
        return _token_sources[key]


def reset_token_cache() -> None:
    with _token_lock:
        _token_sources.clear()
    with _session_lock:
        _sessions.clear()


class GmailBackend(BaseEmailBackend):
    def send_message(self, msg: Message) -> str:
        """
        Send msg as the delegated user and return Gmail's message id.

        Returns only after Gmail accepted the message. Every other outcome
        raises ZcMailError, including a timeout, which is reported as a
        failure even though Gmail may have delivered: it is not retried,
        because a retry could deliver twice.
        """
        email_settings = get_setting("EMAIL")
        account = email_settings.get("account", "")
        service_account = email_settings.get("service_account", "")
        wire = msg.as_bytes()
        check_wire_sender(wire, account)
        if not service_account:
            raise ZcMailError("GmailServiceAccountNotConfigured", status_code=500)

        raw = base64.urlsafe_b64encode(wire).decode("ascii")
        source = get_token_source(service_account, account)
        started = _monotonic()
        attempt = 0
        while True:
            attempt += 1
            token = source.token()
            try:
                resp = _plain_session().post(
                    GMAIL_SEND_URL,
                    json={"raw": raw},
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=HTTP_TIMEOUT,
                )
            except requests.RequestException as e:
                raise ZcMailError(f"GmailSendEmailFailed: {type(e).__name__}") from e

            if 200 <= resp.status_code < 300:
                try:
                    message_id = (resp.json() or {}).get("id")
                except ValueError:
                    message_id = None
                if not message_id:
                    raise ZcMailError("GmailSendEmailFailed: Gmail returned no message id")
                return message_id

            reason = _error_reason(resp)
            if resp.status_code == 401:
                # A cached token Gmail no longer accepts; the next send
                # fetches a fresh one instead of failing until expiry.
                source.invalidate()
            transient = resp.status_code == 429 or resp.status_code >= 500
            if transient and attempt < SEND_ATTEMPTS:
                delay = SEND_BACKOFF_SECONDS[attempt - 1]
                fits = (
                    _monotonic() - started + delay + ATTEMPT_WORST_CASE_SECONDS
                    < SEND_DEADLINE_SECONDS
                )
                if fits:
                    log.warning(
                        "Gmail send attempt %d failed (%s), retrying in %.1fs",
                        attempt, reason, delay,
                    )
                    _sleep(delay)
                    continue
            raise ZcMailError(f"GmailSendEmailFailed: {reason} after {attempt} attempt(s)")


@dataclass
class SentMessage:
    id: str
    message: Message


class InMemoryBackend(BaseEmailBackend):
    """
    Records messages instead of sending them. Enforces the same sender rule
    as GMAIL whenever a delegated user is configured, so a test cannot pass
    with a sender production would refuse.
    """

    outbox: list[SentMessage] = []
    _lock = threading.Lock()
    _counter = 0

    def send_message(self, msg: Message) -> str:
        account = get_setting("EMAIL").get("account", "")
        if account:
            check_wire_sender(msg.as_bytes(), account)
        with InMemoryBackend._lock:
            InMemoryBackend._counter += 1
            message_id = f"test-{InMemoryBackend._counter}"
            InMemoryBackend.outbox.append(SentMessage(message_id, msg))
        return message_id

    @classmethod
    def reset(cls) -> None:
        with cls._lock:
            cls.outbox.clear()
            cls._counter = 0


backends = {
    "GMAIL": GmailBackend,
    "TEST": InMemoryBackend,
}
