#    Copyright 2019 Chessdevil Consulting

import os

MONGO_URL = 'mongodb://localhost:27017/'
MONGO_DB = 'testrunner'

ACCOUNT_DOMAIN = 'runreddevil'

EMAIL= {
  'backend': 'SMTP',
  'host': 'localhost',
  'port': '1025',
  'sender': 'testrunner@chessdevil.net.com',
  'bcc': '',
}

LOG_CONFIG = {
    'version': 1,
    'formatters': {
        'simple': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        },
        'color': {
            'format':
            '%(log_color)s%(levelname)s%(reset)s: %(asctime)s %(bold)s%(name)s%(reset)s %(message)s',
            '()': 'reddevil.common.colorlogfactory.c_factory',
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'level': 'INFO',
            'formatter': 'color',
            'stream': 'ext://sys.stderr'
        }
    },
    'loggers': {
        'testrunner': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'reddevil': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'fastapi': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'uvicorn': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    }
}

GOOGLE_CLIENT_ID = '245790708099-vnd4m1ohdaqha4pbhbj2lecrmpnp8kkj.apps.googleusercontent.com'

GOOGLE_LOGIN_DOMAINS = ['chessdevil.net']

TOKEN = {
    "timeout":  180,    # timeout in minutes
    "secret": "Bluufmejefikknvan",
    "emailtimeouthours": 2,
    "emailsecret": "Bluufookvanmienfikkn",
    "algorithm": "HS256",
    "nocheck": False,
}

try:
    from local_settings import *
    print('local settings loaded')
except ImportError:
    print('No local settings found')
