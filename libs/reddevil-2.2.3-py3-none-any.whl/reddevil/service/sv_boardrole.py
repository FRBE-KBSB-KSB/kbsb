# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging, json, os, uuid, os
from datetime import datetime, timezone, date
from slugify import slugify
from mimetypes import guess_type
from random import randrange
from base64 import b64encode, b64decode
from typing import List, Optional, Union

from reddevil.common import (
    cfg,
    check_token,
    RdInternalServerError, 
    RdBadRequest,
)

from reddevil.models.md_boardrole import (
    BoardRoleIn,
    BoardRoleOut,
    BoardRoleUpdate,
    BoardRoleListOut,
    BoardRoleOptional,
)

from reddevil.crud.db_boardrole import DbBoardRole

log = logging.getLogger(__name__)

def encode_boardrole(e: dict, _class=BoardRoleOut):
    try:
        eo = _class(**e)
    except Exception:
        log.exception('cannot encode BoardRole')
        raise RdInternalServerError(description='CannotEncodeBoardRole')
    return eo

async def createBoardRole(d: BoardRoleIn) -> str:
    """
    create a new BoardRole returning its id
    """
    bd = d.dict()
    bd['title'] = dict(default=dict(value=bd['name']))
    return await DbBoardRole.add(bd)

async def deleteBoardRole(id: str) -> None:
    await DbBoardRole.delete(id)

async def getBoardRole(id: str, options: dict= {}) -> BoardRoleOut:
    """
    get the boardrole 
    """
    _class = options.pop('_class', BoardRoleOut)
    filter = dict(id=id, **options)
    bdict = await DbBoardRole.find_single(filter)
    return encode_boardrole(bdict, _class)

async def getBoardRoles(options: dict={}) -> BoardRoleListOut:
    """
    get all the BoardRoles
    """
    _class = options.pop('_class', BoardRoleOut)
    docs = await DbBoardRole.find_multiple(options)
    boardroles = [encode_boardrole(d, _class) for d in docs]
    return BoardRoleListOut(roles=boardroles)    

async def updateBoardRole(id: str, d: BoardRoleUpdate) -> BoardRoleOut:
    """
    update a boardrole
    """
    bd = d.dict(exclude_unset=True)
    ubd = await DbBoardRole.update(id, bd)
    return encode_boardrole(ubd)

async def backupBoardRoles() -> List[BoardRoleOptional]:
    """
    dumps all BoardRoles records with full details
    """
    docs =  await DbBoardRole.find_multiple({
        '_fieldlist': {}
    })
    return [encode_boardrole(d, BoardRoleOptional) for d in docs]

async def restoreBoardRoles(docs: List[dict]) -> None:
    """
    dumps all BoardRoles records with full details
    """
    await DbBoardRole.restore(docs)    