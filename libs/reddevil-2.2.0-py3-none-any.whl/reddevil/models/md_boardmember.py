# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# all models in the service level exposed to the API
# we are using pydantic as tool

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional, Type
from pydantic import BaseModel

class BoardMemberPermissions(BaseModel):
    showemail: bool
    showmobile: bool
    showpicture: bool

class BoardMember(BaseModel):
    """
    An boardmember as written in the database
    """
    adinterim: List[bool]
    boardroles: List[str]
    email: str
    enabled: bool
    first_name: str
    last_name: str
    mobile: str
    organisation: str
    permissions: BoardMemberPermissions
    picture: bytes
    picturename: str
    picturemimetype: str
    priority: int
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime     


class BoardMemberOptional(BaseModel):
    """
    An fields optional
    """
    adinterim: Optional[List[bool]] = None
    boardroles: Optional[List[str]] = None
    email: Optional[str] = None
    enabled: Optional[bool] = None
    first_name: Optional[str] = None
    id: Optional[str] = None
    last_name: Optional[str] = None
    mobile: Optional[str] = None
    organisation: Optional[str] = None
    picture: Optional[bytes] = None
    picturename: Optional[str] = None
    picturemimetype: Optional[str] = None
    priority: Optional[int] = None
    _id: Optional[str] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None      

class BoardMemberIn(BaseModel):
    """
    contains the required fields to create a new boardmember
    """
    first_name: str
    last_name: str
    email: str
    mobile: str
    organisation: str

class BoardMemberOut(BaseModel):
    """
    A readonly view used for listing boardmembers
    """
    adinterim: List[bool]
    boardroles: List[str]
    email: str
    first_name: str
    id: str
    last_name: str
    mobile: str
    organisation: str
    permissions: BoardMemberPermissions
    priority: int


class BoardMemberListOut(BaseModel):
    members: List[BoardMemberOut]

class BoardMemberUpdate(BaseModel):
    """
    An update to a boardmember: all fields are optional
    """
    adinterim: Optional[List[bool]] = None
    boardroles: Optional[List[str]] = None
    email: Optional[str] = None
    enabled: Optional[bool] = None
    first_name: Optional[str] = None
    id: Optional[str] = None
    last_name: Optional[str] = None
    orgnanisation: Optional[str] = None
    mobile: Optional[str] = None
    picture: Optional[bytes] = None
    picturename: Optional[str] = None
    picturemimetype: Optional[str] = None
    priority: Optional[int] = None

class BoardMemberDetailedOut(BaseModel):
    """
    An detailed view of a boardmember, including picture 
    """
    adinterim: bool 
    boardroles: List[str]
    email: str
    enabled: bool
    first_name: str
    id: str
    last_name: str
    orgnaisation: str
    mobile: str = ''
    picture: bytes 
    picturemimetype: str 
    priority: int
    showemail: bool 
    showmobile: bool 
