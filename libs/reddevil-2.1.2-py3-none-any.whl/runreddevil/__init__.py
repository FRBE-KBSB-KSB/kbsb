# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os.path
import asyncio 
import logging, logging.config
from motor.motor_asyncio import AsyncIOMotorClient
from fastapi import FastAPI
from fastapi.routing import APIRoute
from reddevil.common.configreader import SettingsProxy
from reddevil.common import register_app



# setup the app
settings = SettingsProxy('runreddevil.settings')
logging.config.dictConfig(settings.LOG_CONFIG)
version = '0.0.1'
title = 'RunReddevil'
description = 'Test runner for Reddevil framework'
log = logging.getLogger('reddevil')
log.info(f'Starting {description} v{version} ...')

def get_db():
    """
    a singleton
    """
    if not hasattr(get_db, 'database'):
        loop = asyncio.get_event_loop()
        client = AsyncIOMotorClient(settings.MONGO_URL, io_loop=loop)
        setattr(get_db,'database', client[settings.MONGO_DB])
    return get_db.database


app = FastAPI(title=title, description=description, version=version)
register_app(settings, app, get_db, '/api')

# import the reddevil api
# and simplify operation IDs so that generated API clients have simpler function
# names.

import reddevil.api.api_page
import reddevil.api.api_account

for route in app.routes:
    if isinstance(route, APIRoute):
        route.operation_id = route.name[4:] 

log.info('app {app}')