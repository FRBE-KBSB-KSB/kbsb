# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import json
import uuid
import asyncio
from jose import jwt, JWTError, ExpiredSignatureError

from passlib.context import CryptContext
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from google.oauth2 import id_token
from google.auth.transport import requests
from datetime import datetime, timedelta
from typing import List, Optional, Union

from reddevil.common import (
    cfg,
    RdInternalServerError, 
    RdBadRequest,
    RdNotAuthorized,
    RdNotFound,
)

from reddevil.models.md_account import (
    AccountConfirm,
    AccountDetailedIn,
    AccountDetailedOut,
    AccountIn,
    AccountListOut,
    AccountLogin,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    AccountOptional,
    LoginType,
)
from reddevil.service.sv_account import (
    createAccount, 
    getAccount, 
    updateAccount,
)
from reddevil.crud.db_account import DbAccount

log = logging.getLogger("reddevil")

bearer_schema = HTTPBearer(auto_error=False)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str):
    """
    return the password hashed
    """
    return pwd_context.hash(password)

def verify_password(plain:str, hash: str):
    """
    verify hash is the plain password hashed
    """
    return pwd_context.verify(plain, hash)

async def get_token(acc: AccountOptional, duration: timedelta, 
    invalidate: bool=True
) -> str:
    """
    gets a new JWT token for a user
    :param acc: an AccountOptional
    :param invalidate: invalidate the existing tokens by changing the salt
    :return: return the newly created token
    """
    id = acc.id
    if invalidate or acc.tokensalt is None:
        tokensalt = str(uuid.uuid1())
        await updateAccount(acc.id, AccountDetailedIn(), { "$set":{
            'tokensalt': tokensalt}})
    else:
        tokensalt = acc.tokensalt
        await asyncio.sleep(0)   # a noop await
    payload = {
        'sub': acc.id,
        'exp': datetime.utcnow() + duration
    }
    return jwt.encode(payload, cfg.TOKEN["secret"] + tokensalt, 
        algorithm=cfg.TOKEN["algorithm"])

async def get_email_token(email: str, duration: timedelta) -> str:
    """
    gets a new JWT token for a confirmation email
    :param email: an email addres
    :return: return the newly created token
    """
    payload = {
        'sub': email,
        'exp': datetime.utcnow() + duration
    }
    return jwt.encode(payload, cfg.TOKEN["emailsecret"], 
        algorithm=cfg.TOKEN["algorithm"])

async def validate_token(auth: HTTPAuthorizationCredentials) -> AccountOptional:
    """
    checks a JWT token for validity
    return an AccountRights if the token is correctly validated
    if token is not valid the function :
        - either returns None  
        - either raise RdNotAuthorized if raising is set
    """
    token = auth.credentials if auth else None
    if not token:
        raise RdNotAuthorized(description='MissingToken')
    if cfg.TOKEN.get('nocheck'):
        return None
    try:
        payload = jwt.decode(token, key="", options={'verify_signature': False})
    except:
        log.exception('invalid token without verification')
        raise RdNotAuthorized(description='BadToken')
    try:
        username = payload.get('sub')
        acc = await getAccount(username, {
            '_class': AccountOptional,
            '_fieldlist': ['tokensalt', 'scopes', 'groups', 'superuser'],
        })
    except RdNotFound:
        log.debug(f'account {username} not found')
        raise RdNotAuthorized(description='BadToken')
    try:
        jwt.decode(token, cfg.TOKEN["secret"] + acc.tokensalt)
    except JWTError:
        log.debug('JWT Error')
        raise RdNotAuthorized(description='BadToken')
    except ExpiredSignatureError:
        log.debug('JWT Error')
        raise RdNotAuthorized(description='TokenExpired')
    try:
        return acc
    except Exception as e:
        log.exception('cannot encode account rights')
        raise RdInternalServerError(description='CannotEncodeAccountRights')

async def validate_email_token(token: str, email: str) -> bool:
    """
    checks a JWT emailtoken for validity
    return True if token is a valid token for the username 
    """
    try:
        payload = jwt.decode(token, cfg.TOKEN["emailsecret"])
    except JWTError:
        log.debug('JWT Error')
        return False
    except ExpiredSignatureError:
        log.debug('JWT Error')
        return False
    return payload.get('sub', None) == email

async def login(li: AccountLogin) -> str:
    """
    login and returns a newly create JWT token
    """
    if li.logintype == LoginType.google:
        assert li.token is not None
        token = li.token
        try:
            idinfo = id_token.verify_oauth2_token(token, requests.Request(), 
                cfg.GOOGLE_CLIENT_ID)
            if idinfo['iss'] not in ['accounts.google.com', 'https://accounts.google.com']:
                raise RdNotAuthorized(description='WrongAuthIssuer')
            if cfg.GOOGLE_LOGIN_DOMAINS and idinfo['hd'] not in cfg.GOOGLE_LOGIN_DOMAINS:
                raise RdNotAuthorized(description='WrongGoogleDomain')
            try: 
                acc = await getAccount(idinfo['sub'],{
                    '_class': AccountOptional,
                    '_fieldlist': ['id', 'tokensalt'],
                })
            except RdNotFound:
                log.info(f'account not found creating ...')
                accdict = {
                    'domain': idinfo['hd'],
                    'email': idinfo['email'],
                    'email_verified': idinfo['email_verified'],
                    'enabled': True,
                    'first_name': idinfo['given_name'],
                    'id': idinfo['sub'],
                    'last_name': idinfo['family_name'],
                    'locale': idinfo['locale'],
                    'logintype': LoginType.google,
                }
                id = await DbAccount.add(accdict)
                acc = await getAccount(idinfo['sub'],{
                    '_class': AccountOptional,
                    '_fieldlist': ['id', 'tokensalt'],
                })
        except ValueError:
            raise RdNotAuthorized(description='InvalidGoogleToken')
    elif li.logintype == LoginType.email:
        assert li.password is not None
        if li.username is None:
            raise RdBadRequest(description="MissingUsername")
        try:
            acc = await getAccount(li.username, {
                '_class': AccountOptional,
                '_fieldlist': ["hashed_password", "tokensalt"]
            })
        except RdNotFound:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
        verified = False
        try:
            verified = verify_password(li.password, acc.hashed_password)
        except Exception as e:
            print('verify exception')
            log.exception('cannot process verify password')
        if not verified:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
    else:
        raise RdBadRequest(description='InvalidLoginType')
    token = await get_token(acc, timedelta(minutes=cfg.TOKEN['timeout']))
    return token    

async def registerAccount(ai: AccountIn, domain: str = None) -> None:
    """
    register a new account
    """
    try:
        existing  = await getAccount(ai.id)
    except RdNotFound:
        existing = None
    if existing:
        raise RdBadRequest(description='UsernameAlreadyExisting')
    domain = domain or cfg.ACCOUNT_DOMAIN
    if not ai.email:
        raise RdBadRequest(description='EmailMissing')
    if not ai.first_name:
        raise RdBadRequest(description='FirstNameMissing')
    if not ai.last_name:
        raise RdBadRequest(description='LastNameMissing')
    if not ai.password:
        raise RdBadRequest(description='PasswordMissing')
    if not ai.locale:
        ai.locale = ''
    hashed_password = hash_password(ai.password)
    await createAccount(ai) 
    await updateAccount(ai.id, AccountDetailedIn(), { '$set':{
        'hashed_password': hashed_password,
        'domain': domain,
    }})
    emailtoken = await get_email_token(ai.email, 
        timedelta(hours=cfg.TOKEN['emailtimeouthours']) )
    log.info(f'emailtoken for registering {ai.id}: {emailtoken}')
    # TODO send email

async def confirmAccount(ac: AccountConfirm) -> None:
    """
    confirm the email verification
    """
    v = await validate_email_token(ac.token, ac.email)
    if v:
        await updateAccount(ac.username, AccountDetailedIn(),
            {'$set': {'email_verified': True}})
    else:
        raise RdBadRequest(description='InvalidEmailVerification')

async def updatePassword(pwu: AccountPasswordUpdate, checkold: bool=True) -> None:
    """
    update a user's password
    """
    try:
        acc = await getAccount(pwu.username, {
            '_class': AccountOptional,
            '_fieldlist': ["hashed_password", "tokensalt"]
        })
    except RdNotFound:
        raise RdNotAuthorized(description="WrongUserPasswordCombination")
    if checkold and not verify_password(pwu.oldpassword, acc.hashed_password):
        raise RdNotAuthorized(description="WrongUserPasswordCombination")
    hashed_password = hash_password(pwu.newpassword)
    await updateAccount(pwu.username, AccountDetailedIn(), { "$set": {
        'hashed_password': hashed_password}})
        
async def resetPassword(pwr: AccountPasswordReset) -> None:
    """
    request a reset password for the user
    """
    acc = await getAccount(pwr.username)
    emailtoken = await get_email_token(acc.email, 
        timedelta(hours=cfg.TOKEN['emailtimeouthours']) )
    log.info(f'emailtoken for resetting {acc.id} {acc.email}: {emailtoken}')
    # TODO sent email
       
async def confirmPassword(pwc: AccountPasswordConfirm) -> str:
    """
    confirms a newly reset password, returning a new authorisation token
    """
    v = await validate_email_token(pwc.token, pwc.email)
    if v:
        hashed_password = hash_password(pwc.newpassword)
        await updateAccount(pwc.username, AccountDetailedIn(), { "$set":
            {'hashed_password': hashed_password}})
    else:
        raise RdBadRequest(description='InvalidEmailVerification')
    acc = await getAccount(pwc.username, {
        '_class': AccountOptional,
        '_fieldlist': ["hashed_password", "tokensalt"]
    })
    token = await get_token(acc, timedelta(minutes=cfg.TOKEN['timeout']))
    return token 


