#    Copyright 2019 Chessdevil Consulting

import logging
import time
import smtplib
import base64
from pathlib import Path
from fastapi import HTTPException
from google.oauth2 import service_account
from googleapiclient.discovery import build
from email.mime.base import MIMEBase
from reddevil.core import get_settings, get_secret
from reddevil.core.errors import RdMailError

log = logging.getLogger("bycco")
settings = get_settings()
cwd = Path(".")


class BaseEmailBackend:
    def send_message(self, message: MIMEBase):
        raise HTTPException(503, detail="EmailBackendNotImplemented")


class SmtpSslBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase):
        with smtplib.SMTP_SSL(settings.EMAIL["host"], settings.EMAIL["port"]) as s:
            if settings.EMAIL.get("user"):
                s.login(settings.EMAIL["user"], settings.EMAIL["password"])
            s.send_message(msg)


class SmtpBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase):
        with smtplib.SMTP(settings.EMAIL["host"], settings.EMAIL["port"]) as s:
            if settings.EMAIL.get("user"):
                s.login(settings.EMAIL["user"], settings.EMAIL["password"])
            s.send_message(msg)


class GmailBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase):
        service = get_gmail_service()
        rmsg = {"raw": base64.urlsafe_b64encode(msg.as_bytes()).decode("ascii")}
        retries = 0
        sent = False
        while not sent and retries < 3:
            try:
                service.users().messages().send(userId="me", body=rmsg).execute()
                sent = True
            except Exception as e:
                if retries == 3:
                    raise RdMailError("GmailSendEmailFailed") from e
                retries += 1
                log.error(f"sending Gmail message failed, retrying {retries}")
                time.sleep(5 * retries)


def get_gmail_service():
    if not hasattr(get_gmail_service, "service"):
        secret = get_secret("gmail")
        try:
            cr = service_account.Credentials.from_service_account_info(
                secret, scopes=["https://www.googleapis.com/auth/gmail.send"]
            )
            delegated_credentials = cr.with_subject(settings.EMAIL["account"])
            service = build("gmail", "v1", credentials=delegated_credentials)
            get_gmail_service.service = service
        except Exception:
            log.exception("Cannot setup Gmail API")
            raise HTTPException(503, detail="GmailAPINotAvailable")
    return get_gmail_service.service


backends = {
    "SMTP": SmtpBackend,
    "SMTP_SSL": SmtpSslBackend,
    "GMAIL": GmailBackend,
}
