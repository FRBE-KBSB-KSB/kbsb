# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# we don't use pydantic here because there is no API ued for these models

from dataclasses import dataclass, field
from typing import List, Optional
from io import BytesIO


@dataclass
class MailAttachment:
    filename: str  # filename of attachement
    mimetype: str  # mimetype of attachment
    content_base64: bytes  # base64 encoded content


@dataclass
class MailParams:
    locale: str
    receiver: str
    sender: str
    subject: str
    template: str
    attachments: List[MailAttachment] = field(default_factory=list)
    bcc: str = ""
    cc: str = ""
