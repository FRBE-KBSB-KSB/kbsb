# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import bs4
import base64
from fastapi import HTTPException
from markdown2 import Markdown
from jinja2 import PackageLoader, Environment, exceptions
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.message import EmailMessage
from email import encoders
from io import BytesIO
from pathlib import Path
from typing import List, Optional

# from weasyprint import HTML, CSS
from reddevil.core import get_settings
from reddevil.core.errors import RdBadRequest
from reddevil.mail.md_mail import MailParams

from .mailbackend import backends

logger = logging.getLogger("reddevil")
md = Markdown(extras=["tables", "metadata"])


def get_template_env():
    if not hasattr(get_template_env, "env"):
        settings = get_settings()
        get_template_env.env = Environment(
            loader=PackageLoader(settings.TEMPLATES_MODULE), trim_blocks=True
        )
    return get_template_env.env


def getCss():
    settings = get_settings()
    if not hasattr(getCss, "css"):
        with open(Path(settings.TEMPLATES_PATH) / "markdown.css") as f:
            setattr(getCss, "css", f.read())
    return getattr(getCss, "css")


def sendEmail(mp: MailParams, context: dict, name: str = ""):
    """
    dispatcher for emails
    """
    attachments = mp.attachments
    if not attachments:
        sendEmailNoAttachments(mp, context, name)
        return
    if len(attachments) == 1 and attachments[0].mimetype == "application/pdf":
        sendEmailWithPdf(mp, context, name)
        return
    logger.error("emails with more than 1 attachment not yet supported")
    raise HTTPException(503, detail="TooManyAttachments")


def sendEmailNoAttachments(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with no attachment
    """
    settings = get_settings()
    env = get_template_env()
    try:
        tmpl = env.get_template(mp.template.format(locale=context["locale"]))
    except exceptions.TemplateNotFound as e:
        logger.info(f"could not find template in searchpath {env.loader.searchpath}")
        raise e
    markdowntext = tmpl.render(**context)
    htmltext = md.convert(markdowntext)
    try:
        msg = MIMEMultipart("related")
        msg["Subject"] = htmltext.metadata.get("title") or mp.subject
        msg["From"] = mp.sender
        msg["To"] = mp.receiver
        if mp.cc:
            msg["Cc"] = mp.cc
        if mp.bcc:
            msg["Bcc"] = mp.bcc
        msg.preamble = "This is a multi-part message in MIME format."
        msgAlternative = MIMEMultipart("alternative")
        msgText = MIMEText(markdowntext)
        msgAlternative.attach(msgText)
        msgText = MIMEText(htmltext, "html")
        msgAlternative.attach(msgText)
        msg.attach(msgAlternative)
        backend = backends[settings.EMAIL["backend"]]()
        backend.send_message(msg)
        logger.info(f"email {name} sent to {mp.receiver}")
    except Exception:
        logger.exception("failed")


def sendEmailMessage(mp: MailParams):
    """
    sends an HTML email with plain text alternative and optional attachments
    using the EmailMessage class
    """
    settings = get_settings()
    htmltext = mp.template
    plaintext = bs4.BeautifulSoup(htmltext, features="html.parser").get_text()
    logger.debug(f"sendingEmailMessage with {len(mp.attachments)} attachments")
    try:
        msg = EmailMessage()
        msg["Subject"] = mp.subject
        msg["From"] = mp.sender
        msg["To"] = mp.receiver
        if mp.cc:
            msg["Cc"] = mp.cc
        if mp.bcc:
            msg["Bcc"] = mp.bcc
        msg.set_content(plaintext)
        msg.add_alternative(htmltext, subtype="html")
        # attachments
        for att in mp.attachments:
            logger.debug(f"adding attachment {att.filename}")
            try:
                maintype, subtype = att.mimetype.split("/")
            except ValueError:
                raise RdBadRequest(f"attachment {att.filename} has invalid mimetype")
            content = base64.b64decode(att.content_base64)
            msg.add_attachment(
                content,
                maintype=maintype,
                subtype=subtype,
                filename=att.filename,
            )
        backend = backends[settings.EMAIL["backend"]]()
        backend.send_message(msg)
        title = mp.subject if len(mp.subject) < 20 else mp.subject[0:17] + "..."
        logger.info(f"sendEmailMessage {title} sent to {mp.receiver}")
    except Exception:
        logger.exception("failed")


def sendEmailWithPdf(mp: MailParams, context: dict, name: str = ""):
    """
    sends an email with a pdf attachment
    """
    settings = get_settings()
    env = get_template_env()
    tmpl = env.get_template(mp.template.format(locale=context["locale"]))
    markdowntext = tmpl.render(**context)
    htmltext = md.convert(markdowntext)
    try:
        # receiver = rsv.email
        msg = MIMEMultipart("related")
        msg["Subject"] = htmltext.metadata.get("title") or mp.subject
        msg["From"] = mp.sender
        msg["To"] = mp.receiver
        if mp.cc:
            msg["Cc"] = mp.cc
        if mp.bcc:
            msg["Bcc"] = mp.bcc
        msg.preamble = "This is a multi-part message in MIME format."
        msgAlternative = MIMEMultipart("alternative")
        msgText = MIMEText(markdowntext)
        msgAlternative.attach(msgText)
        msgText = MIMEText(htmltext, "html")
        msgAlternative.attach(msgText)
        msg.attach(msgAlternative)
        # pdf
        att = mp.attachments[0]
        pdfio = BytesIO()
        msgAtt = MIMEBase("application", "octet-stream")
        msgAtt.set_payload(pdfio.getvalue())
        encoders.encode_base64(msgAtt)
        msgAtt.add_header(
            "Content-Disposition",
            f"attachment; filename={att.filename}",
        )
        msg.attach(msgAtt)
        backend = backends[settings.EMAIL["backend"]]()
        backend.send_message(msg)
        logger.info(f"payrequest email sent to {mp.receiver}")
    except Exception:
        logger.exception("failed")
