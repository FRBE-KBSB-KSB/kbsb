# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, MagicMock, patch, PropertyMock, AsyncMock
from datetime import datetime, date, timedelta

from reddevil.service.security import (
    confirmAccount,
    confirmPassword,
    get_token,
    hash_password,
    login,
    registerAccount,
    resetPassword,
    updateAccount,
    updatePassword,
    validate_token,
    verify_password,
)

from reddevil.models.md_account import (
    AccountConfirm,
    AccountDetailedIn,
    AccountDetailedOut,
    AccountIn,
    AccountListOut,
    AccountLogin,
    AccountOut,
    AccountOptional,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    LoginType,
)
from reddevil.common import RdNotFound

@pytest.fixture
def acclogin1():
    return AccountOptional(
        id='234', 
        tokensalt= 'salt',
        hashed_password='droenke',        
    )

@pytest.fixture
def acclogin2():
    return AccountOptional(
        id='234', 
        email= 'email',
    )


@pytest.fixture
def accin1():
    return AccountIn(
        email='a@b.cd',
        first_name='Julius',
        last_name='Caesar',
        locale='lt',
        logintype=LoginType.email,
        id='julius.caeser',
        password='dronken',
    )

@pytest.fixture
def accconfirm1():
    return AccountConfirm(
        token='1234',
        email='email',
        username='ikke',
    )

@pytest.fixture
def accpwupdate1():
    return AccountPasswordUpdate(
        oldpassword='nuchter',
        newpassword='dronken',
        username='ikke',
    )

@pytest.fixture
def accpwreset1():
    return AccountPasswordReset(
        username='ikke',
    )

@pytest.fixture
def accpwconfirm1():
    return AccountPasswordConfirm(
        username='junder',
        newpassword='dronken',
        email='email2',
        token='2345',
    )

def test_password():
    pw = '123deféé'
    hashed = hash_password(pw)
    assert verify_password(pw, hashed)

@patch('reddevil.service.security.cfg')
@patch('reddevil.service.security.getAccount')
@patch('reddevil.service.security.verify_password')
@patch('reddevil.service.security.get_token')
@pytest.mark.asyncio
async def test_login_email(get_token: Mock, verify_password: Mock, 
    getAccount: Mock, cfg: MagicMock, acclogin1
):
    getAccount.return_value = acclogin1
    verify_password.return_value = True
    get_token.return_value = 'token'
    TOKEN = PropertyMock()
    TOKEN.return_value = {'timeout': 50}
    type(cfg).TOKEN = TOKEN
    await login(AccountLogin(
        logintype=LoginType.email,
        password= 'dronken',
        username='ikke'
    ))
    getAccount.assert_awaited()
    assert getAccount.await_args.args[0] == 'ikke'
    verify_password.assert_called()
    assert verify_password.call_args.args[0] == 'dronken'
    assert verify_password.call_args.args[1] == 'droenke'
    get_token.assert_awaited()
    assert get_token.await_args.args[0] == acclogin1
    
@patch('reddevil.service.security.cfg')
@patch('reddevil.service.security.getAccount')
@patch('reddevil.service.security.hash_password')
@patch('reddevil.service.security.createAccount')
@patch('reddevil.service.security.updateAccount')
@patch('reddevil.service.security.get_email_token')
@pytest.mark.asyncio
async def test_registerAccount(get_email_token: Mock, updateAccount: Mock, 
    createAccount: Mock, hash_password:Mock, getAccount: Mock,
    cfg: MagicMock, accin1
):
    getAccount.side_effect = RdNotFound()
    hash_password.return_value = 'droenke'
    createAccount.return_value = 'ikke'
    get_token.return_value = 'token'
    TOKEN = PropertyMock()
    TOKEN.return_value = {'emailtimeouthours': 2}
    type(cfg).TOKEN = TOKEN
    ACCOUNT_DOMAIN = PropertyMock()
    ACCOUNT_DOMAIN.return_value = 'testdomain'
    type(cfg).ACCOUNT = ACCOUNT_DOMAIN
    await registerAccount(accin1)
    assert createAccount.call_args.args[0] == accin1
    updateAccount.assert_awaited()
    updateAccount.call_args.args[0] == 'julius.caeser'
    updateAccount.call_args.args[1] == AccountDetailedIn()
    updateAccount.call_args.args[2] == {
        'hashed_password': 'droenke',
        'domain': 'testdomain',
    }
    get_email_token.assert_awaited()
    assert get_email_token.await_args.args[0] == 'a@b.cd'
    assert get_email_token.await_args.args[1].seconds == 7200
    
@patch('reddevil.service.security.validate_email_token')
@patch('reddevil.service.security.updateAccount')
@pytest.mark.asyncio
async def test_confirmAccount(updateAccount: Mock, validate_email_token: Mock,
    accconfirm1
):
    validate_email_token.return_value = True
    await confirmAccount(accconfirm1)
    assert validate_email_token.await_args.args[1] == 'email'
    updateAccount.assert_awaited()
    updateAccount.call_args.args[0] == 'ikke'
    updateAccount.call_args.args[1] == AccountDetailedIn()
    updateAccount.call_args.args[2] == {
        'email_verified': 'True',
    }
    

@patch('reddevil.service.security.getAccount')
@patch('reddevil.service.security.verify_password')
@patch('reddevil.service.security.hash_password')
@patch('reddevil.service.security.updateAccount')
@pytest.mark.asyncio
async def test_updatePassword(updateAccount: Mock, hash_password: Mock,
    verify_password: Mock, getAccount: Mock, acclogin1, accpwupdate1
):
    getAccount.return_value = acclogin1
    verify_password.return_value = True
    hash_password.return_value = 'droenke'
    await updatePassword(accpwupdate1)
    getAccount.assert_awaited()
    assert getAccount.await_args.args[0] == 'ikke'
    verify_password.assert_called()
    assert verify_password.call_args.args[0] == 'nuchter'
    assert verify_password.call_args.args[1] == 'droenke'
    hash_password.assert_called
    assert hash_password.call_args.args[0] == 'dronken'
    updateAccount.assert_awaited()
    assert updateAccount.await_args.args[0] == 'ikke'
    assert updateAccount.await_args.args[1] == AccountDetailedIn()
    assert updateAccount.await_args.args[2] == {
        'hashed_password': 'droenke',
    }

@patch('reddevil.service.security.getAccount')
@patch('reddevil.service.security.get_email_token')
@patch('reddevil.service.security.cfg')
@pytest.mark.asyncio
async def test_resetPassword(cfg: PropertyMock, 
    get_email_token: AsyncMock, getAccount: AsyncMock, accpwreset1, 
    acclogin2
):
    getAccount.return_value = acclogin2
    get_email_token.return_value = '1234'
    TOKEN = PropertyMock()
    TOKEN.return_value = {'emailtimeouthours': 2}
    type(cfg).TOKEN = TOKEN
    await resetPassword(accpwreset1)
    getAccount.assert_awaited()
    assert getAccount.await_args.args[0] == 'ikke'
    get_email_token.assert_awaited()
    assert get_email_token.await_args.args[0] == 'email'

@patch('reddevil.service.security.validate_email_token')
@patch('reddevil.service.security.hash_password')
@patch('reddevil.service.security.updateAccount')
@patch('reddevil.service.security.getAccount')
@patch('reddevil.service.security.get_token')
@patch('reddevil.service.security.cfg')
@pytest.mark.asyncio
async def test_confirmPassword(cfg: PropertyMock, get_token: AsyncMock,
    getAccount: AsyncMock, updateAccount: AsyncMock, 
    hash_password: Mock, validate_email_token: AsyncMock, 
    accpwconfirm1, acclogin1
):
    validate_email_token.return_value = True
    hash_password.return_value = 'droenke'
    getAccount.return_value = acclogin1 
    get_token.return_value = '1234'
    TOKEN = PropertyMock()
    TOKEN.return_value = {'timeout': 2}
    type(cfg).TOKEN = TOKEN
    await confirmPassword(accpwconfirm1)
    validate_email_token.assert_awaited()
    hash_password.assert_called()
    assert hash_password.call_args.args[0] == 'dronken'
    updateAccount.assert_awaited()
    assert updateAccount.await_args.args[0] == 'junder'
    assert updateAccount.await_args.args[2] == {
        'hashed_password': 'droenke'
    }
    getAccount.assert_awaited()
    assert getAccount.await_args.args[0] == 'junder'
    get_token.assert_awaited()
    assert get_token.await_args.args[0] == acclogin1
