# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import json
import uuid
import asyncio
from jose import jwt, JWTError, ExpiredSignatureError

from passlib.context import CryptContext
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from google.oauth2 import id_token
from google.auth.transport import requests
from datetime import datetime, timedelta
from typing import List, Optional, Union

from reddevil.common import (
    cfg,
    RdInternalServerError, 
    RdBadRequest,
    RdNotAuthorized,
    RdNotFound,
)

from reddevil.models.md_account import (
    AccountConfirm,
    AccountDetailedIn,
    AccountDetailedOut,
    AccountIn,
    AccountListOut,
    AccountLogin,
    AccountOut,
    AccountPasswordConfirm,
    AccountPasswordReset,
    AccountPasswordUpdate,
    LoginType,
)

from reddevil.crud.db_account import DbAccount

log = logging.getLogger('reddevil')

def encode_account(e: dict, _class=AccountDetailedOut):
    try:
        eo = _class(**e)
    except Exception:
        log.exception('cannot encode Account')
        raise RdInternalServerError(description='CannotEncodeAccount')
    return eo

async def createAccount(d: AccountIn) -> str:
    """
    create a new Account 
    """
    assert d.password
    from .security import hash_password
    dd = d.dict()
    dd.pop('password', None)
    dd['id'] = d.id
    dd['email_Verified'] = False
    dd['groups'] = ''
    dd['logintype'] = d.logintype
    dd['enabled'] = d.enabled
    dd['tokensalt'] = str(uuid.uuid1())
    dd['hashed_password'] = hash_password(d.password)
    return await DbAccount.add(dd)

async def deleteAccount(id: str) -> None:
    """
    delete the zccount 
    """
    await DbAccount.delete(id)

async def getAccount(id: str, options: dict= {}) -> AccountDetailedOut:
    """
    get the account 
    """
    _class = options.pop('_class', AccountDetailedOut)
    filter = dict(id=id, **options)
    adict = await DbAccount.find_single(filter)
    return encode_account(adict, _class)

async def getAccounts(options: dict = {}) -> AccountListOut:
    """
    get all account
    """
    _class = options.pop('_class', AccountOut)
    accs = await DbAccount.find_multiple(options)
    accounts = [encode_account(a, _class) for a in accs]
    return AccountListOut(accounts=accounts)  

async def updateAccount(id: str, d: AccountDetailedIn, options: dict = {}
) -> AccountDetailedOut:
    """
    update a Account
    """
    # import dates as isoformat string
    dd = d.dict(exclude_unset=True)
    udd = await DbAccount.update(id, dd, options)
    return encode_account(udd)

