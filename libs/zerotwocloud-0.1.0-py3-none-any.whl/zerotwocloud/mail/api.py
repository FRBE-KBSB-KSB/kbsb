# The HTTP face of the mail package, as a router for a host FastAPI app:
#
#     from zerotwocloud.mail import api as zc_mail_api
#     app.include_router(zc_mail_api.router)
#
# It speaks the same contract as the website's
# POST /api/v1/tournament_registrations/send-confirmation (body, header,
# status codes, error details, {"success": true}), so the existing callers
# switch by changing a URL and a secret. It lives at /api/v1/mail/send because
# the host already owns the website path.
#
# Importing this module and including the router does no I/O and cannot
# raise for configuration reasons. Configuration is read per request, and a
# missing secret, a sender that is not the delegated user or a delegation
# that fails is reported on that request (500 or 502), so a mistake here can
# never stop the host website from booting.

import json
import logging
import re
import sys
import threading
import time
from typing import Callable, List

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .callers import (
    CallerRegistry,
    CallersConfigError,
    CallersUnavailable,
    RateLimiter,
    SecretManagerPayload,
)
from .config import get_settings
from .errors import ZcBadRequest, ZcMailError
from .mail import sendEmailMessage
from .mailbackend import backends
from .md_mail import MailParams

router = APIRouter(prefix="/api/v1/mail", tags=["mail"])

# Detail texts copied from the website endpoint, because callers show them to
# people and may match on them.
DETAIL_UNAUTHORIZED = "Unauthorized"
DETAIL_NO_RECIPIENTS = "At least one recipient (to, cc, or bcc) must not be empty"
DETAIL_SEND_FAILED = "Failed to send confirmation email"
DETAIL_SECRET_UNAVAILABLE = "Could not retrieve mail bridge secret"
# New with this router.
DETAIL_MISCONFIGURED = "Mail service is misconfigured"
DETAIL_RATE_LIMITED = "Rate limit exceeded"

_ADDRESS_RE = re.compile(r"[^\s<>\"'(),;:]+@[^\s<>\"'(),;:]+")


class SendConfirmationPayload(BaseModel):
    # Field for field the website's model. There is deliberately no sender
    # and no reply_to: pydantic drops unknown fields, so a body cannot choose
    # who the mail claims to be from or where replies go.
    subject: str
    html: str
    to: List[str] = []
    cc: List[str] = []
    bcc: List[str] = []


class Misconfigured(Exception):
    pass


class MailState:
    """
    Everything the endpoint keeps between requests: the cached caller list
    and the rate limit windows. Built empty; nothing is read until a request
    needs it.
    """

    def __init__(
        self,
        load_callers: Callable[[], bytes] | None = None,
        clock: Callable[[], float] = time.monotonic,
    ):
        self._load_override = load_callers
        self._clock = clock
        self._lock = threading.Lock()
        self._registry: CallerRegistry | None = None
        self._registry_key: tuple | None = None
        self.limiter = RateLimiter(clock=clock)

    def registry(self) -> CallerRegistry:
        settings = get_settings()
        email_settings = settings.EMAIL  # type: ignore
        backend = email_settings.get("backend", "")
        account = email_settings.get("account", "")
        secret = getattr(settings, "CALLERS_SECRET", "")

        problems = []
        if backend not in backends:
            problems.append(f"backend {backend!r} is not one of {sorted(backends)}")
        if backend == "GMAIL":
            if not email_settings.get("service_account"):
                problems.append("no service account configured")
            if not account:
                problems.append("no delegated user configured")
        if self._load_override is None and not secret:
            problems.append("no callers secret configured")
        if problems:
            raise Misconfigured("; ".join(problems))

        key = (secret, account)
        with self._lock:
            if self._registry is None or self._registry_key != key:
                if self._load_override is not None:
                    load = self._load_override
                else:
                    try:
                        load = SecretManagerPayload(secret)
                    except ValueError as e:
                        raise Misconfigured(str(e)) from e
                self._registry = CallerRegistry(load, account, clock=self._clock)
                self._registry_key = key
            return self._registry


_state = MailState()


def get_mail_state() -> MailState:
    """Dependency, so a test (or a host) can substitute its own MailState."""
    return _state


class _StdoutJsonHandler(logging.Handler):
    # Looks sys.stdout up at emit time so test capture sees the lines. On App
    # Engine a single JSON object per stdout line becomes a structured entry.
    def emit(self, record):
        try:
            sys.stdout.write(record.getMessage() + "\n")
            sys.stdout.flush()
        except Exception:
            self.handleError(record)


send_log = logging.getLogger("zerotwocloud.mail.send")
if not any(isinstance(h, _StdoutJsonHandler) for h in send_log.handlers):
    send_log.addHandler(_StdoutJsonHandler())
send_log.setLevel(logging.INFO)
# Kept out of the host's own log configuration so the line stays one JSON
# object and is not also reformatted and repeated by a root handler.
send_log.propagate = False


def _redact(text: str) -> str:
    return _ADDRESS_RE.sub("<address>", text)


def _clean(recipients: List[str]) -> List[str]:
    return [r.strip() for r in recipients if r.strip()]


# A plain def, not async: sending blocks on HTTP to Google, and FastAPI runs
# plain handlers in its thread pool instead of stalling the host's event loop.
# Named api_* because the host derives operation ids with route.name[4:].
@router.post("/send")
def api_send_mail(
    request: Request,
    payload: SendConfirmationPayload,
    state: MailState = Depends(get_mail_state),
):
    started = time.monotonic()
    entry = {
        "severity": "INFO",
        "event": "send_attempt",
        "caller": None,
        "sender": None,
        "to_count": len(payload.to),
        "cc_count": len(payload.cc),
        "bcc_count": len(payload.bcc),
        "subject": None,
        "message_id": None,
        "outcome": None,
    }

    def finish(outcome: str, status: int, error: str | None = None):
        entry["outcome"] = outcome
        entry["status"] = status
        entry["latency_ms"] = round((time.monotonic() - started) * 1000, 1)
        if error:
            entry["error"] = _redact(error)
        if status >= 500:
            entry["severity"] = "ERROR"
        elif status >= 400:
            entry["severity"] = "WARNING"
        send_log.info(json.dumps(entry, ensure_ascii=False))

    presented = request.headers.get("x-mail-bridge-secret", "")
    try:
        caller = state.registry().authenticate(presented)
    except Misconfigured as e:
        finish("misconfigured", 500, str(e))
        raise HTTPException(status_code=500, detail=DETAIL_MISCONFIGURED)
    except CallersConfigError as e:
        finish("misconfigured", 500, str(e))
        raise HTTPException(status_code=500, detail=DETAIL_MISCONFIGURED)
    except CallersUnavailable as e:
        finish("secret_unavailable", 500, str(e))
        raise HTTPException(status_code=500, detail=DETAIL_SECRET_UNAVAILABLE)
    if caller is None:
        finish("unauthorized", 401)
        raise HTTPException(status_code=401, detail=DETAIL_UNAUTHORIZED)

    entry["caller"] = caller.name
    entry["sender"] = caller.sender
    # Subjects are written by callers and could quote an address; the log
    # promise is no addresses at all, so they are masked here too.
    entry["subject"] = _redact(payload.subject)

    to, cc, bcc = _clean(payload.to), _clean(payload.cc), _clean(payload.bcc)
    # The website checks the raw lists and would pass [" "] on to Gmail;
    # checking after the blanks are dropped refuses that too, with the same
    # answer.
    if not (to or cc or bcc):
        finish("no_recipients", 400)
        raise HTTPException(status_code=400, detail=DETAIL_NO_RECIPIENTS)

    if not state.limiter.allow(caller.name, caller.per_hour):
        finish("rate_limited", 429)
        raise HTTPException(status_code=429, detail=DETAIL_RATE_LIMITED)

    mail_params = MailParams(
        locale="nl",
        # Exactly the website's rule: the visible To is the joined `to` list,
        # and when that is empty it stays empty (a bare To header) with the
        # real recipients only in Cc/Bcc. See README, "Visible To".
        receiver=", ".join(to),
        sender=caller.sender,
        subject=payload.subject,
        template=payload.html,
        cc=", ".join(cc),
        bcc=", ".join(bcc),
        reply_to=caller.reply_to,
    )

    try:
        message_id = sendEmailMessage(mail_params)
    except ZcBadRequest as e:
        finish("bad_request", 400, e.description)
        raise HTTPException(status_code=400, detail=e.description)
    except ZcMailError as e:
        if e.status_code == 500:
            # Our own configuration (backend, accounts, sender), not Gmail.
            finish("misconfigured", 500, e.description)
            raise HTTPException(status_code=500, detail=DETAIL_MISCONFIGURED)
        finish("failed", 502, e.description)
        raise HTTPException(status_code=502, detail=DETAIL_SEND_FAILED)
    except Exception as e:
        finish("failed", 502, type(e).__name__)
        raise HTTPException(status_code=502, detail=DETAIL_SEND_FAILED)

    entry["message_id"] = message_id
    finish("sent", 200)
    return {"success": True, "id": message_id}
