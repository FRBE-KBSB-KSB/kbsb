import logging

from fastapi import HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List
from reddevil.common import app, url, RdException
from reddevil.service.security import bearer_schema, validate_token 
from reddevil.service.sv_boardrole import (
    createBoardRole,
    deleteBoardRole,
    getBoardRole,
    getBoardRoles,
    updateBoardRole,
)
from reddevil.models.md_boardrole import (
    BoardRoleIn,
    BoardRoleListOut,
    BoardRoleOut,
    BoardRoleUpdate,
)

log = logging.getLogger('reddevil')

assert app is not None


@app.get(url + '/boardroles', response_model=BoardRoleListOut)
async def api_getBoardRoles(reports: int=0, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getBoardRoles()
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_boardroles')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.post(url + '/boardroles', response_model=str)
async def aoi_createBoardRole(p: BoardRoleIn, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await createBoardRole(p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call create_boardrole')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/boardrole/{id}', response_model=BoardRoleOut)
async def api_getBoardRole(id: str, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getBoardRole(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_boardrole')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.delete(url + '/boardrole/{id}')
async def api_deleteBoardRole(id: str, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await deleteBoardRole(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call delete_boardrole')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.put(url + '/boardrole/{id}')
async def api_updateBoardRole(id: str, p: BoardRoleUpdate, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await updateBoardRole(id, p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call update_boardrole')
        raise HTTPException(status_code=500, detail="Internal Server Error")
