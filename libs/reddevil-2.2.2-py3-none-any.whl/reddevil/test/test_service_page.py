# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os, os.path, json
import pytest
from unittest.mock import Mock, patch
from datetime import datetime, date, timedelta

from reddevil.service.sv_page import (
    createPage,
    deletePage,
    getPage,
    getPageBySlug,
    getPages,
    isactive,
    updatePage,
)

from reddevil.models.md_page import (
    PageDetailedOut,
    PageIn,
    PageListOut,
    PageUpdate,
)


@pytest.fixture
def pagedetailed1():
    return {
        'body': {'default': {'value': 'body1'}}, 
        '_creationtime': datetime(2020,1,1),
        'component': 'CmsSimplePage',    
        'doctype': 'page', 
        'enabled': True, 
        'expirationdate': '2020-05-15',
        'id': '234', 
        'intro': {'default': {'value': 'intro1'}}, 
        'languages': ['nl'],
        'name': 'page1',  
        '_modificationtime': datetime(2020,4,15), 
        'owner': 'me',
        'publicationdate': '2020-04-21', 
        'slug': 'slug1', 
        'title': {'default': {'value': 'page1'}}, 
        '_version': 2,        
    }


@pytest.fixture
def pages1():
    return [{
        'body': {'default': {'value': 'body1'}}, 
        '_creationtime': datetime(2020,1,1),
        'doctype': 'page', 
        'enabled': True, 
        'expirationdate': '2020-05-15',
        'id': '234', 
        'intro': {'default': {'value': 'intro1'}}, 
        'name': 'page1',  
        '_modificationtime': datetime(2020,4,15), 
        'publicationdate': '2020-04-21', 
        'slug': 'slug1', 
        'title': {'default': {'value': 'page1'}}, 
        '_version': 2,        
    }, {
        'body': {'default': {'value': 'body2'}}, 
        '_creationtime': datetime(2020,2,1),
        'doctype': 'page', 
        'enabled': True, 
        'expirationdate': '2020-06-15',
        'id': '235', 
        'intro': {'default': {'value': 'intro2'}}, 
        'name': 'page1',  
        '_modificationtime': datetime(2020,5,15), 
        'publicationdate': '2020-04-22', 
        'slug': 'slug2', 
        'title': {'default': {'value': 'page2'}}, 
        '_version': 2,        
    }]

@patch('reddevil.service.sv_page.DbPage.add')
@pytest.mark.asyncio
async def test_create_page(padd: Mock):
    d = PageIn(doctype='page', name='page1', locale='nl')
    id = await createPage(d)
    padd.assert_awaited()
    pd = padd.await_args.args[0]
    assert pd['languages'] == ['nl']
    assert 'default' in pd['body']
    assert 'default' in pd['intro']
    assert pd['title']['default']['value'] == 'page1'
    assert isinstance(pd['creationtime'], datetime)


@patch('reddevil.service.sv_page.DbPage.delete')
@pytest.mark.asyncio
async def test_delete_page(pdelete: Mock):
    id = await deletePage('123')
    pdelete.assert_awaited()
    assert pdelete.await_args.args[0] == '123'


@patch('reddevil.service.sv_page.DbPage.find_single')
@pytest.mark.asyncio
async def test_get_page(pfindsingle: Mock, pagedetailed1):
    pfindsingle.return_value = pagedetailed1
    pd = await getPage('123')
    pfindsingle.assert_awaited()
    assert pfindsingle.await_args.args[0] == {'id':'123'}
    assert isinstance(pd, PageDetailedOut)
    assert pd.id == '234'
    assert pd.slug == 'slug1'

@patch('reddevil.service.sv_page.DbPage.find_single')
@pytest.mark.asyncio
async def test_get_pagebyslug(pfindsingle: Mock, pagedetailed1):
    pfindsingle.return_value = pagedetailed1
    pd = await getPageBySlug('slug2')
    pfindsingle.assert_awaited()
    assert pfindsingle.await_args.args[0] == {'slug':'slug2'}
    assert isinstance(pd, PageDetailedOut)
    assert pd.id == '234'
    assert pd.slug == 'slug1'


@patch('reddevil.service.sv_page.DbPage.find_multiple')
@pytest.mark.asyncio
async def test_get_pages(pfindmultiple: Mock, pages1):
    pfindmultiple.return_value = pages1
    pd = await getPages()
    pfindmultiple.assert_awaited()
    assert isinstance(pd, PageListOut)
    ps = pd.pages 
    assert len(ps) == 2

@patch('reddevil.service.sv_page.DbPage.update')
@pytest.mark.asyncio
async def test_update(pupdate: Mock, pagedetailed1):
    pupdate.return_value = pagedetailed1
    pd = await updatePage('123', PageUpdate(slug='newslug'))
    pupdate.assert_awaited()
    assert pupdate.await_args.args[0] == '123'
    assert pupdate.await_args.args[1] == {'slug': 'newslug'}
    assert isinstance(pd, PageDetailedOut)
    assert pd.id == '234'
    assert pd.slug == 'slug1'


def test_isactive():
    assert isactive({}) is False
    assert isactive({'enabled': False}) is False
    today = date.today().isoformat()
    today_min1 = (date.today() + timedelta(days=-1)).isoformat()
    today_min2 = (date.today() + timedelta(days=-2)).isoformat()
    today_plus1 = (date.today() + timedelta(days=1)).isoformat()
    today_plus2 = (date.today() + timedelta(days=2)).isoformat()
    assert isactive({
        'enabled': True, 
        'publicationdate': today_min1,
        'expirationdate': today_plus1,
    }) is True
    assert isactive({
        'enabled': True, 
        'publicationdate': today_min1,
        'expirationdate': today,
    }) is True
    assert isactive({
        'enabled': True, 
        'publicationdate': today,
        'expirationdate': today,
    }) is True
    assert isactive({
        'enabled': True, 
        'publicationdate': today_plus1,
        'expirationdate': today_plus2,
    }) is False
    assert isactive({
        'enabled': True, 
        'publicationdate': today_min2,
        'expirationdate': today_min1,
    }) is False        