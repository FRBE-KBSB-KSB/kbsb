# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2026

import logging

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Response,
    status,
)
from fastapi.security import HTTPAuthorizationCredentials

from reddevil.core import RdException, bearer_schema, validate_token

from .account import (
    add_account,
    delete_account,
    get_account,
    get_accounts,
    login,
    register_account,
    update_account,
)
from .md_account import (
    AccountDB,
    AccountInValidator,
    AccountLoginValidator,
    AccountUpdateValidator,
)

logger = logging.getLogger("reddevil")

router = APIRouter(prefix="/api/v1/accounts")


@router.get("/mgmt/account", response_model=list[AccountDB])
async def api_get_accounts(auth: HTTPAuthorizationCredentials = Depends(bearer_schema)): # noqa B008
    try:
        await validate_token(auth)
        return await get_accounts()
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("api_get_accounts failed")
        raise HTTPException(500, "ApiGetAccountsFailed")


@router.post("/mgmt/account", response_model=AccountDB)
async def api_add_account(
    ac: AccountInValidator, auth: HTTPAuthorizationCredentials = Depends(bearer_schema) # noqa B008
):
    try:
        await validate_token(auth)
        return await add_account(ac)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("Api_add_account failed")
        raise HTTPException(500, "ApiCreateEventFailed")


@router.get("/mgmt/account/{account_id}", response_model=AccountDB)
async def api_get_account(
    account_id, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)  # noqa B008
):
    try:
        await validate_token(auth)
        return await get_account(account_id)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("Api_get_account failed")
        raise HTTPException(500, "ApiGetAccountFailed")


@router.delete("/mgmt/account/{account_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_account(
    account_id: str, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)  # noqa B008
):
    try:
        await validate_token(auth)
        await delete_account(account_id)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("Api_delete_account failed")
        raise HTTPException(500, "ApiDeleteAccountFailed")


@router.put("/mgmt/account/{account_id}", response_model=AccountDB)
async def api_update_account(
    account_id: str,
    au: AccountUpdateValidator,
    auth: HTTPAuthorizationCredentials = Depends(bearer_schema),  # noqa B008
):
    try:
        await validate_token(auth)
        return await update_account(account_id, au)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("Api_update_account failed")
        raise HTTPException(500, "ApiUpdateAccountFailed")


# actions by the user


@router.post("/anon/login", response_model=str)
async def api_login(li: AccountLoginValidator):
    """
    login in an account, returning an authorisation token
    """
    try:
        logger.debug("api_login caller")
        reply = await login(li)
        logger.debug("api_login called OK")
        return reply
    except RdException as e:
        logger.debug("api_login failed")
        raise HTTPException(e.status_code, e.description)
    except Exception:
        logger.exception("api_login failed")
        raise HTTPException(500, "ApiLoginFailed")


@router.post(
    "/anon/register",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
async def api_register_account(ac: AccountInValidator):
    """
    create an new account, sending a confirm email
    """
    try:
        await register_account(ac)
    except RdException as e:
        raise HTTPException(e.status_code, detail=e.description)
    except Exception:
        logger.exception("Application error registerAccount")
        raise HTTPException(500, "ApiRegisterAccountFailed")


# @router.post("/api/v1/accounts/confirm", status_code=status.HTTP_204_NO_CONTENT)
# async def api_confirmAccount(ac: AccountConfirm):
#     """
#     confirm the valid email of an account
#     """
#     try:
#         await confirmAccount(ac)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception("Api_confirm_account failed")
#         raise HTTPException(500, "ApiConfirmAccountFailed")


# @router.put("/api/v1/accounts/password", response_model=str)
# async def api_updatePassword(
#     passwordupdate: AccountPasswordUpdateValidator,
#     auth: HTTPAuthorizationCredentials = Depends(bearer_schema),
# ):
#     """
#     update the password of an account, return a new token
#     """
#     try:
#         await validate_token(auth)
#         await updatePassword(passwordupdate)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception("Api_update_password failed")
#         raise HTTPException(500, "ApiUpdatePasswordFailed")


# @router.post("/api/v1/accounts/resetpassword", status_code=status.HTTP_204_NO_CONTENT)
# async def api_resetPassword(pwreset: AccountPasswordReset):
#     """
#     ask for a password reset of the account, by sending a password reset email
#     """
#     try:
#         await resetPassword(pwreset)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception("Api_reset_password failed")
#         raise HTTPException(500, "ApiResetPasswordFailed")


# @router.post("/api/v1/accounts/confirmpassword")
# async def api_confirmPasswordReset(
#     pwconfirm: AccountPasswordConfirm,
#     auth: HTTPAuthorizationCredentials = Depends(bearer_schema),
# ):
#     """
#     confirms the password reset email
#     """
#     try:
#         await confirmPassword(pwconfirm)
#     except RdException as e:
#         raise HTTPException(e.status_code, detail=e.description)
#     except Exception as e:
#         log.exception("Api_confirm_password failed")
#         raise HTTPException(500, "ApiConfirmPasswordFailed")
