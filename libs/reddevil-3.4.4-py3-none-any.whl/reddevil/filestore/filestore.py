# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import mimetypes
from fastapi.responses import Response
from typing import IO, List
from google.cloud.storage import Blob, Client as StorageClient
from google.api_core import exceptions
from reddevil.core import get_settings, RdNotFound, RdInternalServerError

logger = logging.getLogger(__name__)
mimetypes.add_type("text/markdown", ".md")


def storage_client() -> StorageClient:
    if not hasattr(storage_client, "sc"):
        setattr(storage_client, "sc", StorageClient())
    return storage_client.sc


def read_bucket_content(path: str) -> bytes:
    """
    read a file from the filestore, returns a bytes object
    """
    fsettings = get_settings().FILESTORE
    if fsettings["manager"] == "google":
        client = storage_client()
        bucket = client.bucket(fsettings["bucket"])
        blob = Blob(path, bucket)
        try:
            contents = blob.download_as_bytes(client=client)
            return contents
        except exceptions.NotFound:
            logger.info(f"File {path} not found in CloudStorage")
            raise RdNotFound()
        except Exception:
            logger.exception(f"read_bucket_content failed")
            raise RdInternalServerError()
    elif fsettings["manager"] == "file":
        dir = fsettings["path"] / path
        try:
            with open(dir, "rb") as f:
                return f.read()
        except Exception:
            logger.exception(f"read_bucket_content failed")
            raise RdInternalServerError()
    else:
        raise NotImplementedError


def read_bucket_metadata(path: str) -> Blob:
    """
    read the file metadata,  returns a Blob
    """
    fsettings = get_settings().FILESTORE
    if fsettings["manager"] == "google":
        client = storage_client()
        bucket = client.bucket(fsettings["bucket"])
        blob = Blob(path, bucket)
        return blob
    else:
        raise NotImplementedError


def write_bucket_content(path: str, fileobj: IO) -> None:
    """
    write a file like object to the cloud storage bucket
    """
    fsettings = get_settings().FILESTORE
    if fsettings["manager"] == "google":
        client = storage_client()
        bucket = client.bucket(fsettings["bucket"])
        blob = Blob(path, bucket)
        blob.upload_from_file(fileobj)
    elif fsettings["manager"] == "file":
        dir = fsettings["path"] / path
        try:
            with open(dir, "wb") as f:
                return f.write(fileobj.read())
        except Exception:
            logger.exception(f"write_bucket_content failed")
            raise RdInternalServerError()
    else:
        raise NotImplementedError


def list_bucket_files(path: str) -> List[str]:
    """
    wrtite a file like object to the filestore
    """
    fsettings = get_settings().FILESTORE
    if fsettings["manager"] == "google":
        client = storage_client()
        blobs = client.list_blobs(fsettings["bucket"], prefix=path)
        return [b.name for b in blobs]
    else:
        raise NotImplementedError


def public_url(group: str, name: str) -> str:
    """
    get the public url of the file
    """
    fsettings = get_settings().FILESTORE
    return f"{fsettings['bucket_public']}/{group}/{name}"


async def anon_list_files(group: str) -> List[str]:
    """
    list all files in a group
    """
    return list_bucket_files(group)


async def get_file(group: str, name: str) -> Response:
    """
    get the file, returnig a Response
    """
    mt, enc = mimetypes.guess_type(name)
    return Response(content=read_bucket_content(f"{group}/{name}"), media_type=mt)


async def mgmt_get_file_metadata(group: str, name: str):
    """
    read the file metadata from the filestore

    """
    b = read_bucket_metadata(f"{group}/{name}")
    return {
        "name": b.name,
        "bucket": b.bucket.name,
        "id": b.id,
        "storage_class": b.storage_class,
        "size": b.size,
        "updated": b.update,
        "generation": b.generation,
        "metageneration": b.metageneration,
        "etag": b.etag,
        "owner": b.owner,
        "component_count": b.component_count,
        "crc32c": b.crc32c,
        "md5_hash": b.md5_hash,
        "cache_control": b.cache_control,
        "content_type": b.content_type,
        "content_disposition": b.content_disposition,
        "content_encoding": b.content_encoding,
        "content_language": b.content_language,
        "metadata": b.metadata,
        "media_link": b.media_link,
        "custom_time": b.custom_time,
        "temporary_hold": b.temporary_hold,
        "retention_expiration_time": b.retention_expiration_time,
    }
