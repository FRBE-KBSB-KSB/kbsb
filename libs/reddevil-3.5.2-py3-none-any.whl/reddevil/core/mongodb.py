# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

import logging
from datetime import datetime, date

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient
from reddevil.core import get_settings
from reddevil.core.secrets import get_secret

logger = logging.getLogger(__name__)


db_mongo = {
    "client": None,
    "database": None,
}

dbs_mongo = {
    "client": None,
    "database": None,
}


def connect_mongodb():
    settings = get_settings()
    mongoparams = get_secret("mongodb")
    db_mongo["client"] = AsyncIOMotorClient(mongoparams["url"])
    database_name = mongoparams["db"]
    db_mongo["database"] = db_mongo["client"][database_name]
    logger.info(f"db {db_mongo['database']}")
    dbs_mongo["client"] = MongoClient(mongoparams["url"])
    dbs_mongo["database"] = dbs_mongo["client"][database_name]


def close_mongodb():
    db_mongo["client"].close()


def get_mongodb():
    return db_mongo["database"]


def get_mongodbs():
    return dbs_mongo["database"]


def date2datetime(d, f):
    """
    converts field f of input mongo document d from date to datetime
    as mongo does not supports dates
    """
    if f in d and isinstance(d[f], date):
        t = datetime.min.time()
        d[f] = datetime.combine(d[f], t)
