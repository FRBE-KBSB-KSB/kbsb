# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2026

import logging
from datetime import date, datetime

from pymongo import AsyncMongoClient, MongoClient

from .secrets import get_secret

logger = logging.getLogger(__name__)


db_mongo = {
    "aclient": AsyncMongoClient,
    "client": MongoClient,
    "database": None,
    "adatabase": None,
}



def a_connect_mongodb():
    mongoparams = get_secret("mongodb")
    database_name = mongoparams["db"]
    db_mongo["aclient"] = AsyncMongoClient(mongoparams["url"]) 
    db_mongo["adatabase"] = db_mongo["aclient"][database_name] 
    logger.info(f"db {db_mongo['adatabase']}")
    return db_mongo

async def a_close_mongodb():
    await db_mongo["aclient"].close()

def a_get_mongodb():
    return db_mongo["adatabase"]

def connect_mongodb():
    mongoparams = get_secret("mongodb")
    database_name = mongoparams["db"]
    db_mongo["client"] = MongoClient(mongoparams["url"]) 
    db_mongo["database"] = db_mongo["client"][database_name] 
    logger.info(f"db {db_mongo['database']}")

def close_mongodb():
    db_mongo["client"].close()

def get_mongodb():
    return db_mongo["database"]

def date2datetime(d, f):
    """
    converts field f of input mongo document d from date to datetime
    as mongo does not supports dates
    """
    if f in d and isinstance(d[f], date):
        t = datetime.min.time()
        d[f] = datetime.combine(d[f], t)
