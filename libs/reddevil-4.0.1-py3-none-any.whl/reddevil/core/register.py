# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2026

import importlib
import logging
from typing import Any

logger = logging.getLogger("reddevil")


class Settings:
    """
    simplified version of django settings handling
    creates attributes on self for all uppercase attributes in settings module
    """

    def __init__(self, settings_module=None):
        if settings_module is None:
            return
        mod = importlib.import_module(settings_module)
        for setting in dir(mod):
            if setting.isupper():
                setting_value = getattr(mod, setting)
                setattr(self, setting, setting_value)


def _reddevilapp(app, settingsmodule, baseurl):
    """
    singleton function that should not be called directly
    """
    if not hasattr(_reddevilapp, "rda"):
        _reddevilapp.rda = { # type: ignore
            "app": app,
            "settingsmodule": settingsmodule,
            "baseurl": baseurl,
            "wrappedsettings": None,
        }


def register_app(app=None, settingsmodule=None, baseurl=None):
    if hasattr(_reddevilapp, "rda"):
        logger.info("register_app was already called, skipping ...")
        return
    _reddevilapp(app, settingsmodule, baseurl)


def get_app():
    if not hasattr(_reddevilapp, "rda"):
        logger.info("get_app: register_app was not yet called, skipping")
        raise RuntimeError("get_app: register_app was not yet called")
    return _reddevilapp.rda["app"] # type: ignore


def get_baseurl():
    if not hasattr(_reddevilapp, "rda"):
        logger.info("get_baseurl: register_app was not yet called, skipping")
        raise RuntimeError("get_baseurl: register_app was not yet called")
    return _reddevilapp.rda["baseurl"] # type: ignore


def get_settings() -> Settings:
    if not hasattr(_reddevilapp, "rda"):
        logger.info("get_settings: register_app was not yet called, skipping")
        s = Settings()
        # set EMAIL to empty dict to avoid errors in tests that don't have settings module
        s.EMAIL = {} # type: ignore
        return s
    rdattr = _reddevilapp.rda # type: ignore
    wrappedsettings = rdattr["wrappedsettings"]
    if wrappedsettings is None:
        wrappedsettings = Settings(rdattr["settingsmodule"])
        rdattr["wrappedsettings"] = wrappedsettings
    return wrappedsettings

def get_setting(key: str) -> Any:
    settings = get_settings()
    return getattr(settings, key)