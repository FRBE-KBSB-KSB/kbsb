# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

# all models in the service level exposed to the API
# we are using pydantic as tool

from datetime import datetime
from enum import Enum

from pydantic import BaseModel

from reddevil.core.dbbase import DbBase


class AccountRequestType(str, Enum):
    email_verification = "email_verification"
    password_reset = "password_reset"


class AccountRequest_:
    """
    contains the fields as registered in the database
    of a email Request to chnage password, confirmAccount, ....
    """

    username: str
    expiry_time: datetime
    reason: str
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class AccountRequest(BaseModel):
    """
    An accountrequest
    """

    username: str | None = None
    expiry_time: datetime | None = None
    id: str | None = None
    reason: str | None = None
    _id: str | None = None
    _documenttype: str | None = None
    _version: int | None = None
    _creationtime: datetime | None = None
    _modificationtime: datetime | None = None


class DbAccountRequest(DbBase):
    COLLECTION = "rd_accountrequest"
    DOCUMENTTYPE = "AccountRequest"
    VERSION = 1


class AccountRequestVerification(BaseModel):
    """
    validator for verification of incoming AccountRequest
    """

    id: str
    password: str
    reason: str
    username: str


class AccountRecreateOrgVerify(BaseModel):
    """
    validator to recreate organisation Verify
    """

    email: str
    org_id: str
