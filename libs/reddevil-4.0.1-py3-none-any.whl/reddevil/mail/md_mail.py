# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2016

# we don't use pydantic here because there is no API ued for these models

from dataclasses import dataclass, field


@dataclass
class MailAttachment:
    filename: str  # filename of attachement
    mimetype: str  # mimetype of attachment
    content_base64: bytes  # base64 encoded content


@dataclass
class MailParams:
    locale: str
    receiver: str
    sender: str
    subject: str
    template: str
    attachments: list[MailAttachment] = field(default_factory=list)
    bcc: str = ""
    cc: str = ""
