# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2026

# all models in the service level exposed to the API
# we are using pydantic as tool

from pydantic import BaseModel


class FileIn(BaseModel):
    """
    contains the minimal fields (doctype and name) to create a new page
    """

    group: str
    content: bytes
    name: str
    metadata: dict | None
