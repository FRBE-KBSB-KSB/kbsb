# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging, json, os, uuid, os
from datetime import datetime, timezone, date
from slugify import slugify
from mimetypes import guess_type
from random import randrange
from base64 import b64encode, b64decode
from typing import List, Optional, Union

from reddevil.common import (
    cfg,
    check_token,
    RdInternalServerError, 
    RdBadRequest,
)

from reddevil.models.md_boardmember import (
    BoardMemberIn,
    BoardMemberOut,
    BoardMemberUpdate,
    BoardMemberListOut,
    BoardMemberOptional,
)

from reddevil.crud.db_boardmember import DbBoardMember

log = logging.getLogger(__name__)

def encode_boardmember(e: dict, _class=BoardMemberOut):
    try:
        eo = _class(**e)
    except Exception:
        log.exception('cannot encode BoardMember')
        raise RdInternalServerError(description='CannotEncodeBoardMember')
    return eo

async def createBoardMember(d: BoardMemberIn) -> str:
    """
    create a new BoardMember returning its id
    """
    bd = d.dict()
    bd['adinterim'] = []
    bd['boardroles'] = []
    bd['enabled'] = True
    bd['permissions'] = dict(showemail=False, showmobile=False, showpicture=False)
    bd['picture'] = b''
    bd['picturename'] = ''
    bd['picturemimetype'] = ''
    bd['priority'] = 0
    return await DbBoardMember.add(bd)

async def deleteBoardMember(id: str) -> None:
    await DbBoardMember.delete(id)

async def getBoardMember(id: str, options: dict= {}) -> BoardMemberOut:
    """
    get the boardmember 
    """
    _class = options.pop('_class', BoardMemberOut)
    filter = dict(id=id, **options)
    bdict = await DbBoardMember.find_single(filter)
    return encode_boardmember(bdict, _class)

async def getBoardMembers(options: dict={}) -> BoardMemberListOut:
    """
    get all the BoardMembers
    """
    _class = options.pop('_class', BoardMemberOut)
    docs = await DbBoardMember.find_multiple(options)
    boardmembers = [encode_boardmember(d, _class) for d in docs]
    return BoardMemberListOut(members=boardmembers)    

async def updateBoardMember(id: str, d: BoardMemberUpdate) -> BoardMemberOut:
    """
    update a boardmember
    """
    bd = d.dict(exclude_unset=True)
    ubd = await DbBoardMember.update(id, bd)
    return encode_boardmember(ubd)

async def backupBoardMembers() -> List[BoardMemberOptional]:
    """
    dumps all BoardMembers records with full details
    """
    docs =  await DbBoardMember.find_multiple({
        '_fieldlist': {}
    })
    return [encode_boardmember(d, BoardMemberOptional) for d in docs]

async def restoreBoardMembers(docs: List[dict]) -> None:
    """
    dumps all BoardMembers records with full details
    """
    await DbBoardMember.restore(docs)    