import logging

from fastapi import HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List
from reddevil.common import app, url, RdException
from reddevil.service.security import bearer_schema, validate_token 
from reddevil.service.sv_boardmember import (
    createBoardMember,
    deleteBoardMember,
    getBoardMember,
    getBoardMembers,
    updateBoardMember,
)
from reddevil.models.md_boardmember import (
    BoardMemberIn,
    BoardMemberListOut,
    BoardMemberOut,
    BoardMemberUpdate,
)

log = logging.getLogger('reddevil')

assert app is not None


@app.get(url + '/boardmembers', response_model=BoardMemberListOut)
async def api_getBoardMembers(reports: int=0, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getBoardMembers()
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_boardmembers')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.post(url + '/boardmembers', response_model=str)
async def aoi_createBoardMember(p: BoardMemberIn, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await createBoardMember(p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call create_boardmember')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get(url + '/boardmember/{id}', response_model=BoardMemberOut)
async def api_getBoardMember(id: str, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getBoardMember(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call get_boardmember')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.delete(url + '/boardmember/{id}')
async def api_deleteBoardMember(id: str, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await deleteBoardMember(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call delete_boardmember')
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.put(url + '/boardmember/{id}')
async def api_updateBoardMember(id: str, p: BoardMemberUpdate, 
    auth: HTTPAuthorizationCredentials=Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await updateBoardMember(id, p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception('failed api call update_boardmember')
        raise HTTPException(status_code=500, detail="Internal Server Error")
