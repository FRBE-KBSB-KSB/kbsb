# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

from datetime import datetime
from typing import Dict, Any, List, Optional, Type
from pydantic import BaseModel
from .md_i18nfield import I18nField

class BoardRole(BaseModel):
    """
    a BoardRole as written in database
    """
    name: str
    title: Dict[str, I18nField]  
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime


class BoardRoleOptional(BaseModel):
    """
    a BoardRole as written in database
    """
    id: Optional[str] = None
    name: Optional[str] = None
    title: Optional[Dict[str, I18nField]] = None
    _id: Optional[str] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None

class BoardRoleIn(BaseModel):
    """
    contains the minimal fields to create a new boardrole
    """
    name: str

class BoardRoleOut(BaseModel):
    """
    A readonly view used for listing boardroles
    """
    id: str
    name: str
    title: Dict[str, I18nField]

class BoardRoleListOut(BaseModel):
    roles: List[BoardRoleOut]

class BoardRoleUpdate(BaseModel):
    """
    An update to a boardrole: all fields are optional
    """
    title: Optional[Dict[str,I18nField]] = None
    name: Optional[str] = None

