# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import os.path

# load settings
from reddevil.common.configreader import SettingsProxy
settings = SettingsProxy('testrunner.settings')

import logging, logging.config
logging.config.dictConfig(settings.LOG_CONFIG)

version = '0.0.1'
# read VERSION file if it exist
try:
    with open(os.path.join(os.path.dirname(__file__), 'VERSION')) as fv:
        version = fv.read()
except:
    pass

log = logging.getLogger('testrunner')
log.info(f'Starting Chess API v{version} ...')


from fastapi import FastAPI
app = FastAPI(
    title="Testrunner Reddevil",
    description="Reddevil RESTful api for chess projects",
    version=version,
)

@app.get("/")
async def root():
    return {"message": "Hello World"}

from reddevil.common import register_app
register_app(settings, app)

# import api endpoints
import reddevil.boardmember.api_bmember
log.info(f'Api layer loaded')

