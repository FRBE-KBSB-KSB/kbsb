#    Copyright Chessdevil Consulting 2019 - 2026

import base64
import logging
import smtplib
import time
from email.mime.base import MIMEBase
from pathlib import Path

from fastapi import HTTPException
from google.oauth2 import service_account
from googleapiclient.discovery import build

from src.reddevil.core import get_secret, get_setting
from src.reddevil.core.errors import RdMailError

log = logging.getLogger("bycco")
email_settings = get_setting("EMAIL")
cwd = Path(".")


class BaseEmailBackend:
    def send_message(self, msg: MIMEBase) -> None:
        raise HTTPException(503, detail="EmailBackendNotImplemented")


class SmtpSslBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase) -> None:

        with smtplib.SMTP_SSL(email_settings["host"], email_settings["port"]) as s:
            if email_settings.get("user"):
                s.login(email_settings["user"], email_settings["password"])
            s.send_message(msg)


class SmtpBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase) -> None:
        with smtplib.SMTP(email_settings["host"], email_settings["port"]) as s:
            if email_settings.get("user"):
                s.login(email_settings["user"], email_settings["password"])
            s.send_message(msg)


class GmailBackend(BaseEmailBackend):
    def send_message(self, msg: MIMEBase) -> None:
        service = get_gmail_service()
        rmsg = {"raw": base64.urlsafe_b64encode(msg.as_bytes()).decode("ascii")}
        retries = 0
        sent = False
        while not sent and retries < 3:
            try:
                service.users().messages().send(userId="me", body=rmsg).execute()
                sent = True
            except Exception as e:
                if retries == 3:
                    raise RdMailError("GmailSendEmailFailed") from e
                retries += 1
                log.error(f"sending Gmail message failed, retrying {retries}")
                time.sleep(5 * retries)


def get_gmail_service():
    if not hasattr(get_gmail_service, "service"):
        secret = get_secret("gmail")
        try:
            cr = service_account.Credentials.from_service_account_info(
                secret, scopes=["https://www.googleapis.com/auth/gmail.send"]
            )
            delegated_credentials = cr.with_subject(email_settings["account"])
            service = build("gmail", "v1", credentials=delegated_credentials)
            get_gmail_service.service = service # type: ignore
        except Exception:
            log.exception("Cannot setup Gmail API")
            raise HTTPException(503, detail="GmailAPINotAvailable")
    return get_gmail_service.service # type: ignore


backends = {
    "SMTP": SmtpBackend,
    "SMTP_SSL": SmtpSslBackend,
    "GMAIL": GmailBackend,
}
