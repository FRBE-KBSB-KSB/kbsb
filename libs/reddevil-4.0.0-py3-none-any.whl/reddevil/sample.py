# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2016

# all database request come in here, but we do not use dataclasess
# if needed we define extra models an do marshalling functions at the service level
# All _id are translatesd to stringified id on output
# All functions expect stringified id as input


from pydantic import BaseModel

from src.reddevil.core.dbbase import DbBase


class Sample(BaseModel):
    name: str | None = ""
    size: int | None = 0
    id: str | None = None


class DbSample(DbBase):
    COLLECTION = "sample"
    DOCUMENTTYPE = "sample"
    VERSION = 1
    ItemField = "samples"
