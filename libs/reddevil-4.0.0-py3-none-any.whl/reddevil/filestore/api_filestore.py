# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2026

import logging

from fastapi import APIRouter, HTTPException

from src.reddevil.core import RdException

from .filestore import (
    anon_list_files,
    get_file,
    mgmt_get_file_metadata,
    public_url,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/filestore")


@router.get("/anon/file", response_model=str)
async def api_anon_get_file(group: str, name: str):
    try:
        return await get_file(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except Exception:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/anon/public_url", response_model=str)
def api_anon_public_url(group: str, name: str):
    try:
        return public_url(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except Exception:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/anon/files", response_model=list[str])
async def api_anon_get_files(group: str):
    try:
        return await anon_list_files(group)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except Exception:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/mgmt/metadata")
async def api_mgmt_get_file(group: str, name: str):
    try:
        return await mgmt_get_file_metadata(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except Exception:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")
