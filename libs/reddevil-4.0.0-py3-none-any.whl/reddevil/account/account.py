# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import asyncio
import logging
import uuid
from datetime import UTC, datetime, timedelta
from typing import cast

from fastapi import BackgroundTasks
from google.auth.transport import requests
from google.oauth2 import id_token

from src.reddevil.core import (
    RdBadRequest,
    RdNotAuthorized,
    RdNotFound,
    encode_model,
    get_setting,
    hash_password,
    jwt_encode,
    verify_password,
)
from src.reddevil.mail import MailParams, sendEmailNoAttachments

from .md_account import (
    AccountDB,
    AccountInValidator,
    AccountLoginValidator,
    AccountOutValidator,
    AccountPasswordConfirmValidator,
    AccountPasswordUpdateValidator,
    AccountUpdateValidator,
    DbAccount,
)
from .md_accountrequest import (
    AccountRequest,
    AccountRequestVerification,
    DbAccountRequest,
)

logger = logging.getLogger(__name__)


async def get_accounts(options: dict | None = None) -> list[AccountDB]:
    """
    get all account
    """
    opt = options or {}
    opt.pop("_class", AccountOutValidator)
    opt["_model"] = AccountDB
    accs = await DbAccount.find_multiple(opt)
    assert all(isinstance(acc, AccountDB) for acc in accs)
    return cast(list[AccountDB], accs)


async def add_account(d: AccountInValidator, options: dict | None = None) -> AccountDB:
    """
    add a new Account
    """
    assert isinstance(d.password, str)
    acc = AccountDB(
        domain=d.domain,
        email=d.email,
        enabled=d.enabled,
        hashed_password=hash_password(d.password),
        id=d.id,
        locale=d.locale,
        logintype=d.logintype,
        tokensalt=str(uuid.uuid1()),
        verified=False,
    )
    context = acc.model_dump() 
    if options:
        context.update(options)
    context["_model"] = AccountDB
    newacc = await DbAccount.add(context)
    assert isinstance(newacc, AccountDB)
    return newacc


async def delete_account(id: str) -> None:
    """
    delete the account
    """
    await DbAccount.delete(id)


async def get_account(options: dict | None = None) -> AccountDB:
    """
    get the account, AccountOut is default validator
    """
    myoptions = (options or {}).copy() | {"_model": AccountDB}
    acc = await DbAccount.find_single(myoptions)
    assert isinstance(acc, AccountDB)
    return acc


async def update_account(
    id: str, d: AccountUpdateValidator, options: dict | None = None
) -> dict:
    """
    update a Account
    """
    logger.debug(f"updating {id}")
    try:
        uacc = await DbAccount.update(
            id, d.model_dump(exclude_unset=True), options or {}
        )
        assert isinstance(uacc, dict)
    except Exception:
        logger.exception("cannot update account")
        raise RdBadRequest(description="CannotUpdateAccount")
    logger.debug(f"updated {uacc['id']}")
    return uacc


async def add_accountrequest(
    d: AccountRequest, options: dict | None = None
) -> str:
    """
    add a new AccountREquest
    """
    myoptions = (options or {}).copy() | {"_model": AccountDB}
    idstr = await DbAccountRequest.add(d.model_dump() | myoptions)
    assert isinstance(idstr, str)
    return idstr


async def register_account(ai: AccountInValidator, bt: BackgroundTasks | None = None) -> AccountDB:
    """
    add a new Account
    """
    hours = get_setting("ACCOUNT")["email_expiry_hours"]
    acc = await add_account(ai)
    idstr = await add_accountrequest(
        AccountRequest(
            username=ai.id,
            expiry_time=datetime.now(UTC)
            + timedelta(hours=hours),
            reason="account_registration",
        )
    )
    ar = await get_account({"id": ai.id, "_model": AccountRequest})
    mp = MailParams(
        bcc=get_setting("EMAIL").get("bcc"),
        locale=ai.locale or "en",
        receiver=acc.email,
        sender=get_setting("EMAIL")["sender"],
        subject="Account registration",
        template=get_setting("ACCOUNT")["account_register_template"],
    )
    context = acc.model_dump()
    context.update(ar.model_dump())
    if bt:
        bt.add_task(sendEmailNoAttachments, mp, context, "account_registration")
    return acc


async def account_email_verification(arv: AccountRequestVerification) -> None:
    """
    verify returned email verification
    """
    ardict = await DbAccountRequest.find_single(
        {"id": arv.id, "username": arv.username}
    )
    assert isinstance(ardict, dict)
    ar = cast(AccountRequest, encode_model(AccountRequest, ardict))
    assert ar.expiry_time and ar.username
    if ar.reason != arv.reason:
        raise RdBadRequest(description="WrongReason")
    if ar.expiry_time < datetime.now(UTC):
        raise RdBadRequest(description="VerificationRequestExpired")
    # the verification succeeded, drop the request and update the account
    await DbAccountRequest.delete(arv.id)
    hashed_password = hash_password(arv.password)
    await update_account(
        ar.username,
        AccountUpdateValidator(),
        {"$set": {"verified": True, "hashed_password": hashed_password}},
    )
    logger.info(
        f"AccountRequest {arv.reason} for {ar.username} successfully processed."
    )


async def update_password(apu: AccountPasswordUpdateValidator, checkold=True) -> None:
    """
    update password
    """
    try:
        acc = await get_account(
            {
                "id": apu.username,
                "_model": AccountDB,
                "_fieldlist": ["hashed_password", "tokensalt"],
            },
        )
        assert acc.hashed_password
    except RdNotFound:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    verified = verify_password(apu.oldpassword, acc.hashed_password)
    if checkold and not verified:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    hashed_password = hash_password(apu.newpassword)
    await update_account(
        apu.username,
        AccountUpdateValidator(),
        {
            "$set": {
                "hashed_password": hashed_password,
            }
        },
    )
    logger.info(f"Account {apu.username} password changed.")


async def set_password(username: str, password: str) -> None:
    """
    force password set, no checks
    """
    hashed_password = hash_password(password)
    await update_account(
        username,
        AccountUpdateValidator(),
        {
            "$set": {
                "hashed_password": hashed_password,
            }
        },
    )
    logger.info(f"Account {username} password set.")


async def check_accountid(id: str) -> bool:
    """
    check if account id already exists
    """
    try:
        await DbAccount.find_single({"id": id})
        return True
    except RdNotFound:
        logger.debug("JWT Error")
        return False


async def confirm_passwordreset(pwc: AccountPasswordConfirmValidator) -> str:
    """
    confirms a newly reset password, returning a new authorisation token
    """
    token_settings = get_setting("TOKEN")
    hashed_password = hash_password(pwc.newpassword)
    await update_account(
        pwc.username,
        AccountUpdateValidator(),
        {"$set": {"hashed_password": hashed_password}},
    )
    acc = await get_account({
        "_id": pwc.username,
        "_class": AccountDB, 
        "_fieldlist": ["hashed_password", "tokensalt"]
    })
    assert isinstance(acc, dict)
    token = await get_token(acc, timedelta(minutes=token_settings["timeout"]))
    return token


async def get_token(acc: dict, duration: timedelta, invalidate: bool = True) -> str:
    """
    gets a new JWT token for a user
    :param acc: an Account
    :param invalidate: invalidate the existing tokens by changing the salt
    :return: return the newly created token
    """
    id = acc["id"]
    assert id
    if invalidate or acc["tokensalt"] is None:
        tokensalt = str(uuid.uuid1())
        logger.debug("get_token needs updating account with new tokensalt")
        await update_account(
            id, AccountUpdateValidator(), {"$set": {"tokensalt": tokensalt}}
        )
    else:
        tokensalt = acc["tokensalt"]
        await asyncio.sleep(0)  # a noop await
    payload = {"sub": acc["id"], "exp": datetime.now(UTC) + duration}
    return jwt_encode(payload, tokensalt)


async def login(al: AccountLoginValidator) -> str:
    """
    login and returns a newly create JWT token
    """
    logger.debug("entering login")
    token_settings = get_setting("TOKEN")
    gclid = get_setting("GOOGLE_CLIENT_ID")
    glogin_domains = get_setting("GOOGLE_LOGIN_DOMAINS")
    if al.logintype == "google":
        assert al.token is not None
        token = al.token
        try:
            idinfo = id_token.verify_oauth2_token(
                token, requests.Request(), gclid
            )
        except ValueError:
            raise RdNotAuthorized(description="InvalidGoogleToken")
        if idinfo["iss"] not in ["accounts.google.com", "https://accounts.google.com"]:
            raise RdNotAuthorized(description="WrongAuthIssuer")
        if (
            glogin_domains
            and idinfo["hd"] not in glogin_domains
        ):
            raise RdNotAuthorized(description="WrongGoogleDomain")
        try:
            acc = await get_account(
                {"id": idinfo["email"], "_fieldlist": ["tokensalt"]}
            )
            logger.debug(f"found account {acc['id']}")
        except RdNotFound:
            logger.debug("account not found creating ...")
            ai = AccountInValidator(
                domain=idinfo["hd"],
                email=idinfo["email"],
                enabled=True,
                id=idinfo["email"],
                logintype="google",
            )
            await DbAccount.add(ai)
            acc = await get_account(
                {"id": idinfo["email"], "_fieldlist": ["tokensalt"]}
            )
    elif al.logintype == "email":
        assert al.password
        if al.username is None:
            raise RdBadRequest(description="MissingUsername")
        try:
            acc = await get_account(
                {"_id": al.username, "_fieldlist": ["hashed_password", "tokensalt"]}
            )
            assert isinstance(acc, dict)
            assert acc["hashed_password"]
        except RdNotFound:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
        verified = False
        try:
            verified = verify_password(al.password, acc["hashed_password"])
        except Exception:
            logger.exception("cannot process verify password")
        if not verified:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
    else:
        raise RdBadRequest(description="InvalidLoginType")
    assert isinstance(acc, dict)
    logger.info(f"logged in as {acc['id']}")
    token = await get_token(acc, timedelta(minutes=token_settings["timeout"]))
    return token
