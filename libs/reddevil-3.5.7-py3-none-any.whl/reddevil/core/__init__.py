# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

# variables common for all reddevil modules

from .colorlogfactory import c_factory
from .dbbase import DbBase, encode_model
from .errors import (
    RdBadRequest,
    RdException,
    RdInternalServerError,
    RdNotAuthorized,
    RdNotFound,
)
from .mongodb import (
    close_mongodb,
    connect_mongodb,
    date2datetime,
    get_mongodb,
    get_mongodbs,
)
from .register import (
    Settings,
    get_app,
    get_baseurl,
    get_setting,
    get_settings,
    register_app,
)
from .secrets import (
    get_secret,
    secretmanager_client,
)
from .security import (
    bearer_schema,
    get_tokensalt,
    hash_password,
    jwt_encode,
    jwt_getunverifiedpayload,
    jwt_verify,
    validate_token,
    verify_password,
)

__all__ = [
    "DbBase",
    "RdBadRequest",
    "RdException",
    "RdInternalServerError",
    "RdNotAuthorized",
    "RdNotFound",
    "Settings",
    "bearer_schema",
    "c_factory",
    "close_mongodb",
    "connect_mongodb",
    "date2datetime",
    "encode_model",
    "get_app",
    "get_baseurl",
    "get_mongodb",
    "get_mongodbs",
    "get_secret",
    "get_setting",
    "get_settings",
    "get_tokensalt",
    "hash_password",
    "jwt_encode",
    "jwt_getunverifiedpayload",
    "jwt_verify",
    "register_app",
    "secretmanager_client",
    "validate_token",
    "verify_password",
]