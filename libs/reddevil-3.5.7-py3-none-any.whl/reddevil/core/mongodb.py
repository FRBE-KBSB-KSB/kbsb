# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

import logging
from datetime import date, datetime

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient

from .register import get_settings
from .secrets import get_secret

logger = logging.getLogger(__name__)


db_mongo = {
    "client": AsyncIOMotorClient,
    "database": None,
}

dbs_mongo = {
    "client": MongoClient,
    "database": None,
}


def connect_mongodb():
    get_settings()
    mongoparams = get_secret("mongodb")
    database_name = mongoparams["db"]
    db_mongo["client"] = AsyncIOMotorClient(mongoparams["url"]) 
    db_mongo["database"] = db_mongo["client"][database_name] 
    logger.info(f"db {db_mongo['database']}")
    dbs_mongo["client"] = MongoClient(mongoparams["url"])  
    dbs_mongo["database"] = dbs_mongo["client"][database_name] 


def close_mongodb():
    db_mongo["client"].close()


def get_mongodb():
    return db_mongo["database"]


def get_mongodbs():
    return dbs_mongo["database"]


def date2datetime(d, f):
    """
    converts field f of input mongo document d from date to datetime
    as mongo does not supports dates
    """
    if f in d and isinstance(d[f], date):
        t = datetime.min.time()
        d[f] = datetime.combine(d[f], t)
