#    Copyright 2021 Chessdevil Consulting
import logging
import json
import yaml
from pathlib import Path
from typing import Any
from google.cloud import secretmanager
from reddevil.core import RdInternalServerError, get_settings


logger = logging.getLogger(__name__)


def secretmanager_client():
    if not hasattr(secretmanager_client, "sc"):
        setattr(secretmanager_client, "sc", secretmanager.SecretManagerServiceClient())
    return secretmanager_client.sc


def get_secret(name: str) -> Any:
    settings = get_settings()
    sconfig = settings.SECRETS.get(name, None)
    if not sconfig:
        logger.error(f"Secret {name} not configured")
        raise RdInternalServerError(description="SecretNotConfigured")
    sname = sconfig.get("name", name)
    manager = sconfig.get("manager", "filejson")
    logger.info(f"fetching secret {sname} using manager {manager}")
    if manager == "googlejson":
        project = settings.GOOGLE_PROJECT_ID
        logger.info(f"project _id {project}")
        version = sconfig.get("version", "latest")
        try:
            reply = secretmanager_client().access_secret_version(
                request={
                    "name": f"projects/{project}/secrets/{sname}/versions/{version}"
                }
            )
            return json.loads(reply.payload.data)
        except Exception as e:
            logger.exception(f"Could not get gcp secret {sname}")
            raise e
    if manager == "googleyaml":
        project = settings.GOOGLE_PROJECT_ID
        version = sconfig.get("version", "latest")
        try:
            reply = secretmanager_client().access_secret_version(
                request={
                    "name": f"projects/{project}/secrets/{sname}/versions/{version}"
                }
            )
            return yaml.safe_load(reply.payload.data)
        except Exception as e:
            logger.exception(f"Could not get gcp secret {sname}")
            raise e
    if manager == "filejson":
        extension = sconfig.get("extension", ".json")
        sfile = Path(settings.SECRETS_PATH) / f"{sname}{extension}"
        try: 
            with open(sfile) as f:
                return json.load(f)
        except Exception as e:
            logger.exception(f"Cannot load secret file {sfile}")
            raise e
    if manager == "fileyaml":
        extension = sconfig.get("extension", ".yaml")
        sfile = Path(settings.SECRETS_PATH) / f"{sname}{extension}"
        try: 
            with open(sfile) as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.exception(f"Cannot load secret file {sfile}")
            raise e